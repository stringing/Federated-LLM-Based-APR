#include <iostream>
#include <string>
using namespace std;

int main() {
  int nCase;
  cin >> nCase;
  for (int iCase = 0; iCase < nCase;) {
    ++iCase;
    cout << "Case #" << iCase << ": ";
    string st;
    int ans = 0, k;
    cin >> st >> k;
    for (int cas = 0; cas < st.length() - k + 1; ++cas) {
      if (st[cas] == '-') {
        for (int j = 0; j < k; ++j) {
          st[cas + j] = (st[cas + j] == '+') ? '-' : '+';
        }
        ++ans;
      }
    }
    bool possible = true;
    for (auto cas = st.begin(); cas != st.end(); ++cas) {
      if (*cas == '-') {
        possible = false;
        break;
      }
    }
    if (possible) {
      cout << ans << endl;
    } else {
      cout << "IMPOSSIBLE" << endl;
    }
  }
}
