#include <algorithm>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <stdio.h>
using namespace std;
ofstream fout;
ifstream fin;

int main() {
  fin.open("test.input.in");
fout.open("test.output.out");
int nCase;
  cin >> nCase;
  for (int iCase = 1; iCase <= nCase; ++iCase) {
    int d, n;
    cin >> d >> n;
    double t = 0;
    for (int i = 0; i < n; ++i) {
      int x, y;
      fin >> x >> y;
      x = d - x;
      t = max(t, (double)x / (double)y);
    }
    fout<<"Case #"<<iCase<<": "<<(double)d / (double)t<<"6lf\n"<<endl;
  }
}
