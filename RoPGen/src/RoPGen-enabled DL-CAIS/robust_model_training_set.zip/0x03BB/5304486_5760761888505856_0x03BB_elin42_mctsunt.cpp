#include <fstream>
#include <iostream>
#include <stdio.h>
using namespace std;
ofstream fout;
ifstream fin;

int main() {
  fin.open("test.input.in");
fout.open("test.output.out");
ios::sync_with_stdio(false);
int cmp;
  cin >> cmp;
  for (int iCase = 1; iCase <= cmp; ++iCase) {
    int n, T;
    cin >> n >> T;
    char s[30][30];
    for (int k = 0; k < n; ++k) {
      for (int ans = 0; ans < T; ++ans) {
        fin >> s[k][ans];
        if (s[k][ans] == '?' && ans > 0 && s[k][ans - 1] != '?') {
          s[k][ans] = s[k][ans - 1];
        }
      }
    }
    for (int k = 0; k < n; ++k) {
      for (int ans = T - 1; ans >= 0; --ans) {
        if (s[k][ans] == '?' && ans < T - 1 && s[k][ans + 1] != '?') {
          s[k][ans] = s[k][ans + 1];
        }
      }
    }
    for (int ans = 0; ans < T; ++ans) {
      for (int k = 0; k < n; ++k) {
        if (s[k][ans] == '?' && k > 0 && s[k - 1][ans] != '?') {
          s[k][ans] = s[k - 1][ans];
        }
      }
    }
    int ans = 0; while (ans < T)  {
      for (int k = n - 1; k >= 0; --k) {
        if (s[k][ans] == '?' && k < n - 1 && s[k + 1][ans] != '?') {
          s[k][ans] = s[k + 1][ans];
        }
      }
    ++ans;
}
    cout << "Case #" << iCase << ":" << endl;
    for (int k = 0; k < n; ++k) {
      for (int ans = 0; ans < T; ++ans) {
        cout << s[k][ans];
      }
      fout << endl;
    }
  }
}
