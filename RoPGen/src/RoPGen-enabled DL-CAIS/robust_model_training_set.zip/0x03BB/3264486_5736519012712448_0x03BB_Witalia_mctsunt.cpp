#include <iostream>
#include <stdio.h>
#include <string>
using namespace std;

void split_main_31_35(bool* possible,int* ans) {
    if ((*possible)) {
      cout << (*ans) << endl;
    } else {
      printf("IMPOSSIBLE\n");
    }
}
int main() {
  ios::sync_with_stdio(false);
int sz;
  scanf("%d",&sz);
  for (int iCase = 0; iCase < sz;) {
    ++iCase;
    printf("Case #%d: ",iCase);
    string st;
    int ans = 0, k;
    cin >> st >> k;
    for (int i = 0; i < st.length() - k + 1; ++i) {
      if (st[i] == '-') {
        int j = 0; while (j < k)  {
          st[i + j] = (st[i + j] == '+') ? '-' : '+';
        ++j;
}
        ++ans;
      }
    }
    bool possible = true;
    for (auto i = st.begin(); i != st.end(); ++i) {
      if (*i == '-') {
        possible = false;
        break;
      }
    }
    split_main_31_35(&possible,&ans);

  }
}
