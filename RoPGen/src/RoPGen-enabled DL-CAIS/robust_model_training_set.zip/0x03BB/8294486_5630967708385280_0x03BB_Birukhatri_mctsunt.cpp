#include <algorithm>
#include <cstdio>
#include <iostream>
#include <stdio.h>
using namespace std;

int main() {
  int calc;
  cin >> calc;
  for (int iCase = 1; iCase <= calc; ++iCase) {
    int d, n;
    scanf("%d%d",&d,&n);
    double t = 0;
    for (int i = 0; i < n; ++i) {
      int x, y;
      scanf("%d%d",&x,&y);
      x = d - x;
      t = max(t, (double)x / (double)y);
    }
    printf("Case #%d: %.6lf\n", iCase, (double)d / (double)t);
  }
}
