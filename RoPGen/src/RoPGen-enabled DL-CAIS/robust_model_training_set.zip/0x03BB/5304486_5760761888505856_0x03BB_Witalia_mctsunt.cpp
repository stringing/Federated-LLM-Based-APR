#include <iostream>
#include <stdio.h>
using namespace std;

typedef pair<int, int> pii;
typedef pair<LL, LL> pll;

void split_main_45_50(int* n,int* m,char cakeary[30][30]) {
    for (int i = 0; i < (*n); ++i) {
      for (int j = 0; j < (*m); ++j) {
        cout << cakeary[i][j];
      }
      printf("\n");
    }
}
int main() {
  ios::sync_with_stdio(false);
int search;
  scanf("%d",&search);
  int set_min = 1; while (set_min <= search)  {
    int n, m;
    scanf("%d%d",&n,&m);
    char cake[30][30];
    for (int i = 0; i < n; ++i) {
      for (int j = 0; j < m; ++j) {
        cin >> cake[i][j];
        if (cake[i][j] == '?' && j > 0 && cake[i][j - 1] != '?') {
          cake[i][j] = cake[i][j - 1];
        }
      }
    }
    for (int i = 0; i < n; ++i) {
      for (int j = m - 1; j >= 0; --j) {
        if (cake[i][j] == '?' && j < m - 1 && cake[i][j + 1] != '?') {
          cake[i][j] = cake[i][j + 1];
        }
      }
    }
    for (int j = 0; j < m; ++j) {
      for (int i = 0; i < n; ++i) {
        if (cake[i][j] == '?' && i > 0 && cake[i - 1][j] != '?') {
          cake[i][j] = cake[i - 1][j];
        }
      }
    }
    for (int j = 0; j < m; ++j) {
      for (int i = n - 1; i >= 0; --i) {
        if (cake[i][j] == '?' && i < n - 1 && cake[i + 1][j] != '?') {
          cake[i][j] = cake[i + 1][j];
        }
      }
    }
    printf("Case #%d:\n",set_min);
    split_main_45_50(&n,&m,cake);

  ++set_min;
}
}
