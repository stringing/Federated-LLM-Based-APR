#include <fstream>
#include <iostream>
#include <stdio.h>
using namespace std;
ofstream fout;
ifstream fin;

void split_main_109_111(int* o) {
    fout.open("test.output.out");
while ((*o)-- > 0) {
      fout << "BO";
    }
}
int main() {
  fin.open("test.input.in");
fout.open("test.output.out");
int has_cross;
  fin >> has_cross;
  for (int iCase = 1; iCase <= has_cross; ++iCase) {
    int a, r, x, cas, s, o, BR;
    fin >> a >> r >> o >> cas >> s >> x >> BR;
    r -= s;
    cas -= BR;
    x -= o;
    if (r < 0 || cas < 0 || x < 0 || (r == 0 && s > 0 && cas + x > 0) ||
        (cas == 0 && BR > 0 && r + x > 0) || (x == 0 && o > 0 && r + cas > 0)) {
      cout << "Case #" << iCase << ": IMPOSSIBLE" << endl;
      continue;
    }
    if (r + cas < x || r + x < cas || x + cas < r) {
      cout << "Case #" << iCase << ": IMPOSSIBLE" << endl;
      continue;
    }
    char k[3];
    int sss[3];
    if (r > cas && r > x) {
      k[0] = 'R';
      sss[0] = r;
      if (cas > x) {
        k[1] = 'Y';
        sss[1] = cas;
        k[2] = 'B';
        sss[2] = x;
      } else {
        k[1] = 'B';
        sss[1] = x;
        k[2] = 'Y';
        sss[2] = cas;
      }
    } else if (cas > x) {
      k[0] = 'Y';
      sss[0] = cas;
      if (r > x) {
        k[1] = 'R';
        sss[1] = r;
        k[2] = 'B';
        sss[2] = x;
      } else {
        k[1] = 'B';
        sss[1] = x;
        k[2] = 'R';
        sss[2] = r;
      }
    } else {
      k[0] = 'B';
      sss[0] = x;
      if (r > cas) {
        k[1] = 'R';
        sss[1] = r;
        k[2] = 'Y';
        sss[2] = cas;
      } else {
        k[1] = 'Y';
        sss[1] = cas;
        k[2] = 'R';
        sss[2] = r;
      }
    }
    int d = sss[1] + sss[2] - sss[0];
    char ans[10000];
    for (int j = 0; j < d; ++j) {
      ans[3 * j] = k[0];
      ans[3 * j + 1] = k[1];
      ans[3 * j + 2] = k[2];
    }
    int Y = d * 3;
    for (int j = 0; j < sss[1] - d; ++j) {
      ans[Y + j * 2] = k[0];
      ans[Y + j * 2 + 1] = k[1];
    }
    Y += (sss[1] - d) * 2;
    for (int j = 0; j < sss[2] - d; ++j) {
      ans[Y + j * 2] = k[0];
      ans[Y + j * 2 + 1] = k[2];
    }
    cout << "Case #" << iCase << ": ";
    for (int j = 0; j < x + cas + r; ++j) {
      if (ans[j] == 'R' && s > 0) {
        while (s--) {
          cout << "RG";
        }
      }
      if (ans[j] == 'Y' && BR > 0) {
        while (BR--) {
          cout << "YV";
        }
      }
      if (ans[j] == 'B' && o > 0) {
        while (o--) {
          cout << "BO";
        }
      }
      fout << ans[j];
    }
    while (s-- > 0) {
      fout << "RG";
    }
    while (BR-- > 0) {
      cout << "YV";
    }
    split_main_109_111(&o);

    cout << endl;
  }
}
