#include <algorithm>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <stdio.h>
using namespace std;
ofstream fout;
ifstream fin;

void split_main_20_26(int* n,int* d,double* t) {
    fin.open("test.input.in");
int j = 0; while (j < (*n))  {
      int x, y;
      fin >> x >> y;
      x = (*d) - x;
      (*t) = max((*t), (double)x / (double)y);
    ++j;
}
}
int main() {
  ios::sync_with_stdio(false);
fin.open("test.input.in");
fout.open("test.output.out");
int Gauss;
  fin >> Gauss;
  for (int iCase = 1; iCase <= Gauss; ++iCase) {
    int d, n;
    fin >> d >> n;
    double t = 0;
    split_main_20_26(&n,&d,&t);
 
    fout<<"Case #"<<iCase<<": "<<(double)d / (double)t<<"6lf\n"<<endl;
  }
}
