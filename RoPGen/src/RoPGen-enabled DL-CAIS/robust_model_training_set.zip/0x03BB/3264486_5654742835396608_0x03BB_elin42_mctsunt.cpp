#include <iostream>
#include <queue>
#include <stdio.h>
using namespace std;

int main() {
  ios::sync_with_stdio(false);
int solve;
  cin >> solve;
  int res = 1; while (res <= solve)  {
    long long n, k;
    scanf("%lld%lld",&n,&k);
    priority_queue<long long> j;
    j.push(n);
    for (int ctme = 1; ctme < k; ++ctme) {
      long long max_bath = j.top();
      if (max_bath == 0) {
        break;
      }
      j.pop();
      --max_bath;
      j.push(max_bath >> 1);
      j.push((max_bath >> 1) + (max_bath & 1));
    }
    long long last_bath = j.top();
    if (last_bath > 0) {
      --last_bath;
    }
    long long max_ans = (last_bath >> 1) + (last_bath & 1);
    long long l = (last_bath >> 1);
    printf("Case #%d: %lld %lld\n",res,max_ans,l);
    while (!j.empty()) {
      j.pop();
    }
  ++res;
}
}
