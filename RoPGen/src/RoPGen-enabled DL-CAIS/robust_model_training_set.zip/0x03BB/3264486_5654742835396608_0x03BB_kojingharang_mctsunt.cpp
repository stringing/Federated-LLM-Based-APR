#include <fstream>
#include <iostream>
#include <queue>
#include <stdio.h>
using namespace std;
ofstream fout;
ifstream fin;

typedef pair<dbl, int> pdi;

int main() {
  fin.open("test.input.in");
fout.open("test.output.out");
int sz;
  fin >> sz;
  for (int j = 1; j <= sz; ++j) {
    long long n, s;
    fin >> n >> s;
    priority_queue<long long> res;
    res.push(n);
    for (int cnt = 1; cnt < s; ++cnt) {
      long long r = res.top();
      if (r == 0) {
        break;
      }
      res.pop();
      --r;
      res.push(r >> 1);
      res.push((r >> 1) + (r & 1));
    }
    long long x = res.top();
    if (x > 0) {
      --x;
    }
    long long v = (x >> 1) + (x & 1);
    long long ii = (x >> 1);
    fout << "Case #" << j << ": " << v << " " << ii << endl;
    while (!res.empty()) {
      res.pop();
    }
  }
}
