#include <algorithm>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <stdio.h>
using namespace std;
ofstream fout;
ifstream fin;

int main() {
  fin.open("test.input.in");
fout.open("test.output.out");
ios::sync_with_stdio(false);
int casen;
  cin >> casen;
  int s = 1; while (s <= casen)  {
    int j, r;
    cin >> j >> r;
    double t = 0;
    for (int i = 0; i < r; ++i) {
      int x, casex;
      fin >> x >> casex;
      x = j - x;
      t = max(t, (double)x / (double)casex);
    }
    fout<<"Case #"<<s<<": "<<(double)j / (double)t<<"6lf\n"<<endl;
  ++s;
}
}
