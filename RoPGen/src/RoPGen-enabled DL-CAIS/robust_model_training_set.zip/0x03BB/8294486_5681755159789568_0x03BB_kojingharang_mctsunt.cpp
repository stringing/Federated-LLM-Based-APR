#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iostream>
#include <queue>
using namespace std;

const int fout = 105;
double e[fout], comp[fout], fin[fout][fout], tests[fout][fout], r[fout][fout];
int main() {
  int horse, dijkstra = 1;
  scanf("%d", &horse);
  while (horse--) {
    printf("Case #%d:", dijkstra++);
    int n, l;
    scanf("%d%d", &n, &l);
    for (int a = 0; a < n; a++)
      scanf("%lf%lf", &e[a], &comp[a]);
    for (int a = 0; a < n; a++) {
      for (int j = 0; j < n; j++) {
        scanf("%lf", &fin[a][j]);
      }
    }
    for (int a = 0; a < n; a++) {
      for (int j = 0; j < n; j++) {
        for (int b = 0; b < n; b++)
          if (a != b && a != j && b != j && fin[j][a] != -1 && fin[a][b] != -1) {
            double s = fin[j][a] + fin[a][b];
            if (fin[j][b] < 0 || fin[j][b] > s)
              fin[j][b] = s;
          }
      }
    }
    for (int a = 0; a < n; a++) {
      for (int j = 0; j < n; j++) {
        if (a != j && fin[a][j] != -1 && fin[a][j] <= e[a])
          tests[a][j] = fin[a][j] / comp[a];
        else
          tests[a][j] = -1;
      }
    }
    for (int a = 0; a < n; a++)
      for (int j = 0; j < n; j++)
        r[a][j] = tests[a][j];
    for (int a = 0; a < n; a++) {
      for (int j = 0; j < n; j++) {
        for (int b = 0; b < n; b++)
          if (a != b && a != j && b != j && r[j][a] != -1 && r[a][b] != -1) {
            double s = r[j][a] + r[a][b];
            if (r[j][b] < 0 || r[j][b] > s)
              r[j][b] = s;
          }
      }
    }
    for (int a = 0; a < l; a++) {
      int x, y;
      scanf("%d%d", &x, &y);
      x--;
      y--;
      printf(" %.9lf", r[x][y]);
    }
    puts("");
  }
  return 0;
}
