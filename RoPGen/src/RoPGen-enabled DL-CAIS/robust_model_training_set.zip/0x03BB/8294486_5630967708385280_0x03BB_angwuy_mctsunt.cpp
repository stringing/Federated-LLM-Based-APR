#include <algorithm>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <stdio.h>
using namespace std;
ofstream fout;
ifstream fin;

int main() {
  fin.open("test.input.in");
fout.open("test.output.out");
int nCase;
  cin >> nCase;
  for (int iCase = 1; iCase <= nCase; ++iCase) {
    int d, n;
    fin >> d >> n;
    double t = 0;
    int i = 0; while (i < n)  {
      int x, y;
      cin >> x >> y;
      x = d - x;
      t = max(t, (double)x / (double)y);
    ++i;
}
    fout<<"Case #"<<iCase<<": "<<(double)d / (double)t<<"6lf\n"<<endl;
  }
}
