#include <algorithm>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <stdio.h>
using namespace std;
ifstream fin;

int main() {
  fin.open("test.input.in");
int nCase;
  fin >> nCase;
  for (int iCase = 1; iCase <= nCase; ++iCase) {
    int d, n;
    cin >> d >> n;
    double t ;
    t = 0;
for (int i = 0; i < n; ++i) {
      int x, y;
      cin >> x >> y;
      x = d - x;
      t = max(t, (double)x / (double)y);
    }
    printf("Case #%d: %.6lf\n", iCase, (double)d / (double)t);
  }
}
