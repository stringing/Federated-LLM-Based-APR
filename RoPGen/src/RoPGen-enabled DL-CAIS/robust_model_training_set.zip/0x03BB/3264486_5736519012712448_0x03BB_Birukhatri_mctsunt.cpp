#include <iostream>
#include <stdio.h>
#include <string>
using namespace std;

int main() {
  int nCase;
  scanf("%d",&nCase);
  for (int iCase = 0; iCase < nCase;) {
    ++iCase;
    printf("Case #%d: ",iCase);
    string st;
    int ans = 0, k;
    cin >> st >> k;
    for (int _n = 0; _n < st.length() - k + 1; ++_n) {
      if (st[_n] == '-') {
        for (int j = 0; j < k; ++j) {
          st[_n + j] = (st[_n + j] == '+') ? '-' : '+';
        }
        ++ans;
      }
    }
    bool possible = true;
    for (auto _n = st.begin(); _n != st.end(); ++_n) {
      if (*_n == '-') {
        possible = false;
        break;
      }
    }
    if (possible) {
      cout << ans << endl;
    } else {
      printf("IMPOSSIBLE\n");
    }
  }
}
