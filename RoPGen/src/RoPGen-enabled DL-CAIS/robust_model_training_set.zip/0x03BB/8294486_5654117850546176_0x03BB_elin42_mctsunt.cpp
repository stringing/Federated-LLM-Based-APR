#include <fstream>
#include <iostream>
#include <stdio.h>
using namespace std;
ofstream fout;
ifstream fin;

int main() {
  fin.open("test.input.in");
fout.open("test.output.out");
ios::sync_with_stdio(false);
int t;
  fin >> t;
  for (int iCase = 1; iCase <= t; ++iCase) {
    int n, r, j, ccr, g, o, v;
    cin >> n >> r >> o >> ccr >> g >> j >> v;
    r -= g;
    ccr -= v;
    j -= o;
    if (r < 0 || ccr < 0 || j < 0 || (r == 0 && g > 0 && ccr + j > 0) ||
        (ccr == 0 && v > 0 && r + j > 0) || (j == 0 && o > 0 && r + ccr > 0)) {
      cout << "Case #" << iCase << ": IMPOSSIBLE" << endl;
      continue;
    }
    if (r + ccr < j || r + j < ccr || j + ccr < r) {
      cout << "Case #" << iCase << ": IMPOSSIBLE" << endl;
      continue;
    }
    char c[3];
    int cnt[3];
    if (r > ccr && r > j) {
      c[0] = 'R';
      cnt[0] = r;
      if (ccr > j) {
        c[1] = 'Y';
        cnt[1] = ccr;
        c[2] = 'B';
        cnt[2] = j;
      } else {
        c[1] = 'B';
        cnt[1] = j;
        c[2] = 'Y';
        cnt[2] = ccr;
      }
    } else if (ccr > j) {
      c[0] = 'Y';
      cnt[0] = ccr;
      if (r > j) {
        c[1] = 'R';
        cnt[1] = r;
        c[2] = 'B';
        cnt[2] = j;
      } else {
        c[1] = 'B';
        cnt[1] = j;
        c[2] = 'R';
        cnt[2] = r;
      }
    } else {
      c[0] = 'B';
      cnt[0] = j;
      if (r > ccr) {
        c[1] = 'R';
        cnt[1] = r;
        c[2] = 'Y';
        cnt[2] = ccr;
      } else {
        c[1] = 'Y';
        cnt[1] = ccr;
        c[2] = 'R';
        cnt[2] = r;
      }
    }
    int lc = cnt[1] + cnt[2] - cnt[0];
    char ans[10000];
    for (int val = 0; val < lc; ++val) {
      ans[3 * val] = c[0];
      ans[3 * val + 1] = c[1];
      ans[3 * val + 2] = c[2];
    }
    int k = lc * 3;
    int val = 0; while (val < cnt[1] - lc)  {
      ans[k + val * 2] = c[0];
      ans[k + val * 2 + 1] = c[1];
    ++val;
}
    k += (cnt[1] - lc) * 2;
    for (int val = 0; val < cnt[2] - lc; ++val) {
      ans[k + val * 2] = c[0];
      ans[k + val * 2 + 1] = c[2];
    }
    cout << "Case #" << iCase << ": ";
    for (int val = 0; val < j + ccr + r; ++val) {
      if (ans[val] == 'R' && g > 0) {
        while (g--) {
          cout << "RG";
        }
      }
      if (ans[val] == 'Y' && v > 0) {
        while (v--) {
          cout << "YV";
        }
      }
      if (ans[val] == 'B' && o > 0) {
        while (o--) {
          cout << "BO";
        }
      }
      fout << ans[val];
    }
    while (g-- > 0) {
      cout << "RG";
    }
    while (v-- > 0) {
      cout << "YV";
    }
    while (o-- > 0) {
      cout << "BO";
    }
    cout << endl;
  }
}
