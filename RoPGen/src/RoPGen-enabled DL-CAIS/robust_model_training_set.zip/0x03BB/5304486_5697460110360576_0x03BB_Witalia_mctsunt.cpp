#include <algorithm>
#include <iostream>
#include <stdio.h>
using namespace std;

bool debugarr(int e, int d, int x) {
  return (!(e * d * 1.1 < x || e * d * 0.9 > x));
}

int main() {
  ios::sync_with_stdio(false);
int T;
  scanf("%d",&T);
  double eps = 0.000001;
  for (int iCase = 1; iCase <= T; ++iCase) {
    int ans = 0;
    int n, p;
    scanf("%d%d",&n,&p);
    int a[100];
    for (int r = 0; r < n; ++r) {
      cin >> a[r];
    }
    int b[100][100];
    int max_p = 0;
    int ptr[100];
    for (int r = 0; r < n; ++r) {
      for (int j = 0; j < p; ++j) {
        cin >> b[r][j];
        max_p = max(max_p, b[r][j] / a[r] + 1);
      }
      ptr[r] = 0;
      while (ptr[r] < p && b[r][ptr[r]] < a[r] * 0.9) {
        ++ptr[r];
      }
      sort(b[r], b[r] + p);
    }
    for (int r = 1; r <= max_p; ++r) {
      int ptr_backup[100];
      while (true) {
        bool f = false, canDo = true;
        int j = 0; while (j < n)  {
          ptr_backup[j] = ptr[j];
          if (ptr[j] >= p) {
            f = true;
            break;
          }
          while (ptr[j] < p && b[j][ptr[j]] < a[j] * r * 0.9) {
            ++ptr[j];
          }
          if (ptr[j] < p && !(b[j][ptr[j]] > a[j] * r * 1.1)) {
            ++ptr[j];
          } else {
            canDo = false;
          }
        ++j;
}
        if (f) {
          break;
        }
        if (canDo) {
          ++ans;
        } else {
          for (int k = 0; k <= n; ++k) {
            ptr[k] = ptr_backup[k];
          }
          break;
        }
      }
    }
    printf("Case #%d: %d\n",iCase,ans);
  }
}
