#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <iostream>
#include <queue>
#include <stdio.h>
using namespace std;
ifstream fin;

typedef long long int lld;
typedef pair<lld, lld> PA;

const int N = 105;
double e[N], s[N], d[N][N], t[N][N], r[N][N];
int main() {
  ios::sync_with_stdio(false);
fin.open("test.input.in");
int T, ca = 1;
  scanf("%d", &T);
  while (T--) {
    printf("Case #%d:", ca++);
    int n, m;
    scanf("%d%d", &n, &m);
    for (int l = 0; l < n; l++)
      scanf("%lf%lf", &e[l], &s[l]);
    for (int l = 0; l < n; l++) {
      for (int K = 0; K < n; K++) {
        fin>>d[l][K];
      }
    }
    for (int l = 0; l < n; l++) {
      for (int K = 0; K < n; K++) {
        for (int k = 0; k < n; k++)
          if (l != k && l != K && k != K && d[K][l] != -1 && d[l][k] != -1) {
            double mi = d[K][l] + d[l][k];
            if (d[K][k] < 0 || d[K][k] > mi)
              d[K][k] = mi;
          }
      }
    }
    int l = 0; while (l < n)  {
      for (int K = 0; K < n; K++) {
        if (l != K && d[l][K] != -1 && d[l][K] <= e[l])
          t[l][K] = d[l][K] / s[l];
        else
          t[l][K] = -1;
      }
    l++;
}
    for (int l = 0; l < n; l++)
      for (int K = 0; K < n; K++)
        r[l][K] = t[l][K];
    for (int l = 0; l < n; l++) {
      for (int K = 0; K < n; K++) {
        for (int k = 0; k < n; k++)
          if (l != k && l != K && k != K && r[K][l] != -1 && r[l][k] != -1) {
            double mi = r[K][l] + r[l][k];
            if (r[K][k] < 0 || r[K][k] > mi)
              r[K][k] = mi;
          }
      }
    }
    for (int l = 0; l < m; l++) {
      int x, y;
      fin>>x>>y;
      x--;
      y--;
      printf(" %.9lf", r[x][y]);
    }
    puts("");
  }
  return 0;
}
