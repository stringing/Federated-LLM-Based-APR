#include <iostream>
#include <stdio.h>
#include <string>
using namespace std;

void split_main_29_33(bool* rank,int* v) {
    if ((*rank)) {
      cout << (*v) << endl;
    } else {
      printf("IMPOSSIBLE\n");
    }
}
int main() {
  int solve;
  scanf("%d",&solve);
  for (int mx = 0; mx < solve;) {
    ++mx;
    printf("Case #%d: ",mx);
    string u;
    int v = 0, happy;
    cin >> u >> happy;
    for (int cas = 0; cas < u.length() - happy + 1; ++cas) {
      if (u[cas] == '-') {
        for (int flip = 0; flip < happy; ++flip) {
          u[cas + flip] = (u[cas + flip] == '+') ? '-' : '+';
        }
        ++v;
      }
    }
    bool rank = true;
    for (auto cas = u.begin(); cas != u.end(); ++cas) {
      if (*cas == '-') {
        rank = false;
        break;
      }
    }
    split_main_29_33(&rank,&v);

  }
}
