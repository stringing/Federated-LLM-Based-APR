#include <algorithm>
#include <iostream>
using namespace std;

bool inRange(int e, int d, int x) {
  return (!(e * d * 1.1 < x || e * d * 0.9 > x));
}

int main() {
  int T;
  cin >> T;
  double eps = 0.000001;
  for (int iCase = 1; iCase <= T; ++iCase) {
    int ans = 0;
    int n, p;
    cin >> n >> p;
    int a[100];
    for (int t = 0; t < n; ++t) {
      cin >> a[t];
    }
    int b[100][100];
    int max_p = 0;
    int ptr[100];
    for (int t = 0; t < n; ++t) {
      for (int j = 0; j < p; ++j) {
        cin >> b[t][j];
        max_p = max(max_p, b[t][j] / a[t] + 1);
      }
      ptr[t] = 0;
      while (ptr[t] < p && b[t][ptr[t]] < a[t] * 0.9) {
        ++ptr[t];
      }
      sort(b[t], b[t] + p);
    }
    for (int t = 1; t <= max_p; ++t) {
      int ptr_backup[100];
      while (true) {
        bool f = false, canDo = true;
        for (int j = 0; j < n; ++j) {
          ptr_backup[j] = ptr[j];
          if (ptr[j] >= p) {
            f = true;
            break;
          }
          while (ptr[j] < p && b[j][ptr[j]] < a[j] * t * 0.9) {
            ++ptr[j];
          }
          if (ptr[j] < p && !(b[j][ptr[j]] > a[j] * t * 1.1)) {
            ++ptr[j];
          } else {
            canDo = false;
          }
        }
        if (f) {
          break;
        }
        if (canDo) {
          ++ans;
        } else {
          for (int k = 0; k <= n; ++k) {
            ptr[k] = ptr_backup[k];
          }
          break;
        }
      }
    }
    cout << "Case #" << iCase << ": " << ans << endl;
  }
}
