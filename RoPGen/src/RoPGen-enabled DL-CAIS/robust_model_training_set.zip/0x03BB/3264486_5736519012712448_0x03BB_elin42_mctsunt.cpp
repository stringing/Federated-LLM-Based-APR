#include <fstream>
#include <iostream>
#include <stdio.h>
#include <string>
using namespace std;
ofstream fout;
ifstream fin;

typedef vector<int> vi;
typedef vector<vector<int>> vvi;
typedef pair<int, int> pii;

int main() {
  fin.open("test.input.in");
fout.open("test.output.out");
ios::sync_with_stdio(false);
int solve;
  fin >> solve;
  for (int iCase = 0; iCase < solve;) {
    ++iCase;
    cout << "Case #" << iCase << ": ";
    string t2;
    int ans = 0, k;
    cin >> t2 >> k;
    for (int r = 0; r < t2.length() - k + 1; ++r) {
      if (t2[r] == '-') {
        for (int v = 0; v < k; ++v) {
          t2[r + v] = (t2[r + v] == '+') ? '-' : '+';
        }
        ++ans;
      }
    }
    bool x = true;
    auto r = t2.begin(); while (r != t2.end())  {
      if (*r == '-') {
        x = false;
        break;
      }
    ++r;
}
    if (x) {
      cout << ans << endl;
    } else {
      fout << "IMPOSSIBLE" << endl;
    }
  }
}
