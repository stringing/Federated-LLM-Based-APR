#include <algorithm>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <stdio.h>
using namespace std;
ifstream fin;

typedef vector<int> vi;
void split_main_13_18(int* p,int* k,double* j) {
    fin.open("test.input.in");
for (int ans = 0; ans < (*p); ++ans) {
      int mid, q;
      fin >> mid >> q;
      mid = (*k) - mid;
      (*j) = max((*j), (double)mid / (double)q);
    }
}
int main() {
  fin.open("test.input.in");
int run;
  fin >> run;
  for (int ok = 1; ok <= run; ++ok) {
    int k, p;
    fin >> k >> p;
    double j = 0;
    split_main_13_18(&p,&k,&j);

    printf("Case #%d: %.6lf\n", ok, (double)k / (double)j);
  }
}
