#include <fstream>
#include <iostream>
#include <stdio.h>
using namespace std;
ofstream fout;
ifstream fin;

typedef long long ll;

void split_main_41_46(int* res,int* rightMax,char amary[30][30]) {
    fout.open("test.output.out");
for (int poz = 0; poz < (*res); ++poz) {
      for (int k = 0; k < (*rightMax); ++k) {
        fout << amary[poz][k];
      }
      fout << endl;
    }
}
int main() {
  fin.open("test.input.in");
fout.open("test.output.out");
int solve;
  fin >> solve;
  for (int it = 1; it <= solve; ++it) {
    int res, rightMax;
    fin >> res >> rightMax;
    char am[30][30];
    for (int poz = 0; poz < res; ++poz) {
      for (int k = 0; k < rightMax; ++k) {
        cin >> am[poz][k];
        if (am[poz][k] == '?' && k > 0 && am[poz][k - 1] != '?') {
          am[poz][k] = am[poz][k - 1];
        }
      }
    }
    for (int poz = 0; poz < res; ++poz) {
      for (int k = rightMax - 1; k >= 0; --k) {
        if (am[poz][k] == '?' && k < rightMax - 1 && am[poz][k + 1] != '?') {
          am[poz][k] = am[poz][k + 1];
        }
      }
    }
    for (int k = 0; k < rightMax; ++k) {
      for (int poz = 0; poz < res; ++poz) {
        if (am[poz][k] == '?' && poz > 0 && am[poz - 1][k] != '?') {
          am[poz][k] = am[poz - 1][k];
        }
      }
    }
    for (int k = 0; k < rightMax; ++k) {
      for (int poz = res - 1; poz >= 0; --poz) {
        if (am[poz][k] == '?' && poz < res - 1 && am[poz + 1][k] != '?') {
          am[poz][k] = am[poz + 1][k];
        }
      }
    }
    fout << "Case #" << it << ":" << endl;
    split_main_41_46(&res,&rightMax,am);

  }
}
