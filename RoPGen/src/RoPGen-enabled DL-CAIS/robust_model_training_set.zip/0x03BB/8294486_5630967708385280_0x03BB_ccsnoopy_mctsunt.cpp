#include <algorithm>
#include <cstdio>
#include <iostream>
using namespace std;

void split_main_13_18(int* n,int* d,double* t) {
    for (int i = 0; i < (*n); ++i) {
      int x, y;
      cin >> x >> y;
      x = (*d) - x;
      (*t) = max((*t), (double)x / (double)y);
    }
}
int main() {
  int nCase;
  cin >> nCase;
  for (int iCase = 1; iCase <= nCase; ++iCase) {
    int d, n;
    cin >> d >> n;
    double t = 0;
    split_main_13_18(&n,&d,&t);

    printf("Case #%d: %.6lf\n", iCase, (double)d / (double)t);
  }
}
