#include <algorithm>
#include <fstream>
#include <iostream>
#include <stdio.h>
using namespace std;
ofstream fout;
ifstream fin;

typedef long long ll;

bool gc(int tmpMAX, int MIN, int tmpMIN) {
  return (!(tmpMAX * MIN * 1.1 < tmpMIN || tmpMAX * MIN * 0.9 > tmpMIN));
}

int main() {
  fin.open("test.input.in");
fout.open("test.output.out");
int fin;
  fin >> fin;
  double fout = 0.000001;
  for (int K = 1; K <= fin; ++K) {
    int ans = 0;
    int n, p;
    cin >> n >> p;
    int a[100];
    for (int x = 0; x < n; ++x) {
      cin >> a[x];
    }
    int S[100][100];
    int max_p = 0;
    int ptr[100];
    for (int x = 0; x < n; ++x) {
      for (int N = 0; N < p; ++N) {
        fin >> S[x][N];
        max_p = max(max_p, S[x][N] / a[x] + 1);
      }
      ptr[x] = 0;
      while (ptr[x] < p && S[x][ptr[x]] < a[x] * 0.9) {
        ++ptr[x];
      }
      sort(S[x], S[x] + p);
    }
    for (int x = 1; x <= max_p; ++x) {
      int ptr_backup[100];
      while (true) {
        bool f = false, R = true;
        for (int N = 0; N < n; ++N) {
          ptr_backup[N] = ptr[N];
          if (ptr[N] >= p) {
            f = true;
            break;
          }
          while (ptr[N] < p && S[N][ptr[N]] < a[N] * x * 0.9) {
            ++ptr[N];
          }
          if (ptr[N] < p && !(S[N][ptr[N]] > a[N] * x * 1.1)) {
            ++ptr[N];
          } else {
            R = false;
          }
        }
        if (f) {
          break;
        }
        if (R) {
          ++ans;
        } else {
          for (int k = 0; k <= n; ++k) {
            ptr[k] = ptr_backup[k];
          }
          break;
        }
      }
    }
    fout << "Case #" << K << ": " << ans << endl;
  }
}
