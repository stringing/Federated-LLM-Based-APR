#include <fstream>
#include <iostream>
#include <stdio.h>
#include <string>
using namespace std;
ofstream fout;
ifstream fin;

int main() {
  fin.open("test.input.in");
fout.open("test.output.out");
int simple;
  cin >> simple;
  for (int iCase = 0; iCase < simple;) {
    ++iCase;
    cout << "Case #" << iCase << ": ";
    string st;
    int ans = 0, k;
    fin >> st >> k;
    for (int i = 0; i < st.length() - k + 1; ++i) {
      if (st[i] == '-') {
        for (int j = 0; j < k; ++j) {
          st[i + j] = (st[i + j] == '+') ? '-' : '+';
        }
        ++ans;
      }
    }
    bool possible = true;
    for (auto i = st.begin(); i != st.end(); ++i) {
      if (*i == '-') {
        possible = false;
        break;
      }
    }
    if (possible) {
      cout << ans << endl;
    } else {
      fout << "IMPOSSIBLE" << endl;
    }
  }
}
