#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>
using namespace std;
typedef long long LL;
typedef long double LD;

int cond;

int main() {
  cin >> cond;
  for (int c = 1; c <= cond; ++c) {
    int mu, cs;
    cin >> mu >> cs;
    priority_queue<int> a;
    a.push(mu);
    int rhs, rh;
    for (int d = 0; d < cs; ++d) {
      int c = a.top() - 1;
      a.pop();
      rhs = c / 2 + (c % 2);
      rh = c / 2;
      a.push(rhs);
      a.push(rh);
    }
    cout<<"Case #"<<c<<": "<<rhs<<" "<<rh<<"\n"<<endl;
  }
return 0;}
