#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <vector>
using namespace std;

int tc;

int main() {
  cin >> tc;
  for (int ans = 1; ans <= tc; ans++) {
    string s;
    int get, fl = 0;
    cin >> s >> get;
    {
      int i = 0;
      while (i < s.size() - get + 1) {
        if (s[i] == '-') {
          // cout << "Flip at " << i << endl;
          fl++;
          for (int j = i; j < i + get; j++) {
            if (s[j] == '-')
              s[j] = '+';
            else
              s[j] = '-';
          }
        }
        i++;
      }
    }
    int f = 1;
    for (int i = s.size() - get + 1; i < s.size(); i++) {
      if (s[i] == '-')
        f = 0;
    }
    if (f == 1) {
      printf("Case #%d: %d\n", ans, fl);
    } else {
      printf("Case #%d: IMPOSSIBLE\n", ans, fl);
    }
  }
}
