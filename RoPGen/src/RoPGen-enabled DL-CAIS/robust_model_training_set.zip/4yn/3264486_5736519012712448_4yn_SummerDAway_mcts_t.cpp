#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <iostream>
using namespace std;

int tc;

int main() {
  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_3264486_5736519012712448_15_CCS18_RNN_800_True_MCTS_Classic_True/SummerDAway/4yn/outer_temp/4yn/A-small-practice_transformation.out", "w", stdout);

  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    string s;
    int work, fl = 0;
    cin >> s >> work;
    for (int i = 0; i < s.size() - work + 1; i++) {
      if (s[i] == '-') {
        // cout << "Flip at " << i << endl;
        fl++;
        for (int j = i; j < i + work; j++) {
          if (s[j] == '-')
            s[j] = '+';
          else
            s[j] = '-';
        }
      }
    }
    int f = 1;
    for (int i = s.size() - work + 1; i < s.size(); i++) {
      if (s[i] == '-')
        f = 0;
    }
    if (f == 1) {
      printf("Case #%d: %d\n", t, fl);
    } else {
      printf("Case #%d: IMPOSSIBLE\n", t, fl);
    }
  }
}
