#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
int t;

int main() {
  freopen("C-small-1-attempt0.in","r",stdin);
freopen("out0.out","w",stdout);
cin >> t;
  for (int r = 1; r <= t; r++) {
    int flag, ans;
    cin >> flag >> ans;
    priority_queue<int> l;
    l.push(flag);
    int x, v;
    for (int m = 0; m < ans; m++) {
      int r = l.top() - 1;
      l.pop();
      x = r / 2 + (r % 2);
      v = r / 2;
      l.push(x);
      l.push(v);
    }
    printf("Case #%d: %d %d\n", r, x, v);
  }
return 0;}
