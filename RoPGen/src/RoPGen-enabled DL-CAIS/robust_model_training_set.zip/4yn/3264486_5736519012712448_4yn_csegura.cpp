#include <algorithm>
#include <bits/stdc++.h>
#include <float.h>
#include <iomanip>
#include <iostream>
#include <limits.h>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <vector>
using namespace std;

int tests;

int main() {
  cin >> tests;
  for (int firstSelected = 1; firstSelected <= tests; firstSelected++) {
    string r;
    int solution, ci = 0;
    cin >> r >> solution;
    for (int t = 0; t < r.size() - solution + 1; t++) {
      if (r[t] == '-') {
        // cout << "Flip at " << i << endl;
        ci++;
        for (int i = t; i < t + solution; i++) {
          if (r[i] == '-')
            r[i] = '+';
          else
            r[i] = '-';
        }
      }
    }
    int K = 1;
    for (int j = r.size() - solution + 1; j < r.size(); j++) {
      if (r[j] == '-')
        K = 0;
    }
    if (K == 1) {
      cout<<"Case #"<<firstSelected<<": "<<ci<<"\n"<<endl;
    } else {
      cout<<"Case #"<<firstSelected<<": IMPOSSIBLE\n"<<ci<<endl;
    }
  }
}
