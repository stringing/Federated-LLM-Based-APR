#include <bits/stdc++.h>
#include <unordered_map>
#include <unordered_set>
using namespace std;

int tc;

long long int d;
long long int n;
long long int a;
long long int b;

vector<pair<long long int, long long int>> t;

int main() {
  ios_base::sync_with_stdio(false);
freopen("inp3.txt","r",stdin);
freopen("out3.txt","w",stdout);
cin >> tc;
  for (int k = 1; k <= tc; ++k) {
    t.clear();
    cin >> d >> n;
    double aj = 0;
double ans = 0;
double vec;

    for (int val = 0; val < n; ++val) {
      cin >> a >> b;
      t.push_back((pair<long long int, long long int>)(a, b));
      if (ans == 0) {
        if (a != d) {
          ans = d * b / (d - a + 0.0);
        }
      } else if (a != d) {
        ans = min(ans, d * b / (d - a + 0.0));
      }
    }
    for(;abs(ans - aj) > 0.0000005f;) {
      vec = (ans + aj) / 2;
      bool j = true;
      // cout << "Testing " << ex << endl;
      for (int val = 0; val < n; ++val) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (t[val].second >= vec)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (t[val].first / (vec - t[val].second) * vec < d) {
          j = false;
        }
      }
      if (j) {
        aj = vec;
      } else {
        ans = vec;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << k << ": " << ans << endl;
  }
return 0;}
