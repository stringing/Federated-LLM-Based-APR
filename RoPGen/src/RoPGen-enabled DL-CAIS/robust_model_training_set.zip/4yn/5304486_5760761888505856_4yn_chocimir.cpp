#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

typedef long long LL;
typedef long double LD;

int cond;

void split_main_8_54(int* cond) {
  for (int rh = 1; rh <= (*cond); ++rh) {
    int mu, a;
    cin >> mu >> a;
    char cs[30][30];
    for (int rhs = 0; rhs < mu; ++rhs) {
      for (int d = 0; d < a; ++d) {
        cin >> cs[rhs][d];
      }
    }
    for (int rhs = 0; rhs < mu; ++rhs) {
      // sweep left to right
      for (int d = 1; d < a; ++d) {
        if (cs[rhs][d - 1] != '?' && cs[rhs][d] == '?') {
          cs[rhs][d] = cs[rhs][d - 1];
        }
      }
      // sweep right to left
      for (int d = a - 2; d >= 0; --d) {
        if (cs[rhs][d + 1] != '?' && cs[rhs][d] == '?') {
          cs[rhs][d] = cs[rhs][d + 1];
        }
      }
    }
    for (int rhs = 1; rhs < mu; ++rhs) {
      // sweep up to down
      if (cs[rhs - 1][0] != '?' && cs[rhs][0] == '?') {
        for (int d = 0; d < a; ++d) {
          cs[rhs][d] = cs[rhs - 1][d];
        }
      }
    }
    for (int rhs = mu - 1; rhs >= 0; --rhs) {
      // sweep down to up
      if (cs[rhs + 1][0] != '?' && cs[rhs][0] == '?') {
        for (int d = 0; d < a; ++d) {
          cs[rhs][d] = cs[rhs + 1][d];
        }
      }
    }
    cout << "Case #" << rh << ":\n";
    for (int rhs = 0; rhs < mu; ++rhs) {
      for (int d = 0; d < a; ++d) {
        cout << cs[rhs][d];
      }
      cout << endl;
    }
  }
}
int main() {
  cin >> cond;
  split_main_8_54(&cond);

return 0;}
