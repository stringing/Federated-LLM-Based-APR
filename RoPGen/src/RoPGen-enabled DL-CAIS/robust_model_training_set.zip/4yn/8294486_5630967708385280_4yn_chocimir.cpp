#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

typedef long long LL;
typedef long double LD;

int k;

long long int aj;
long long int cjl;
long long int t;
long long int res;

vector<pair<long long int, long long int>> cond;

int main() {
  cin >> k;
  for (int pi = 1; pi <= k; ++pi) {
    cond.clear();
    cin >> aj >> cjl;
    double mu = 0;
double rhs = 0;
double ex;

    for (int c = 0; c < cjl; ++c) {
      cin >> t >> res;
      cond.push_back((pair<long long int, long long int>)(t, res));
      if (rhs == 0) {
        if (t != aj) {
          rhs = aj * res / (aj - t + 0.0);
        }
      } else if (t != aj) {
        rhs = min(rhs, aj * res / (aj - t + 0.0));
      }
    }
    for(;abs(rhs - mu) > 0.0000005f;) {
      ex = (rhs + mu) / 2;
      bool rh = true;
      // cout << "Testing " << ex << endl;
      for (int cs = 0; cs < cjl; ++cs) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (cond[cs].second >= ex)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (cond[cs].first / (ex - cond[cs].second) * ex < aj) {
          rh = false;
        }
      }
      if (rh) {
        mu = ex;
      } else {
        rhs = ex;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << pi << ": " << rhs << endl;
  }
return 0;}
