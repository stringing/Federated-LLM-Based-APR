#include <bits/stdc++.h>
#include <fstream>
#include <stdio.h>
#include <string>
using namespace std;
ofstream fout;

int Case;

int main() {
  fout.open("/home/hx/data/Mis/media/ramdisk/blackbox_5304486_5760761888505856_15_CCS18_RNN_800_True_MCTS_Classic_True/TungNP/4yn/outer_temp/4yn/A-small-practice_transformation.out");

  scanf("%d ", &Case);
  for (int t = 1; t <= Case; t++) {
    int r, c;
    scanf("%d %d ", &r, &c);
    char cake[30][30];
    for (int i = 0; i < r; i++) {
      for (int solve = 0; solve < c; solve++) {
        scanf("%c ", &cake[i][solve]);
      }
    }
    for (int i = 0; i < r; i++) {
      // sweep left to right
      for (int solve = 1; solve < c; solve++) {
        if (cake[i][solve - 1] != '?' && cake[i][solve] == '?') {
          cake[i][solve] = cake[i][solve - 1];
        }
      }
      // sweep right to left
      for (int solve = c - 2; solve >= 0; solve--) {
        if (cake[i][solve + 1] != '?' && cake[i][solve] == '?') {
          cake[i][solve] = cake[i][solve + 1];
        }
      }
    }
    for (int i = 1; i < r; i++) {
      // sweep up to down
      if (cake[i - 1][0] != '?' && cake[i][0] == '?') {
        for (int solve = 0; solve < c; solve++) {
          cake[i][solve] = cake[i - 1][solve];
        }
      }
    }
    for (int i = r - 1; i >= 0; i--) {
      // sweep down to up
      if (cake[i + 1][0] != '?' && cake[i][0] == '?') {
        for (int solve = 0; solve < c; solve++) {
          cake[i][solve] = cake[i + 1][solve];
        }
      }
    }
    fout << "Case #" << t << ":\n";
    for (int i = 0; i < r; i++) {
      for (int solve = 0; solve < c; solve++) {
        fout << cake[i][solve];
      }
      fout << endl;
    }
  }
}
