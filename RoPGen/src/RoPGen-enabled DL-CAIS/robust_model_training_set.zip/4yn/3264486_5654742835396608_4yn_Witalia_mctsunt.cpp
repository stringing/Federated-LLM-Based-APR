#include <bits/stdc++.h>
#include <iostream>
#include <stdio.h>
using namespace std;
typedef long long LL;

typedef long double LD;

int get_max;

int main() {
  ios::sync_with_stdio(false);
scanf("%d",&get_max);
  int t = 1; while (t <= get_max)  {
    int n, k;
    scanf("%d%d",&n,&k);
    priority_queue<int> pq;
    pq.push(n);
    int ans, z;
    for (int i = 0; i < k; i++) {
      int t = pq.top() - 1;
      pq.pop();
      ans = t / 2 + (t % 2);
      z = t / 2;
      pq.push(ans);
      pq.push(z);
    }
    printf("Case #%d: %d %d\n\n",t,ans,z);
  t++;
}
}
