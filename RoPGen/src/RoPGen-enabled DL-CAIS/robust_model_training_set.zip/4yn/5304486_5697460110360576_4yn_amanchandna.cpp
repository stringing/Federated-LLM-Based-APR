#include <bits/stdc++.h>
#include <unordered_map>
#include <unordered_set>
using namespace std;
int tc;
int n, p;
long long int r[1009];

long long int eleven(long long int t) { return t * 11 / 10; }

long long int ninety(long long int t) {
  long long int y = t * 9 / 10;
  if (t % 10 != 0) {
    y += 1;
  }
  return y;
}

bool inrange(int ingredient, long long int number, long long int servings) {
  long long int t = r[ingredient] * servings;
  return (ninety(t) <= number) && (number <= eleven(t));
}

int main() {
  ios_base::sync_with_stdio(false);
freopen("inp3.txt","r",stdin);
freopen("out3.txt","w",stdout);
cin >> tc;
  for (int ht = 1; ht <= tc; ++ht) {
    long long int aj;
    priority_queue<long long int, vector<long long int>, greater<long long int>> each[1009];
    memset(r, -1, sizeof(r));
    cin >> n >> p;
    for (int val = 0; val < n; ++val) {
      cin >> r[val];
    }
    for (int val = 0; val < n; ++val) {
      for (int newTot = 0; newTot < p; ++newTot) {
        cin >> aj;
        each[val].push(aj);
      }
    }
    long long int pq = 0;
long long int vec = 1;
long long int k = 1;
long long int c = 1;

    
    
    
    for(;1;) {
      // if can send serving
      bool pi = 1;
      vec = 1;
      for (int val = 0; val < n; ++val) {
        if (each[val].empty()) {
          pi = 0;
          break;
        }
        if (!inrange(val, each[val].top(), k)) {
          vec = 0;
        }
      }

      if (!pi) {
        break;
      }

      if (vec) {
        // cout << "Send\n";
        ++pq;
        for (int val = 0; val < n; ++val) {
          each[val].pop();
        }
      } else {
        // find next serving size to make
        c = 9999999999;
        for (int val = 0; val < n; ++val) {
          if (each[val].empty())
            break;
          c = min(c, each[val].top() / eleven(r[val]));
        }
        if (c <= k) {
          c = k + 1;
        }
        k = c;
        // flush
        for (int val = 0; val < n; ++val) {
          for(;!each[val].empty() && each[val].top() < ninety(r[val] * k);) {
            each[val].pop();
          }
          if (each[val].empty()) {
            pi = 0;
            break;
          }
        }
        if (!pi) {
          break;
        }
      }
    }
    cout << "Case #" << ht << ": " << pq << endl;
  }
return 0;}
