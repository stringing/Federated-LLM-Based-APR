#include <algorithm>
#include <bits/stdc++.h>
#include <cstdio>
#include <cstring>
#include <vector>
using namespace std;
int Ak;
int Hd, P;
long long int N[1009];

long long int eleven(long long int d) { return d * 11 / 10; }

long long int ninety(long long int d) {
  long long int tic = d * 9 / 10;
  if (d % 10 != 0) {
    tic += 1;
  }
  return tic;
}

bool inrange(int t, long long int C, long long int B) {
  long long int d = N[t] * B;
  return (ninety(d) <= C) && (C <= eleven(d));
}

int main() {
  scanf("%d",&Ak);
  for (int st = 1; st <= Ak; ++st) {
    long long int pro;
    priority_queue<long long int, vector<long long int>, greater<long long int>> a1[1009];
    memset(N, -1, sizeof(N));
    scanf("%d%d",&Hd,&P);
    for (int h2 = 0; h2 < Hd; ++h2) {
      cin >> N[h2];
    }
    for (int h2 = 0; h2 < Hd; ++h2) {
      for (int a2 = 0; a2 < P; ++a2) {
        cin >> pro;
        a1[h2].push(pro);
      }
    }
    long long int rid = 0;
    long long int ed = 1;
    long long int h1 = 1;
    long long int k2 = 1;
    for(;1;) {
      // if can send serving
      bool k = 1;
      ed = 1;
      for (int h2 = 0; h2 < Hd; ++h2) {
        if (a1[h2].empty()) {
          k = 0;
          break;
        }
        if (!inrange(h2, a1[h2].top(), h1)) {
          ed = 0;
        }
      }

      if (!k) {
        break;
      }

      if (ed) {
        // cout << "Send\n";
        ++rid;
        for (int h2 = 0; h2 < Hd; ++h2) {
          a1[h2].pop();
        }
      } else {
        // find next serving size to make
        k2 = 9999999999;
        for (int h2 = 0; h2 < Hd; ++h2) {
          if (a1[h2].empty())
            break;
          k2 = min(k2, a1[h2].top() / eleven(N[h2]));
        }
        if (k2 <= h1) {
          k2 = h1 + 1;
        }
        h1 = k2;
        // flush
        for (int h2 = 0; h2 < Hd; ++h2) {
          for(;!a1[h2].empty() && a1[h2].top() < ninety(N[h2] * h1);) {
            a1[h2].pop();
          }
          if (a1[h2].empty()) {
            k = 0;
            break;
          }
        }
        if (!k) {
          break;
        }
      }
    }
    cout << "Case #" << st << ": " << rid << endl;
  }
return 0;}
