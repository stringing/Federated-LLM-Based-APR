#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;

typedef pair<int, int> par;
typedef long long int tint;

int p;

long long int info;
long long int dp;
long long int c;
long long int EPS;

vector<pair<long long int, long long int>> k;

void split_main_43_45(vector<pair<long long int, long long int>>* k,int* ans,double* hi,long long int* info,bool* cnd) {
        if ((*k)[(*ans)].first / ((*hi) - (*k)[(*ans)].second) * (*hi) < (*info)) {
          (*cnd) = false;
        }
}
int main() {
  freopen("test.txt","r",stdin);
freopen("out.txt","w",stdout);
cin >> p;
  for (int lo = 1; lo <= p; lo++) {
    k.clear();
    cin >> info >> dp;
    double best = 0;
double j = 0;
double hi;

    for (int ans = 0; ans < dp; ans++) {
      cin >> c >> EPS;
      k.push_back((pair<long long int, long long int>)(c, EPS));
      if (j == 0) {
        if (c != info) {
          j = info * EPS / (info - c + 0.0);
        }
      } else if (c != info) {
        j = min(j, info * EPS / (info - c + 0.0));
      }
    }
    for(;abs(j - best) > 0.0000005f;) {
      hi = (j + best) / 2;
      bool cnd = true;
      // cout << "Testing " << ex << endl;
      for (int ans = 0; ans < dp; ans++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (k[ans].second >= hi)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        split_main_43_45(&k,&ans,&hi,&info,&cnd);

      }
      if (cnd) {
        best = hi;
      } else {
        j = hi;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << lo << ": " << j << endl;
  }
return 0;}
