#include <bits/stdc++.h>
#include <iostream>
#include <stdio.h>
using namespace std;

int chmin;

int main() {
  ios::sync_with_stdio(false);
cin >> chmin;
  for (int v = 1; v <= chmin; v++) {
    int b, c;
    scanf("%d%d",&b,&c);
    char cake[30][30];
    int N = 0; while (N < b)  {
      for (int ans = 0; ans < c; ans++) {
        cin >> cake[N][ans];
      }
    N++;
}
    for (int N = 0; N < b; N++) {
      // sweep left to right
      for (int ans = 1; ans < c; ans++) {
        if (cake[N][ans - 1] != '?' && cake[N][ans] == '?') {
          cake[N][ans] = cake[N][ans - 1];
        }
      }
      // sweep right to left
      for (int ans = c - 2; ans >= 0; ans--) {
        if (cake[N][ans + 1] != '?' && cake[N][ans] == '?') {
          cake[N][ans] = cake[N][ans + 1];
        }
      }
    }
    for (int N = 1; N < b; N++) {
      // sweep up to down
      if (cake[N - 1][0] != '?' && cake[N][0] == '?') {
        for (int ans = 0; ans < c; ans++) {
          cake[N][ans] = cake[N - 1][ans];
        }
      }
    }
    for (int N = b - 1; N >= 0; N--) {
      // sweep down to up
      if (cake[N + 1][0] != '?' && cake[N][0] == '?') {
        for (int ans = 0; ans < c; ans++) {
          cake[N][ans] = cake[N + 1][ans];
        }
      }
    }
    printf("Case #%d:\n",v);
    for (int N = 0; N < b; N++) {
      for (int ans = 0; ans < c; ans++) {
        cout << cake[N][ans];
      }
      cout << endl;
    }
  }
}
