#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;
typedef pair<int, int> par;
typedef long long int tint;

int act;
int dp, b;
long long int c[1009];

long long int eleven(long long int a) { return a * 11 / 10; }

long long int ninety(long long int a) {
  long long int info = a * 9 / 10;
  if (a % 10 != 0) {
    info += 1;
  }
  return info;
}

bool inrange(int k, long long int pan, long long int EPS) {
  long long int a = c[k] * EPS;
  return (ninety(a) <= pan) && (pan <= eleven(a));
}

int main() {
  freopen("test.txt","r",stdin);
freopen("out.txt","w",stdout);
cin >> act;
  for (int hi = 1; hi <= act; hi++) {
    
    
    memset(c, -1, sizeof(c));
    cin >> dp >> b;
    for (int cnd = 0; cnd < dp; cnd++) {
      cin >> c[cnd];
    }
    priority_queue<long long int, vector<long long int>, greater<long long int>> us[1009];long long int lambda;for (int cnd = 0; cnd < dp; cnd++) {
      for (int best = 0; best < b; best++) {
        cin >> lambda;
        us[cnd].push(lambda);
      }
    }
    long long int be = 0;
    long long int dif = 1;
    long long int lo = 1;
    long long int t = 1;
    for(;1;) {
      // if can send serving
      bool ma = 1;
      dif = 1;
      for (int cnd = 0; cnd < dp; cnd++) {
        if (us[cnd].empty()) {
          ma = 0;
          break;
        }
        if (!inrange(cnd, us[cnd].top(), lo)) {
          dif = 0;
        }
      }

      if (!ma) {
        break;
      }

      if (dif) {
        // cout << "Send\n";
        be++;
        for (int cnd = 0; cnd < dp; cnd++) {
          us[cnd].pop();
        }
      } else {
        // find next serving size to make
        t = 9999999999;
        for (int cnd = 0; cnd < dp; cnd++) {
          if (us[cnd].empty())
            break;
          t = min(t, us[cnd].top() / eleven(c[cnd]));
        }
        if (t <= lo) {
          t = lo + 1;
        }
        lo = t;
        // flush
        for (int cnd = 0; cnd < dp; cnd++) {
          for(;!us[cnd].empty() && us[cnd].top() < ninety(c[cnd] * lo);) {
            us[cnd].pop();
          }
          if (us[cnd].empty()) {
            ma = 0;
            break;
          }
        }
        if (!ma) {
          break;
        }
      }
    }
    cout << "Case #" << hi << ": " << be << endl;
  }
return 0;}
