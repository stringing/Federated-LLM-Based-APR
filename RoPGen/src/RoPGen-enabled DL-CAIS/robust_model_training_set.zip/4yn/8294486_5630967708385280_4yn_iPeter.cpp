#include <algorithm>
#include <bits/stdc++.h>
#include <cstdio>
#include <cstring>
#include <vector>
using namespace std;

int Hd;

long long int tic;
long long int N;
long long int P;
long long int B;

vector<pair<long long int, long long int>> t;

void split_main_43_45(vector<pair<long long int, long long int>>* t,int* ans,double* st,long long int* tic,bool* r) {
        if ((*t)[(*ans)].first / ((*st) - (*t)[(*ans)].second) * (*st) < (*tic)) {
          (*r) = false;
        }
}
int main() {
  scanf("%d",&Hd);
  for (int h2 = 1; h2 <= Hd; ++h2) {
    t.clear();
    cin >> tic >> N;
    double j = 0;
double x = 0;
double st;

    for (int ans = 0; ans < N; ++ans) {
      cin >> P >> B;
      t.push_back((pair<long long int, long long int>)(P, B));
      if (x == 0&&P != tic) {
        
          x = tic * B / (tic - P + 0.0);
        } else if (P != tic) {
        x = min(x, tic * B / (tic - P + 0.0));
      }
    }
    for(;abs(x - j) > 0.0000005f;) {
      st = (x + j) / 2;
      bool r = true;
      // cout << "Testing " << ex << endl;
      for (int ans = 0; ans < N; ++ans) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (t[ans].second >= st)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        split_main_43_45(&t,&ans,&st,&tic,&r);

      }
      if (r) {
        j = st;
      } else {
        x = st;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << h2 << ": " << x << endl;
  }
return 0;}
