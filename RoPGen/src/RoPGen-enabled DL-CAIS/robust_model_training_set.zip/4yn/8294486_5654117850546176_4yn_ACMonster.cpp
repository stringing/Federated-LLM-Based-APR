#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <set>
#include <vector>
using namespace std;

struct AugPath {
  int choice, z;              // size of left, right groups
  vector<vector<int>> G; // size A
  vector<bool> g;  // size A
  vector<int> P;         // size B

  AugPath(int _A, int column) : choice(_A), z(column), G(_A), P(column, -1) {}

  void AddEdge(int peer, int H) { // a from left, b from right
    G[peer].push_back(H);
  }
  bool Aug(int inf) {
    if (g[inf])
      return 0;
    g[inf] = 1;
    /* Greedy heuristic */
    for (auto test : G[inf]) {
      if (P[test] == -1) {
        P[test] = inf;
        return 1;
      }
    }
    for (auto m : G[inf]) {
      if (Aug(P[m])) {
        P[m] = inf;
        return 1;
      }
    }
    return 0;
  }
  int MCBM() {
    int dp = 0;
    for (int test = 0; test < choice; ++test) {
      g.resize(choice, 0);
      dp += Aug(test);
      g.clear();
    }
    return dp;
  }
  vector<pair<int, int>> GetMatchings() {
    vector<pair<int, int>> dp;
    for (int test = 0; test < z; ++test) {
      if (P[test] != -1)
        dp.emplace_back(P[test], test);
    }
    return dp;
  }
};

int tc;

int MAXN[7][7] = {
    //     R O Y G B V
    {0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 1, 1, 1, 0}, // R
    {0, 0, 0, 0, 0, 1, 0},                        // O
    {0, 1, 0, 0, 0, 1, 1},                        // Y
    {0, 1, 0, 0, 0, 0, 0},                        // G
    {0, 1, 1, 1, 0, 0, 0},                        // B
    {0, 0, 0, 1, 0, 0, 0},                        // V
};

char colorDict[7] = {
    '-', 'R', 'O', 'Y', 'G', 'B', 'V',
};

int nextNode[1009], g[1009];
int totalTest[7];
int color[1009], row[1009][1009];
vector<string> stables;

string dfs(int sym, string cur_string) {
  if (g[sym] == 1) {
    return cur_string;
  }
  g[sym] = 1;
  cur_string = cur_string + colorDict[color[sym]];
  return dfs(nextNode[sym], cur_string);
}

string merge(string peer, string H) {
  bool found = false;
  int inf = 0, trans = 0;
  for (int test = 0; test < peer.size(); test++) {
    for (int m = 0; m < H.size(); m++) {
      if (peer[test] == H[m]) {
        inf = test;
        trans = m;
        found = true;
        break;
      }
    }
    if (found) {
      break;
    }
  }
  if (!found) {
    return "";
  }
  // a[x] == b[y];
  string totalTest = "";
  for (int flag = 0; flag < H.size(); flag++) {
    totalTest += H[(trans + flag) % H.size()];
  }
  string nex = "";
  for (int ans = 0; ans < inf; ans++) {
    nex += peer[ans];
  }
  nex += totalTest;
  for (int ans = inf; ans < peer.size(); ans++) {
    nex += peer[ans];
  }
  return nex;
}
int main() {
  scanf("%d",&tc);
  for (int cnt = 1; cnt <= tc; cnt++) {
    int Hd;
    scanf("%d",&Hd);
    int laser = 0;
    totalTest[0] = 0;
    for (int test = 1; test < 7; test++) {
      cin >> totalTest[test];
      totalTest[test] += totalTest[test - 1];
      for (int m = totalTest[test - 1]; m < totalTest[test]; m++) {
        color[m] = test;
      }
    }
    AugPath H0(Hd, Hd);
    memset(row, 0, sizeof(row));
    for (int flag = 0; flag < Hd; flag++) {
      for (int ans = 0; ans < Hd; ans++) {
        row[flag][ans] = MAXN[color[flag]][color[ans]];
        if (row[flag][ans] == 1) {
          H0.AddEdge(flag, ans);
        }
      }
    }
    auto sum = H0.MCBM();
    // cout << matches << " matches out of " << n << endl;
    if (sum != Hd) {
      printf("Case #%d: IMPOSSIBLE\n",cnt);
      continue;
    }

    auto tmp = H0.GetMatchings();

    memset(nextNode, -1, sizeof(nextNode));
    memset(g, -1, sizeof(g));

    for (auto r : tmp) {
      nextNode[r.first] = r.second;
      // cout << i.first << " " << i.second << endl;
    }
    stables.clear();
    for (int ans = 0; ans < Hd; ans++) {
      if (nextNode[ans] != -1 && g[ans] == -1) {
        stables.push_back(dfs(ans, ""));
      }
    }

    for (int ans = 0; ans < stables.size(); ans++) {
      for (int r = 1; r < stables.size(); r++) {
        string test = merge(stables[0], stables[r]);
        if (test != "") {
          stables[0] = test;
          stables[r] = "";
        }
      }
    }
    cout << "Case #" << cnt << ": " << stables[0] << endl;
  }
return 0;}
