#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <stdio.h>
using namespace std;

typedef long long int lli;
typedef pair<lli, lli> pii;
typedef double dbl;

int tc;

lli d, y, a, b;
vector<pii> ks;

inline void work(dbl &ans) { ans = d * b / (d - a + 0.0); }

int main() {
  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_8294486_5630967708385280_15_CCS18_RNN_800_True_MCTS_Classic_True/SummerDAway/4yn/A-small-practice.in",
          "r", stdin);

  scanf("%d ", &tc);
  for (int TC = 1; TC <= tc; TC++) {
    ks.clear();
    scanf("%lld %lld ", &d, &y);
    dbl lb, ans, ex;
    lb = 0;
    ans = 0;
    {
      int i = 0;
      while (i < y) {
        scanf("%lld %lld ", &a, &b);
        ks.push_back(pii(a, b));
        if (ans == 0) {
          if (a != d)
            work(ans);
        } else if (a != d) {
          ans = min(ans, d * b / (d - a + 0.0));
        }
        i++;
      }
    }
    while (abs(ans - lb) > 0.0000005f) {
      ex = (ans + lb) / 2;
      bool f = true;
      // cout << "Testing " << ex << endl;
      {
        int i = 0;
        while (i < y) {
          // cout << "Horse " << i << " speed " << ks[i].second << endl;
          if (ks[i].second >= ex) {
            i++;
            continue;
          }
          // cout << "Comparative speed: " << ex - ks[i].second << endl;
          // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex
          // << endl;
          if (ks[i].first / (ex - ks[i].second) * ex < d)
            f = false;
          i++;
        }
      }
      if (f) {
        lb = ex;
      } else {
        ans = ex;
      }
    }
    printf("Case #%d: %.7f\n", TC, ans);
  }
}
