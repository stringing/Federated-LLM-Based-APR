#include <algorithm>
#include <bits/stdc++.h>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>
using namespace std;
typedef long long i64d;

int cas;

int main() {
  freopen("D-small-attempt2.in","r",stdin);
freopen("D-small-attempt2.out","w",stdout);
scanf("%d",&cas);
  for (int j = 1; j <= cas; j++) {
    
    int x;int p;
scanf("%d%d",&p,&x);
    priority_queue<int> b;
    b.push(p);
    int a, num;
    for (int res = 0; res < x; res++) {
      int j = b.top() - 1;
      b.pop();
      a = j / 2 + (j % 2);
      num = j / 2;
      b.push(a);
      b.push(num);
    }
    printf("Case #%d: %d %d\n", j, a, num);
  }
return 0;}
