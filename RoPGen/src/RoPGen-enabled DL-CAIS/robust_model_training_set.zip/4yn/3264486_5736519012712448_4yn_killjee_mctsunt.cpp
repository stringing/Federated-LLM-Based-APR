#include <bits/stdc++.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include <iostream>
using namespace std;
ofstream fout;
ifstream fin;

int tc;

int main() {
  fin.open("test.input.in");
fout.open("test.output.out");
fin >> tc;
  for (int t = 1; t <= tc; t++) {
    string s;
    int k, fl = 0;
    cin >> s >> k;
    for (int i = 0; i < s.size() - k + 1; i++) {
      if (s[i] == '-') {
        // cout << "Flip at " << i << endl;
        fl++;
        for (int j = i; j < i + k; j++) {
          if (s[j] == '-')
            s[j] = '+';
          else
            s[j] = '-';
        }
      }
    }
    int f = 1;
    for (int i = s.size() - k + 1; i < s.size(); i++) {
      if (s[i] == '-')
        f = 0;
    }
    if (f == 1) {
      fout<<"Case #"<<t<<": "<<fl<<"\n"<<endl;
    } else {
      printf("Case #%d: IMPOSSIBLE\n", t, fl);
    }
  }
}
