#include <bits/stdc++.h>
#include <iostream>
#include <unordered_map>
#include <unordered_set>
using namespace std;

int tc;

inline void ryvbgclmne(char cake[30][30], int &i, int &ccr) {
  cake[i][ccr] = cake[i][ccr + 1];
}

int main() {
  ios::sync_with_stdio(false);
  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    int r, ans;
    cin >> r >> ans;
    char cake[30][30];
    for (int i = 0; i < r; i++) {
      for (int ccr = 0; ccr < ans; ccr++) {
        cin >> cake[i][ccr];
      }
    }
    for (int i = 0; i < r; i++) {
      // sweep left to right
      int ccr;
      for (ccr = 1; ccr < ans; ccr++) {
        if (cake[i][ccr - 1] != '?' && cake[i][ccr] == '?')
          cake[i][ccr] = cake[i][ccr - 1];
      }
      // sweep right to left
      for (int ccr = ans - 2; ccr >= 0; ccr--) {
        if (cake[i][ccr + 1] != '?' && cake[i][ccr] == '?')
          ryvbgclmne(cake, i, ccr);
      }
    }
    for (int i = 1; i < r; i++) {
      // sweep up to down
      if (cake[i - 1][0] != '?' && cake[i][0] == '?') {
        for (int ccr = 0; ccr < ans; ccr++) {
          cake[i][ccr] = cake[i - 1][ccr];
        }
      }
    }
    for (int i = r - 1; i >= 0; i--) {
      // sweep down to up
      if (cake[i + 1][0] != '?' && cake[i][0] == '?') {
        for (int ccr = 0; ccr < ans; ccr++) {
          cake[i][ccr] = cake[i + 1][ccr];
        }
      }
    }
    cout << "Case #" << t << ":\n";
    for (int i = 0; i < r; i++) {
      for (int ccr = 0; ccr < ans; ccr++)
        cout << cake[i][ccr];

      cout << endl;
    }
  }
  return 0;
}
