#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
int Case;

long long int u;
long long int cnt;
long long int T;
long long int cas;

vector<pair<long long int, long long int>> t;

int main() {
  freopen("C-small-1-attempt0.in","r",stdin);
freopen("out0.out","w",stdout);
cin >> Case;
  for (int m = 1; m <= Case; m++) {
    t.clear();
    cin >> u >> cnt;
    double l = 0;
double x = 0;
double v;

    for (int r = 0; r < cnt; r++) {
      cin >> T >> cas;
      t.push_back((pair<long long int, long long int>)(T, cas));
      if (x == 0&&T != u) {
        
          x = u * cas / (u - T + 0.0);
        } else if (T != u) {
        x = min(x, u * cas / (u - T + 0.0));
      }
    }
    while (abs(x - l) > 0.0000005f) {
      v = (x + l) / 2;
      bool ans = true;
      // cout << "Testing " << ex << endl;
      for (int r = 0; r < cnt; r++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (t[r].second >= v)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (t[r].first / (v - t[r].second) * v < u) {
          ans = false;
        }
      }
      if (ans) {
        l = v;
      } else {
        x = v;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << m << ": " << x << endl;
  }
return 0;}
