#include <bits/stdc++.h>
#include <cmath>
#include <fstream>
#include <string>
using namespace std;

int fout;

void split_main_8_54(int* fout) {
  for (int max_r_n = 1; max_r_n <= (*fout); max_r_n++) {
    int max_ar_n;  int a_n;
    cin >> max_ar_n >> a_n;
    char score[30][30];
    for (int i = 0; i < max_ar_n; i++) {
      for (int ch = 0; ch < a_n; ch++) {
        cin >> score[i][ch];
      }
    }
    for (int i = 0; i < max_ar_n; i++) {
      // sweep left to right
      for (int ch = 1; ch < a_n; ch++) {
        if (score[i][ch - 1] != '?' && score[i][ch] == '?') {
          score[i][ch] = score[i][ch - 1];
        }
      }
      // sweep right to left
      for (int ch = a_n - 2; ch >= 0; ch--) {
        if (score[i][ch + 1] != '?' && score[i][ch] == '?') {
          score[i][ch] = score[i][ch + 1];
        }
      }
    }
    for (int i = 1; i < max_ar_n; i++) {
      // sweep up to down
      if (score[i - 1][0] != '?' && score[i][0] == '?') {
        for (int ch = 0; ch < a_n; ch++) {
          score[i][ch] = score[i - 1][ch];
        }
      }
    }
    for (int i = max_ar_n - 1; i >= 0; i--) {
      // sweep down to up
      if (score[i + 1][0] != '?' && score[i][0] == '?') {
        for (int ch = 0; ch < a_n; ch++) {
          score[i][ch] = score[i + 1][ch];
        }
      }
    }
    cout << "Case #" << max_r_n << ":\n";
    for (int i = 0; i < max_ar_n; i++) {
      for (int ch = 0; ch < a_n; ch++) {
        cout << score[i][ch];
      }
      cout << endl;
    }
  }
}
int main() {
  cin >> fout;
  split_main_8_54(&fout);

return 0;}
