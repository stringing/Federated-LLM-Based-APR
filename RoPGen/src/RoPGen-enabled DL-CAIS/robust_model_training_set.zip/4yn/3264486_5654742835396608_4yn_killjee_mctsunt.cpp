#include <bits/stdc++.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include <iostream>
using namespace std;
ofstream fout;
ifstream fin;
typedef std::pair<int, int> pi;
int tc;

int main() {
  fin.open("test.input.in");
fout.open("test.output.out");
cin >> tc;
  for (int t = 1; t <= tc; t++) {
    int n, k;
    fin >> n >> k;
    priority_queue<int> pq;
    pq.push(n);
    int y, z;
    for (int i = 0; i < k; i++) {
      int t = pq.top() - 1;
      pq.pop();
      y = t / 2 + (t % 2);
      z = t / 2;
      pq.push(y);
      pq.push(z);
    }
    fout<<"Case #"<<t<<": "<<y<<" "<<z<<"\n"<<endl;
  }
}
