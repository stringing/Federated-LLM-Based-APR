#include <bits/stdc++.h>
using namespace std;

int tc;

int main() {
  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_3264486_5736519012712448_15_CCS18_RNN_800_True_MCTS_Classic_True/jiian/4yn/A-small-practice.in", "r", stdin);

  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    string s;
    int ans, fl = 0;
    cin >> s >> ans;
    for (int i = 0; i < s.size() - ans + 1; i++) {
      if (s[i] == '-') {
        // cout << "Flip at " << i << endl;
        fl++;
        for (int cas = i; cas < i + ans; cas++) {
          if (s[cas] == '-')
            s[cas] = '+';
          else
            s[cas] = '-';
        }
      }
    }
    int f = 1;
    for (int i = s.size() - ans + 1; i < s.size(); i++) {
      if (s[i] == '-')
        f = 0;
    }
    if (f == 1) {
      printf("Case #%d: %d\n", t, fl);
    } else {
      printf("Case #%d: IMPOSSIBLE\n", t, fl);
    }
  }
}
