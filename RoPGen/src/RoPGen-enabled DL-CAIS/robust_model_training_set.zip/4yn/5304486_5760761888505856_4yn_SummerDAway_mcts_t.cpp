#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <stdio.h>

using namespace std;

int tc;

inline void xhjuiltvcm(char cake[30][30], int &work, int &j) {
  cake[work][j] = cake[work][j - 1];
}

int main() {

  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_5304486_5760761888505856_15_CCS18_RNN_800_True_MCTS_Classic_True/SummerDAway/4yn/outer_temp/4yn/A-small-practice_transformation.out",
          "w", stdout);

  cin >> tc;
  for (int b = 1; b <= tc; b++) {
    int r, TC;
    cin >> r >> TC;
    char cake[30][30];
    for (int work = 0; work < r; work++) {
      for (int j = 0; j < TC; j++)
        cin >> cake[work][j];
    }
    int work;
    for (work = 0; work < r; work++) {
      // sweep left to right
      for (int j = 1; j < TC; j++) {
        if (cake[work][j - 1] != '?' && cake[work][j] == '?')
          xhjuiltvcm(cake, work, j);
      }
      // sweep right to left
      for (int j = TC - 2; j >= 0; j--) {
        if (cake[work][j + 1] != '?' && cake[work][j] == '?') {
          cake[work][j] = cake[work][j + 1];
        }
      }
    }
    for (int work = 1; work < r; work++) {
      // sweep up to down
      if (cake[work - 1][0] != '?' && cake[work][0] == '?') {
        for (int j = 0; j < TC; j++) {
          cake[work][j] = cake[work - 1][j];
        }
      }
    }
    for (int work = r - 1; work >= 0; work--) {
      // sweep down to up
      if (cake[work + 1][0] != '?' && cake[work][0] == '?') {
        for (int j = 0; j < TC; j++) {
          cake[work][j] = cake[work + 1][j];
        }
      }
    }
    printf("Case #%d:\n", b);
    for (int work = 0; work < r; work++) {
      for (int j = 0; j < TC; j++)
        printf("%c", cake[work][j]);

      printf("\n");
    }
  }
  return 0;
}
