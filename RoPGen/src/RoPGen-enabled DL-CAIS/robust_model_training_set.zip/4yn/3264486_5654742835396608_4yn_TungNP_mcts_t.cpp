#include <bits/stdc++.h>
#include <fstream>
#include <string>
using namespace std;
ifstream fin;

typedef long long int lli;
typedef pair<lli, lli> pii;

int r;

int main() {
  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_3264486_5654742835396608_15_CCS18_RNN_800_True_MCTS_Classic_True/TungNP/4yn/outer_temp/4yn/A-small-practice_transformation.out",
          "w", stdout);

  fin.open("/home/hx/data/Mis/media/ramdisk/blackbox_3264486_5654742835396608_15_CCS18_RNN_800_True_MCTS_Classic_True/TungNP/4yn/A-small-practice.in");

  fin >> r;
  for (int t = 1; t <= r; t++) {
    int n, k;
    fin >> n >> k;
    priority_queue<int> pq;
    pq.push(n);
    int y, z;
    for (int i = 0; i < k; i++) {
      int t = pq.top() - 1;
      pq.pop();
      y = t / 2 + (t % 2);
      z = t / 2;
      pq.push(y);
      pq.push(z);
    }
    printf("Case #%d: %d %d\n", t, y, z);
  }
}
