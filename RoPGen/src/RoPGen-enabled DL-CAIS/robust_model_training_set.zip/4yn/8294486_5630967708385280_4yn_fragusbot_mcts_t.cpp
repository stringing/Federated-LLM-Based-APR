#include <algorithm>
#include <bits/std_abs.h>
#include <iomanip>
#include <iostream>
#include <memory>
#include <stdio.h>
#include <stdlib.h>
#include <utility>
#include <vector>

using namespace std;

typedef long long int lli;

typedef double dbl;

int cc;

lli d, tt, a, b;
vector<pair<lli, lli>> ks;

inline void oldchqpkib(dbl &lb, dbl &ex) { lb = ex; }

int main() {

  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_8294486_5630967708385280_15_CCS18_RNN_800_True_MCTS_Classic_True/fragusbot/4yn/outer_temp/4yn/A-small-practice_transformation.out",
          "w", stdout);

  scanf("%d ", &cc);
  for (int ans = 1; ans <= cc; ans++) {
    ks.clear();
    scanf("%lld %lld ", &d, &tt);
    dbl lb, ub, ex;
    lb = 0;
    ub = 0;
    int i;
    {
      i = 0;
      while (i < tt) {
        scanf("%lld %lld ", &a, &b);
        ks.push_back(pair<lli, lli>(a, b));
        if (ub == 0) {
          if (a != d) {
            ub = d * b / (d - a + 0.0);
          }
        } else {
          if (a != d) {
            ub = min(ub, d * b / (d - a + 0.0));
          }
        }
        i++;
      }
    }
    for (; abs(ub - lb) > 0.0000005f;) {
      ex = (ub + lb) / 2;
      int f = true;
      // cout << "Testing " << ex << endl;
      for (int i = 0; i < tt; i++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (ks[i].second >= ex)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (ks[i].first / (ex - ks[i].second) * ex < d)
          f = false;
      }
      if (f)
        oldchqpkib(lb, ex);
      else
        ub = ex;
    }
    cout << fixed << setprecision(7) << "Case #" << ans << ": " << ub << endl;
  }
}
