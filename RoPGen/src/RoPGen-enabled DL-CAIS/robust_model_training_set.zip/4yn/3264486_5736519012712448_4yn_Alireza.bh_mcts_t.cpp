#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <complex>
#include <cstdio>
#include <ctime>
#include <functional>
#include <list>
#include <map>
#include <set>
#include <utility>
#include <vector>
using namespace std;
typedef long double lld;
typedef pair<int, int> PII;
typedef vector<int> VI;

int tc;

int main() {
  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    string s;
    int res, fl = 0;
    cin >> s >> res;
    for (int i = 0; i < s.size() - res + 1; i++) {
      if (s[i] == '-') {
        // cout << "Flip at " << i << endl;
        fl++;
        for (int j = i; j < i + res; j++) {
          if (s[j] == '-')
            s[j] = '+';
          else
            s[j] = '-';
        }
      }
    }
    int f = 1;
    for (int i = s.size() - res + 1; i < s.size(); i++) {
      if (s[i] == '-')
        f = 0;
    }
    if (f == 1) {
      printf("Case #%d: %d\n", t, fl);
    } else {
      printf("Case #%d: IMPOSSIBLE\n", t, fl);
    }
  }
}
