#include <bits/stdc++.h>
#include <stdio.h>
using namespace std;

int solve;

void split_main_48_53(int* nbServs,int* K,char resary[30][30]) {
    for (int j2 = 0; j2 < (*nbServs); j2++) {
      for (int N = 0; N < (*K); N++) {
        cout << resary[j2][N];
      }
      printf("\n");
    }
}
int main() {
  scanf("%d",&solve);
  for (int R = 1; R <= solve; R++) {
    int nbServs, K;
    scanf("%d%d",&nbServs,&K);
    char res[30][30];
    for (int j2 = 0; j2 < nbServs; j2++) {
      for (int N = 0; N < K; N++) {
        cin >> res[j2][N];
      }
    }
    for (int j2 = 0; j2 < nbServs; j2++) {
      // sweep left to right
      for (int N = 1; N < K; N++) {
        if (res[j2][N - 1] != '?' && res[j2][N] == '?') {
          res[j2][N] = res[j2][N - 1];
        }
      }
      // sweep right to left
      for (int N = K - 2; N >= 0; N--) {
        if (res[j2][N + 1] != '?' && res[j2][N] == '?') {
          res[j2][N] = res[j2][N + 1];
        }
      }
    }
    for (int j2 = 1; j2 < nbServs; j2++) {
      // sweep up to down
      if (res[j2 - 1][0] != '?' && res[j2][0] == '?') {
        for (int N = 0; N < K; N++) {
          res[j2][N] = res[j2 - 1][N];
        }
      }
    }
    for (int j2 = nbServs - 1; j2 >= 0; j2--) {
      // sweep down to up
      if (res[j2 + 1][0] != '?' && res[j2][0] == '?') {
        for (int N = 0; N < K; N++) {
          res[j2][N] = res[j2 + 1][N];
        }
      }
    }
    printf("Case #%d:\n",R);
    split_main_48_53(&nbServs,&K,res);

  }
}
