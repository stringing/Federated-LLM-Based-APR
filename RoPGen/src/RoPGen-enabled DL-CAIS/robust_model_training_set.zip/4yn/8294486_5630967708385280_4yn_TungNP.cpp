#include <bits/stdc++.h>
#include <cmath>
#include <fstream>
#include <string>
using namespace std;

int argc;

long long int argv;  long long int fin;  long long int ar;  long long int T;
vector<pair<long long int, long long int>> fout;

void split_main_47_51(bool* ch,double* score,double* a_n,double* j) {
      if ((*ch)) {
        (*score) = (*a_n);
      } else {
        (*j) = (*a_n);
      }
}
int main() {
  cin >> argc;
  for (int i = 1; i <= argc; i++) {
    fout.clear();
    cin >> argv >> fin;
    double score = 0;  double j = 0;  double a_n;
    for (int c = 0; c < fin; c++) {
      cin >> ar >> T;
      fout.push_back((pair<long long int, long long int>)(ar, T));
      if (j == 0&&ar != argv) {
        
          j = argv * T / (argv - ar + 0.0);
        } else if (ar != argv) {
        j = min(j, argv * T / (argv - ar + 0.0));
      }
    }
    for(;abs(j - score) > 0.0000005f;) {
      a_n = (j + score) / 2;
      bool ch = true;
      // cout << "Testing " << ex << endl;
      for (int max_r_n = 0; max_r_n < fin; max_r_n++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (fout[max_r_n].second >= a_n)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (fout[max_r_n].first / (a_n - fout[max_r_n].second) * a_n < argv) {
          ch = false;
        }
      }
      split_main_47_51(&ch,&score,&a_n,&j);

    }
    cout << fixed << setprecision(7) << "Case #" << i << ": " << j << endl;
  }
return 0;}
