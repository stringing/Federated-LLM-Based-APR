#include <bits/stdc++.h>
#include <iomanip>
#include <iostream>
using namespace std;
const int MAXN = 1 * 1000 + 10;
typedef long long ll;
typedef pair<ll, ll> pii;

int tc;

int main() {

  cin >> tc;
  for (int tt = 1; tt <= tc; tt++) {
    int n, k;
    cin >> n >> k;
    priority_queue<int> pq;
    pq.push(n);
    int y, z;
    for (int i = 0; i < k; i++) {
      int tt = pq.top() - 1;
      pq.pop();
      y = tt / 2 + (tt % 2);
      z = tt / 2;
      pq.push(y);
      pq.push(z);
    }
    cout << "Case #" << tt << ": " << y << " " << z << "\n";
  }
  return 0;
}
