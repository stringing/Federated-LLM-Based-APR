#include <algorithm>
#include <bits/stdc++.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <set>
#include <vector>
using namespace std;

int tc;

int main() {
  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    int r, get;
    cin >> r >> get;
    char cake[30][30];
    for (int i = 0; i < r; i++) {
      for (int test = 0; test < get; test++) {
        cin >> cake[i][test];
      }
    }
    for (int i = 0; i < r; i++) {
      // sweep left to right
      for (int test = 1; test < get; test++) {
        if (cake[i][test - 1] != '?' && cake[i][test] == '?') {
          cake[i][test] = cake[i][test - 1];
        }
      }
      // sweep right to left
      for (int test = get - 2; test >= 0; test--) {
        if (cake[i][test + 1] != '?' && cake[i][test] == '?') {
          cake[i][test] = cake[i][test + 1];
        }
      }
    }
    for (int i = 1; i < r; i++) {
      // sweep up to down
      if (cake[i - 1][0] != '?' && cake[i][0] == '?') {
        for (int test = 0; test < get; test++) {
          cake[i][test] = cake[i - 1][test];
        }
      }
    }
    for (int i = r - 1; i >= 0; i--) {
      // sweep down to up
      if (cake[i + 1][0] != '?' && cake[i][0] == '?') {
        for (int test = 0; test < get; test++) {
          cake[i][test] = cake[i + 1][test];
        }
      }
    }
    cout << "Case #" << t << ":\n";
    for (int i = 0; i < r; i++) {
      for (int test = 0; test < get; test++) {
        cout << cake[i][test];
      }
      cout << endl;
    }
  }
}
