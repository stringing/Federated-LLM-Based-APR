#include <algorithm>
#include <bits/stdc++.h>
#include <float.h>
#include <iomanip>
#include <iostream>
#include <limits.h>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <vector>
using namespace std;
int tests;

int main() {
  cin >> tests;
  for (int i = 1; i <= tests; i++) {
    int K, j;
    cin >> K >> j;
    priority_queue<int> ci;
    ci.push(K);
    int N, di;
    for (int solution = 0; solution < j; solution++) {
      int i = ci.top() - 1;
      ci.pop();
      N = i / 2 + (i % 2);
      di = i / 2;
      ci.push(N);
      ci.push(di);
    }
    cout<<"Case #"<<i<<": "<<N<<" "<<di<<"\n"<<endl;
  }
}
