#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>
using namespace std;
typedef long long LL;
typedef long double LD;

int ac;
int k, cjl;
long long int aj[1009];

long long int eleven(long long int pi) { return pi * 11 / 10; }

long long int ninety(long long int pi) {
  long long int res = pi * 9 / 10;
  if (pi % 10 != 0) {
    res += 1;
  }
  return res;
}

bool inrange(int cond, long long int as, long long int t) {
  long long int pi = aj[cond] * t;
  return (ninety(pi) <= as) && (as <= eleven(pi));
}

int main() {
  cin >> ac;
  for (int pi = 1; pi <= ac; ++pi) {
    long long int cs;
    priority_queue<long long int, vector<long long int>, greater<long long int>> q[1009];
    memset(aj, -1, sizeof(aj));
    cin >> k >> cjl;
    for (int d = 0; d < k; ++d) {
      cin >> aj[d];
    }
    for (int c = 0; c < k; ++c) {
      for (int d = 0; d < cjl; ++d) {
        cin >> cs;
        q[c].push(cs);
      }
    }
    long long int rh = 0;
long long int a = 1;
long long int rhs = 1;
long long int nextservingsize = 1;

    
    
    
    for(;1;) {
      // if can send serving
      bool mu = 1;
      a = 1;
      for (int c = 0; c < k; ++c) {
        if (q[c].empty()) {
          mu = 0;
          break;
        }
        if (!inrange(c, q[c].top(), rhs)) {
          a = 0;
        }
      }

      if (!mu) {
        break;
      }

      if (a) {
        // cout << "Send\n";
        ++rh;
        for (int c = 0; c < k; ++c) {
          q[c].pop();
        }
      } else {
        // find next serving size to make
        nextservingsize = 9999999999;
        for (int c = 0; c < k; ++c) {
          if (q[c].empty())
            break;
          nextservingsize = min(nextservingsize, q[c].top() / eleven(aj[c]));
        }
        if (nextservingsize <= rhs) {
          nextservingsize = rhs + 1;
        }
        rhs = nextservingsize;
        // flush
        for (int c = 0; c < k; ++c) {
          for(;!q[c].empty() && q[c].top() < ninety(aj[c] * rhs);) {
            q[c].pop();
          }
          if (q[c].empty()) {
            mu = 0;
            break;
          }
        }
        if (!mu) {
          break;
        }
      }
    }
    cout << "Case #" << pi << ": " << rh << endl;
  }
return 0;}
