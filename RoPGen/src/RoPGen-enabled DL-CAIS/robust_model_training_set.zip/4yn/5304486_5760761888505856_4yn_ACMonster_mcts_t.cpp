#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <set>
#include <vector>
using namespace std;

int flag;

inline void rxovhzehde(char cake[30][30], int &get, int &m) {
  if (cake[get][m - 1] != '?' && cake[get][m] == '?') {
    cake[get][m] = cake[get][m - 1];
  }
}

int main() {

  cin >> flag;
  for (int test = 1; test <= flag; test++) {
    int r, c;
    cin >> r >> c;
    char cake[30][30];
    for (int get = 0; get < r; get++) {
      for (int m = 0; m < c; m++) {
        cin >> cake[get][m];
      }
    }
    for (int get = 0; get < r; get++) {
      // sweep left to right
      for (int m = 1; m < c; m++)
        rxovhzehde(cake, get, m);
      // sweep right to left
      for (int m = c - 2; m >= 0; m--) {
        if (cake[get][m + 1] != '?' && cake[get][m] == '?') {
          cake[get][m] = cake[get][m + 1];
        }
      }
    }
    for (int get = 1; get < r; get++) {
      // sweep up to down
      if (cake[get - 1][0] != '?')
        if (cake[get][0] == '?') {
          for (int m = 0; m < c; m++) {
            cake[get][m] = cake[get - 1][m];
          }
        }
    }
    for (int get = r - 1; get >= 0; get--) {
      // sweep down to up
      if (cake[get + 1][0] != '?' && cake[get][0] == '?') {
        for (int m = 0; m < c; m++) {
          cake[get][m] = cake[get + 1][m];
        }
      }
    }
    cout << "Case #" << test << ":\n";
    for (int get = 0; get < r; get++) {
      for (int m = 0; m < c; m++) {
        cout << cake[get][m];
      }
      cout << endl;
    }
  }
}
