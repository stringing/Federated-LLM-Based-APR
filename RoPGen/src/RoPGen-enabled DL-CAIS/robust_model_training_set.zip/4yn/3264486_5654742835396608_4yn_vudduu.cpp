#include <algorithm>
#include <bits/stdc++.h>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <functional>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string.h>
#include <string>
#include <utility>
#include <vector>
using namespace std;
typedef long long LL;

int T;

int main() {
  scanf("%d",&T);
  for (int _i = 1; _i <= T; ++_i) {
    int a, flag;
    scanf("%d%d",&a,&flag);
    priority_queue<int> b;
    b.push(a);
    int _cas, c;
    for (int cs = 0; cs < flag; ++cs) {
      int _i = b.top() - 1;
      b.pop();
      _cas = _i / 2 + (_i % 2);
      c = _i / 2;
      b.push(_cas);
      b.push(c);
    }
    printf("Case #%d: %d %d\n", _i, _cas, c);
  }
}
