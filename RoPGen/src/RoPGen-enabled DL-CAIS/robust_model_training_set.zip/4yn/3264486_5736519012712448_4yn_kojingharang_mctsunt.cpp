#include <bits/stdc++.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
using namespace std;
ifstream fin;

int bfs;

void split_main_29_33(int* d,int* ans,int* t1) {
    if ((*d) == 1) {
      printf("Case #%d: %d\n", (*ans), (*t1));
    } else {
      printf("Case #%d: IMPOSSIBLE\n", (*ans), (*t1));
    }
}
int main() {
  fin.open("test.input.in");
fin >> bfs;
  for (int ans = 1; ans <= bfs; ans++) {
    string v;
    int e, t1 = 0;
    fin >> v >> e;
    for (int i = 0; i < v.size() - e + 1; i++) {
      if (v[i] == '-') {
        // cout << "Flip at " << i << endl;
        t1++;
        for (int u = i; u < i + e; u++) {
          if (v[u] == '-')
            v[u] = '+';
          else
            v[u] = '-';
        }
      }
    }
    int d = 1;
    for (int i = v.size() - e + 1; i < v.size(); i++) {
      if (v[i] == '-')
        d = 0;
    }
    split_main_29_33(&d,&ans,&t1);

  }
}
