#include <bits/stdc++.h>
#include <cmath>
#include <fstream>
#include <string>
using namespace std;
int removei;
int argv;  int fin;
long long int r[1009];

long long int eleven(long long int fout) { return fout * 11 / 10; }

long long int ninety(long long int fout) {
  long long int T = fout * 9 / 10;
  if (fout % 10 != 0) {
    T += 1;
  }
  return T;
}

bool inrange(int argc, long long int N, long long int ar) {
  long long int fout = r[argc] * ar;
  return (ninety(fout) <= N) && (N <= eleven(fout));
}

int main() {
  cin >> removei;
  for (int max_r_n = 1; max_r_n <= removei; max_r_n++) {
    long long int a_n;
    priority_queue<long long int, vector<long long int>, greater<long long int>> q[1009];
    memset(r, -1, sizeof(r));
    cin >> argv >> fin;
    for (int c = 0; c < argv; c++) {
      cin >> r[c];
    }
    for (int r = 0; r < argv; r++) {
      for (int ch = 0; ch < fin; ch++) {
        cin >> a_n;
        q[r].push(a_n);
      }
    }
    long long int M = 0;
    long long int max_ar_n = 1;
    long long int curservingsize = 1;
    long long int nextservingsize = 1;
    for(;1;) {
      // if can send serving
      bool buff = 1;
      max_ar_n = 1;
      for (int score = 0; score < argv; score++) {
        if (q[score].empty()) {
          buff = 0;
          break;
        }
        if (!inrange(score, q[score].top(), curservingsize)) {
          max_ar_n = 0;
        }
      }

      if (!buff) {
        break;
      }

      if (max_ar_n) {
        // cout << "Send\n";
        M++;
        for (int ch = 0; ch < argv; ch++) {
          q[ch].pop();
        }
      } else {
        // find next serving size to make
        nextservingsize = 9999999999;
        for (int ch = 0; ch < argv; ch++) {
          if (q[ch].empty())
            break;
          nextservingsize = min(nextservingsize, q[ch].top() / eleven(r[ch]));
        }
        if (nextservingsize <= curservingsize) {
          nextservingsize = curservingsize + 1;
        }
        curservingsize = nextservingsize;
        // flush
        for (int ch = 0; ch < argv; ch++) {
          for(;!q[ch].empty() && q[ch].top() < ninety(r[ch] * curservingsize);) {
            q[ch].pop();
          }
          if (q[ch].empty()) {
            buff = 0;
            break;
          }
        }
        if (!buff) {
          break;
        }
      }
    }
    cout << "Case #" << max_r_n << ": " << M << endl;
  }
return 0;}
