#include <bits/stdc++.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
using namespace std;
ifstream fin;
typedef long long int lli;
typedef pair<lli, lli> pii;

int solve;

int main() {
  fin.open("test.input.in");
fin >> solve;
  for (int t = 1; t <= solve; t++) {
    int n, k;
    fin >> n >> k;
    priority_queue<int> pq;
    pq.push(n);
    int y, z;
    for (int i = 0; i < k; i++) {
      int t = pq.top() - 1;
      pq.pop();
      y = t / 2 + (t % 2);
      z = t / 2;
      pq.push(y);
      pq.push(z);
    }
    printf("Case #%d: %d %d\n", t, y, z);
  }
}
