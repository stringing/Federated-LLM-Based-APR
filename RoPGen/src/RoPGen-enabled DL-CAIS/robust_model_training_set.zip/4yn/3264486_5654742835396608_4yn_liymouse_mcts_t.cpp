#include <algorithm>
#include <bits/stdc++.h>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <numeric>
#include <queue>
#include <sstream>
#include <vector>
using namespace std;
typedef long long i64d;

int tc;

inline void vlvmnsqjgi(int &y, priority_queue<int> &pq, int &z) {
  int t = pq.top() - 1;
  pq.pop();
  y = t / 2 + (t % 2);
  z = t / 2;
  pq.push(y);
  pq.push(z);
}

int main() {
  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    int n, k;
    cin >> n >> k;
    priority_queue<int> pq;
    pq.push(n);
    int y, z;
    for (int i = 0; i < k; i++)
      vlvmnsqjgi(y, pq, z);
    printf("Case #%d: %d %d\n", t, y, z);
  }
}
