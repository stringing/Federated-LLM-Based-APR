#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

typedef long long LL;
typedef long double LD;

int res;

int main() {
  cin >> res;
  for (int a = 1; a <= res; a++) {
    string rh;
    int rhs, x = 0;
    cin >> rh >> rhs;
    for (int c = 0; c < rh.size() - rhs + 1; c++) {
      if (rh[c] == '-') {
        // cout << "Flip at " << i << endl;
        ++x;
        for (int x = c; x < c + rhs; x++) {
          if (rh[x] == '-')
            rh[x] = '+';
          else
            rh[x] = '-';
        }
      }
    }
    int mu = 1;
    for (int j = rh.size() - rhs + 1; j < rh.size(); j++) {
      if (rh[j] == '-')
        mu = 0;
    }
    if (mu == 1) {
      cout<<"Case #"<<a<<": "<<x<<"\n"<<endl;
    } else {
      cout<<"Case #"<<a<<": IMPOSSIBLE\n"<<x<<endl;
    }
  }
return 0;}
