#include <algorithm>
#include <bits/stdc++.h>
#include <cstdio>
#include <cstring>
#include <vector>
using namespace std;

int d;

int main() {
  scanf("%d",&d);
  for (int pro = 1; pro <= d; pro++) {
    string ok;
    int x, k2 = 0;
    cin >> ok >> x;
    for (int tt = 0; tt < ok.size() - x + 1; tt++) {
      if (ok[tt] == '-') {
        // cout << "Flip at " << i << endl;
        ++k2;
        for (int r = tt; r < tt + x; r++) {
          if (ok[r] == '-')
            ok[r] = '+';
          else
            ok[r] = '-';
        }
      }
    }
    int ans = 1;
    for (int tt = ok.size() - x + 1; tt < ok.size(); tt++) {
      if (ok[tt] == '-')
        ans = 0;
    }
    if (ans == 1) {
      printf("Case #%d: %d\n", pro, k2);
    } else {
      printf("Case #%d: IMPOSSIBLE\n", pro, k2);
    }
  }
return 0;}
