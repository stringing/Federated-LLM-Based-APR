#include <algorithm>
#include <assert.h>
#include <bits/stdc++.h>
#include <iostream>
#include <map>
#include <queue>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;
typedef long long int lli;
typedef pair<lli, lli> pii;

int tc;

int main() {
  cin >> tc;
  {
    int t = 1;
    while (t <= tc) {
      int n, testCase;
      cin >> n >> testCase;
      priority_queue<int> pq;
      pq.push(n);
      int y, z;
      {
        int i = 0;
        while (i < testCase) {
          int t = pq.top() - 1;
          pq.pop();
          y = t / 2 + (t % 2);
          z = t / 2;
          pq.push(y);
          pq.push(z);
          i++;
        }
      }
      printf("Case #%d: %d %d\n", t, y, z);
      t++;
    }
  }
}
