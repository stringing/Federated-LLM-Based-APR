#include <bits/stdc++.h>
#include <iostream>
#include <unordered_map>
#include <unordered_set>
using namespace std;
int t;

int main() {
  ios_base::sync_with_stdio(false);
freopen("inp3.txt","r",stdin);
freopen("out3.txt","w",stdout);
cin >> t;
  for (int val = 1; val <= t; ++val) {
    int pi, j;
    cin >> pi >> j;
    priority_queue<int> aj;
    aj.push(pi);
    int ans, vec;
    for (int newTot = 0; newTot < j; ++newTot) {
      int val = aj.top() - 1;
      aj.pop();
      ans = val / 2 + (val % 2);
      vec = val / 2;
      aj.push(ans);
      aj.push(vec);
    }
    cout<<"Case #"<<val<<": "<<ans<<" "<<vec<<"\n"<<endl;
  }
return 0;}
