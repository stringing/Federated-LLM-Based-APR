#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <vector>
using namespace std;

typedef long long ll;
int t;

int main() {
  ios::sync_with_stdio(false);
freopen("test.txt","r",stdin);
freopen("test1.txt","w",stdout);
cin >> t;
  for (int i = 1; i <= t; i++) {
    string cur;
    int av, x = 0;
    cin >> cur >> av;
    for (int j = 0; j < cur.size() - av + 1; j++) {
      if (cur[j] == '-') {
        // cout << "Flip at " << i << endl;
        x++;
        for (int b = j; b < j + av; b++) {
          if (cur[b] == '-')
            cur[b] = '+';
          else
            cur[b] = '-';
        }
      }
    }
    int curMax = 1;
    for (int b = cur.size() - av + 1; b < cur.size(); b++) {
      if (cur[b] == '-')
        curMax = 0;
    }
    if (curMax == 1) {
      cout<<"Case #"<<i<<": "<<x<<"\n"<<endl;
    } else {
      cout<<"Case #"<<i<<": IMPOSSIBLE\n"<<x<<endl;
    }
  }
}
