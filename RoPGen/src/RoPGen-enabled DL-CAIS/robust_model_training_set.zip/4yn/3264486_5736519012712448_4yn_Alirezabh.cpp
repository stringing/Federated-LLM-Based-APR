#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>
using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef long double lld;
typedef pair<int, int> PII;
typedef pair<ll, ll> PLL;
typedef vector<int> VI;
typedef vector<string> VS;
typedef vector<double> VD;

int Tcase;

int main() {
  freopen("a.in","r",stdin);
freopen("a.out","w",stdout);
cin >> Tcase;
  for (int ticket = 1; ticket <= Tcase; ticket++) {
    
    
    string p;int newCurrentParent;
cin >> p >> newCurrentParent;
    int n = 0;for (int cas = 0; cas < p.size() - newCurrentParent + 1; cas++) {
      if (p[cas] == '-') {
        // cout << "Flip at " << i << endl;
        n++;
        for (int newCameronTime = cas; newCameronTime < cas + newCurrentParent; newCameronTime++) {
          if (p[newCameronTime] == '-')
            p[newCameronTime] = '+';
          else
            p[newCameronTime] = '-';
        }
      }
    }
    int v = 1;
    for (int cas = p.size() - newCurrentParent + 1; cas < p.size(); cas++) {
      if (p[cas] == '-')
        v = 0;
    }
    if (v == 1) {
      cout<<"Case #"<<ticket<<": "<<n<<"\n"<<endl;
    } else {
      cout<<"Case #"<<ticket<<": IMPOSSIBLE\n"<<n<<endl;
    }
  }
}
