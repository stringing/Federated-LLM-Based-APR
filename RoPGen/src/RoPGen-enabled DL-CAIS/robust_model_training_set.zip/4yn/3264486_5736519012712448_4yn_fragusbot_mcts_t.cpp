#include <bits/stdc++.h>
using namespace std;

int tc;

inline void dvvhqourpv(std::__cxx11::string &cc, int &pqhi_Var) {
  if (cc[pqhi_Var] == '-')
    cc[pqhi_Var] = '+';
  else
    cc[pqhi_Var] = '-';
}

int main() {
  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_3264486_5736519012712448_15_CCS18_RNN_800_True_MCTS_Classic_True/fragusbot/4yn/A-small-practice.in",
          "r", stdin);

  cin >> tc;
  for (int ans = 1; ans <= tc; ans++) {
    string cc;
    int tt, fl = 0;
    cin >> cc >> tt;
    for (int i = 0; i < cc.size() - tt + 1; i++) {
      if (cc[i] == '-') {
        // cout << "Flip at " << i << endl;
        fl++;
        for (int pqhi_Var = i; pqhi_Var < i + tt; pqhi_Var++)
          dvvhqourpv(cc, pqhi_Var);
      }
    }
    int f = 1;
    for (int i = cc.size() - tt + 1; i < cc.size(); i++) {
      if (cc[i] == '-')
        f = 0;
    }
    if (f == 1) {
      printf("Case #%d: %d\n", ans, fl);
    } else {
      printf("Case #%d: IMPOSSIBLE\n", ans, fl);
    }
  }
}
