#include <bits/stdc++.h>
#include <fstream>
#include <iostream>
#include <utility>
using namespace std;
ofstream fout;

typedef pair<int, int> pii;
typedef long long ll;

int tc;
int n, p;
ll r[1009];

ll eleven(ll x) { return x * 11 / 10; }

ll ninety(ll x) {
  ll k = x * 9 / 10;
  if (x % 10 != 0) {
    k += 1;
  }
  return k;
}

bool inrange(int ingredient, ll number, ll servings) {
  ll x = r[ingredient] * servings;
  return (ninety(x) <= number) && (number <= eleven(x));
}

inline void rgrilgkpbj(priority_queue<ll, vector<ll>, greater<ll>> q[1009],
                       int &i) {
  q[i].pop();
}

int main() {
  ios::sync_with_stdio(false);

  fout.open("/home/hx/data/Mis/media/ramdisk/blackbox_5304486_5697460110360576_15_CCS18_RNN_800_True_MCTS_Classic_True/ShayanH/4yn/outer_temp/4yn/A-small-practice_transformation.out");

  cin >> tc;
  for (int tt = 1; tt <= tc; tt++) {
    ll tmp;
    priority_queue<ll, vector<ll>, greater<ll>> q[1009];
    memset(r, -1, sizeof(r));
    cin >> n >> p;
    for (int i = 0; i < n; i++)
      cin >> r[i];

    int i;
    for (i = 0; i < n; i++) {
      for (int j = 0; j < p; j++) {
        cin >> tmp;
        q[i].push(tmp);
      }
    }
    ll ans = 0;
    ll cansendserving = 1;
    ll curservingsize = 1;
    ll nextservingsize = 1;
    for (; true;) {
      // if can send serving
      bool okay = 1;
      cansendserving = 1;

      for (int i = 0; i < n; i++) {
        if (q[i].empty()) {
          okay = 0;
          break;
        }
        if (!inrange(i, q[i].top(), curservingsize)) {
          cansendserving = 0;
        }
      }

      if (!okay) {
        break;
      }

      if (cansendserving) {
        // cout << "Send\n";
        ans++;
        for (int i = 0; i < n; i++)
          q[i].pop();

      } else {
        // find next serving size to make
        nextservingsize = 9999999999;
        for (int i = 0; i < n; i++) {
          if (q[i].empty())
            break;
          nextservingsize = min(nextservingsize, q[i].top() / eleven(r[i]));
        }
        if (nextservingsize <= curservingsize) {
          nextservingsize = curservingsize + 1;
        }
        curservingsize = nextservingsize;
        // flush
        for (int i = 0; i < n; i++) {
          while (!q[i].empty() && q[i].top() < ninety(r[i] * curservingsize))
            rgrilgkpbj(q, i);
          if (q[i].empty()) {
            okay = 0;
            break;
          }
        }
        if (!okay) {
          break;
        }
      }
    }
    fout << "Case #" << tt << ": " << ans << endl;
  }
}
