#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstring>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <regex>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <tuple>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>
using namespace std;

int row;

long long int ifs;
long long int col;
long long int d2;
long long int d1;

vector<pair<long long int, long long int>> t;

void split_main_43_45(vector<pair<long long int, long long int>>* t,int* ofs,double* k,long long int* ifs,bool* newd) {
        if ((*t)[(*ofs)].first / ((*k) - (*t)[(*ofs)].second) * (*k) < (*ifs)) {
          (*newd) = false;
        }
}
int main() {
  ios_base::sync_with_stdio(false);
cin >> row;
  for (int test = 1; test <= row; ++test) {
    t.clear();
    cin >> ifs >> col;
    double y = 0;
double bs = 0;
double k;

    for (int j = 0; j < col; ++j) {
      cin >> d2 >> d1;
      t.push_back((pair<long long int, long long int>)(d2, d1));
      if (bs == 0&&d2 != ifs) {
        
          bs = ifs * d1 / (ifs - d2 + 0.0);
        } else if (d2 != ifs) {
        bs = min(bs, ifs * d1 / (ifs - d2 + 0.0));
      }
    }
    for(;abs(bs - y) > 0.0000005f;) {
      k = (bs + y) / 2;
      bool newd = true;
      // cout << "Testing " << ex << endl;
      for (int v = 0; v < col; ++v) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (t[v].second >= k)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        split_main_43_45(&t,&v,&k,&ifs,&newd);

      }
      if (newd) {
        y = k;
      } else {
        bs = k;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << test << ": " << bs << endl;
  }
return 0;}
