#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <iomanip>
#include <iostream>
#include <queue>
#include <set>
#include <stack>
#include <vector>
using namespace std;
typedef long long ll;

int a;

int main() {
  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_5304486_5760761888505856_15_CCS18_RNN_800_True_MCTS_Classic_True/thatprogrammer/4yn/outer_temp/4yn/A-small-practice_transformation.out", "w", stdout);

  cin >> a;
  for (int t = 1; t <= a; t++) {
    int r, b;
    cin >> r >> b;
    char cake[30][30];
    for (int i = 0; i < r; i++) {
      for (int j = 0; j < b; j++) {
        cin >> cake[i][j];
      }
    }
    for (int i = 0; i < r; i++) {
      // sweep left to right
      for (int j = 1; j < b; j++) {
        if (cake[i][j - 1] != '?' && cake[i][j] == '?') {
          cake[i][j] = cake[i][j - 1];
        }
      }
      // sweep right to left
      for (int j = b - 2; j >= 0; j--) {
        if (cake[i][j + 1] != '?' && cake[i][j] == '?') {
          cake[i][j] = cake[i][j + 1];
        }
      }
    }
    for (int i = 1; i < r; i++) {
      // sweep up to down
      if (cake[i - 1][0] != '?' && cake[i][0] == '?') {
        for (int j = 0; j < b; j++) {
          cake[i][j] = cake[i - 1][j];
        }
      }
    }
    for (int i = r - 1; i >= 0; i--) {
      // sweep down to up
      if (cake[i + 1][0] != '?' && cake[i][0] == '?') {
        for (int j = 0; j < b; j++) {
          cake[i][j] = cake[i + 1][j];
        }
      }
    }
    cout << "Case #" << t << ":\n";
    for (int i = 0; i < r; i++) {
      for (int j = 0; j < b; j++) {
        cout << cake[i][j];
      }
      cout << endl;
    }
  }
}
