#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <set>
#include <vector>
using namespace std;

int g;

long long int dp;
long long int H;
long long int peer;
long long int A;

vector<pair<long long int, long long int>> totalTest;

int main() {
  scanf("%d",&g);
  for (int test = 1; test <= g; test++) {
    totalTest.clear();
    cin >> dp >> H;
    double c = 0;
double j = 0;
double m;

    for (int i = 0; i < H; i++) {
      cin >> peer >> A;
      totalTest.push_back((pair<long long int, long long int>)(peer, A));
      if (j == 0&&peer != dp) {
        
          j = dp * A / (dp - peer + 0.0);
        } else if (peer != dp) {
        j = min(j, dp * A / (dp - peer + 0.0));
      }
    }
    for(;abs(j - c) > 0.0000005f;) {
      m = (j + c) / 2;
      bool y = true;
      // cout << "Testing " << ex << endl;
      for (int ans = 0; ans < H; ans++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (totalTest[ans].second >= m)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (totalTest[ans].first / (m - totalTest[ans].second) * m < dp) {
          y = false;
        }
      }
      if (y) {
        c = m;
      } else {
        j = m;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << test << ": " << j << endl;
  }
return 0;}
