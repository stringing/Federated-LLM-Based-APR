#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <set>
#include <vector>
using namespace std;

int totalTest;

void split_main_8_54(int* totalTest) {
  for (int test = 1; test <= (*totalTest); test++) {
    int tmp, m;
    scanf("%d%d",&tmp,&m);
    char n[30][30];
    for (int a = 0; a < tmp; a++) {
      for (int flag = 0; flag < m; flag++) {
        cin >> n[a][flag];
      }
    }
    for (int ans = 0; ans < tmp; ans++) {
      // sweep left to right
      for (int y = 1; y < m; y++) {
        if (n[ans][y - 1] != '?' && n[ans][y] == '?') {
          n[ans][y] = n[ans][y - 1];
        }
      }
      // sweep right to left
      for (int y = m - 2; y >= 0; y--) {
        if (n[ans][y + 1] != '?' && n[ans][y] == '?') {
          n[ans][y] = n[ans][y + 1];
        }
      }
    }
    for (int ans = 1; ans < tmp; ans++) {
      // sweep up to down
      if (n[ans - 1][0] != '?' && n[ans][0] == '?') {
        for (int y = 0; y < m; y++) {
          n[ans][y] = n[ans - 1][y];
        }
      }
    }
    for (int ans = tmp - 1; ans >= 0; ans--) {
      // sweep down to up
      if (n[ans + 1][0] != '?' && n[ans][0] == '?') {
        for (int y = 0; y < m; y++) {
          n[ans][y] = n[ans + 1][y];
        }
      }
    }
    printf("Case #%d:\n",test);
    for (int ans = 0; ans < tmp; ans++) {
      for (int y = 0; y < m; y++) {
        cout << n[ans][y];
      }
      printf("\n");
    }
  }
}
int main() {
  scanf("%d",&totalTest);
  split_main_8_54(&totalTest);

return 0;}
