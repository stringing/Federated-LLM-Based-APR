#include <algorithm>
#include <bits/stdc++.h>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <functional>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string.h>
#include <string>
#include <utility>
#include <vector>
using namespace std;

typedef long long LL;

int T;

int main() {
  scanf("%d",&T);
  for (int a = 1; a <= T; a++) {
    string cs;
    int b, cas = 0;
    cin >> cs >> b;
    for (int _i = 0; _i < cs.size() - b + 1; _i++) {
      if (cs[_i] == '-') {
        // cout << "Flip at " << i << endl;
        ++cas;
        for (int cas = _i; cas < _i + b; cas++) {
          if (cs[cas] == '-')
            cs[cas] = '+';
          else
            cs[cas] = '-';
        }
      }
    }
    int flag = 1;
    for (int i = cs.size() - b + 1; i < cs.size(); i++) {
      if (cs[i] == '-')
        flag = 0;
    }
    if (flag == 1) {
      printf("Case #%d: %d\n", a, cas);
    } else {
      printf("Case #%d: IMPOSSIBLE\n", a, cas);
    }
  }
}
