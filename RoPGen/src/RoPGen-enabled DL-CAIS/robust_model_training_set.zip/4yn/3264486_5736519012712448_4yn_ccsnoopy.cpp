#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef long long LL;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<int> vi;
int idx;

int main() {
  freopen("D:/OneDrive/Code/GCJ/B-small-attempt0(3).in","r",stdin);
freopen("D:/OneDrive/Code/GCJ/out.txt","w",stdout);
scanf("%d",&idx);
  for (int x = 1; x <= idx; x++) {
    string c;
    int ctr, y = 0;
    cin >> c >> ctr;
    for (int ct = 0; ct < c.size() - ctr + 1; ct++) {
      if (c[ct] == '-') {
        // cout << "Flip at " << i << endl;
        y++;
        for (int found = ct; found < ct + ctr; found++) {
          if (c[found] == '-')
            c[found] = '+';
          else
            c[found] = '-';
        }
      }
    }
    int tot = 1;
    for (int ct = c.size() - ctr + 1; ct < c.size(); ct++) {
      if (c[ct] == '-')
        tot = 0;
    }
    if (tot == 1) {
      printf("Case #%d: %d\n", x, y);
    } else {
      printf("Case #%d: IMPOSSIBLE\n", x, y);
    }
  }
return 0;}
