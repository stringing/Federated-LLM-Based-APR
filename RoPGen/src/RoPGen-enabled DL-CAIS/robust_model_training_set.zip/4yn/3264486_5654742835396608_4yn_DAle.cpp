#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstring>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <regex>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <tuple>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>
using namespace std;
int ifs;

int main() {
  ios_base::sync_with_stdio(false);
cin >> ifs;
  for (int test = 1; test <= ifs; ++test) {
    int m, bs;
    cin >> m >> bs;
    priority_queue<int> newd;
    newd.push(m);
    int j, v;
    for (int i = 0; i < bs; ++i) {
      int test = newd.top() - 1;
      newd.pop();
      j = test / 2 + (test % 2);
      v = test / 2;
      newd.push(j);
      newd.push(v);
    }
    cout<<"Case #"<<test<<": "<<j<<" "<<v<<"\n"<<endl;
  }
return 0;}
