#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <vector>
using namespace std;
ofstream fout;

int tc;

inline void iknuanveeb(char cake[30][30], int &i, int &j) { cin >> cake[i][j]; }

int main() {
  ios::sync_with_stdio(false);

  fout.open("/home/hx/data/Mis/media/ramdisk/blackbox_5304486_5760761888505856_16_CCS18_RNN_800_True_MCTS_Classic_True/eugenus/4yn/outer_temp/4yn/A-small-practice_transformation.out");

  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    int r, c;
    cin >> r >> c;
    char cake[30][30];
    for (int i = 0; i < r; i++) {
      for (int j = 0; j < c; j++)
        iknuanveeb(cake, i, j);
    }
    for (int i = 0; i < r; i++) {
      // sweep left to right
      for (int j = 1; j < c; j++) {
        if (cake[i][j - 1] != '?' && cake[i][j] == '?') {
          cake[i][j] = cake[i][j - 1];
        }
      }
      // sweep right to left
      for (int j = c - 2; j >= 0; j--) {
        if (cake[i][j + 1] != '?' && cake[i][j] == '?') {
          cake[i][j] = cake[i][j + 1];
        }
      }
    }
    int i;
    for (i = 1; i < r; i++) {
      // sweep up to down
      if (cake[i - 1][0] != '?' && cake[i][0] == '?') {
        for (int j = 0; j < c; j++) {
          cake[i][j] = cake[i - 1][j];
        }
      }
    }
    {
      int i = r - 1;
      while (i >= 0) {
        // sweep down to up
        if (cake[i + 1][0] != '?' && cake[i][0] == '?') {
          for (int j = 0; j < c; j++) {
            cake[i][j] = cake[i + 1][j];
          }
        }
        i--;
      }
    }
    fout << "Case #" << t << ":\n";
    for (int i = 0; i < r; i++) {
      for (int j = 0; j < c; j++) {
        fout << cake[i][j];
      }
      fout << endl;
    }
  }
}
