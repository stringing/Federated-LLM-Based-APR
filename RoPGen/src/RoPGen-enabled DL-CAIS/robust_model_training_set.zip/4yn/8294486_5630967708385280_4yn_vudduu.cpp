#include <algorithm>
#include <bits/stdc++.h>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <functional>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string.h>
#include <string>
#include <utility>
#include <vector>
using namespace std;

typedef long long LL;

int t;

long long int v;
long long int p;
long long int it;
long long int aux;

vector<pair<long long int, long long int>> T;

int main() {
  scanf("%d",&t);
  for (int c = 1; c <= t; ++c) {
    T.clear();
    cin >> v >> p;
    double cs = 0;
double _cas = 0;
double ex;

    for (int _i = 0; _i < p; ++_i) {
      cin >> it >> aux;
      T.push_back((pair<long long int, long long int>)(it, aux));
      if (_cas == 0) {
        if (it != v) {
          _cas = v * aux / (v - it + 0.0);
        }
      } else if (it != v) {
        _cas = min(_cas, v * aux / (v - it + 0.0));
      }
    }
    for(;abs(_cas - cs) > 0.0000005f;) {
      ex = (_cas + cs) / 2;
      bool flag = true;
      // cout << "Testing " << ex << endl;
      for (int _i = 0; _i < p; ++_i) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (T[_i].second >= ex)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (T[_i].first / (ex - T[_i].second) * ex < v) {
          flag = false;
        }
      }
      if (flag) {
        cs = ex;
      } else {
        _cas = ex;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << c << ": " << _cas << endl;
  }
}
