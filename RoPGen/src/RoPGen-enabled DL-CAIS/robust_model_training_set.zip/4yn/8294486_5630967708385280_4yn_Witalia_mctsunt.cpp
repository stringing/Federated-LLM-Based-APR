#include <bits/stdc++.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
using namespace std;
ofstream fout;
ifstream fin;

int T;

long long int d;
long long int casen;
long long int a;
long long int b;

vector<pair<long long int, long long int>> ks;

int main() {
  fin.open("test.input.in");
fout.open("test.output.out");
ios::sync_with_stdio(false);
cin >> T;
  for (int t = 1; t <= T; t++) {
    ks.clear();
    fin >> d >> casen;
    double lb;
double ub;
double ex;

    lb = 0;
    ub = 0;
    for (int i = 0; i < casen; i++) {
      fin >> a >> b;
      ks.push_back((pair<long long int, long long int>)(a, b));
      if (ub == 0) {
        if (a != d) {
          ub = d * b / (d - a + 0.0);
        }
      } else if (a != d) {
        ub = min(ub, d * b / (d - a + 0.0));
      }
    }
    while (abs(ub - lb) > 0.0000005f) {
      ex = (ub + lb) / 2;
      bool f = true;
      // cout << "Testing " << ex << endl;
      int i = 0; while (i < casen)  {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (ks[i].second >= ex)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (ks[i].first / (ex - ks[i].second) * ex < d) {
          f = false;
        }
      i++;
}
      if (f) {
        lb = ex;
      } else {
        ub = ex;
      }
    }
    fout << fixed << setprecision(7) << "Case #" << t << ": " << ub << endl;
  }
}
