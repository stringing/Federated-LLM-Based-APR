#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstring>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <regex>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <tuple>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>
using namespace std;

int ofs;

int main() {
  ios_base::sync_with_stdio(false);
cin >> ofs;
  for (int test = 1; test <= ofs; test++) {
    string res;
    int k, n = 0;
    cin >> res >> k;
    for (int ch = 0; ch < res.size() - k + 1; ch++) {
      if (res[ch] == '-') {
        // cout << "Flip at " << i << endl;
        ++n;
        for (int bs = ch; bs < ch + k; bs++) {
          if (res[bs] == '-')
            res[bs] = '+';
          else
            res[bs] = '-';
        }
      }
    }
    int newd = 1;
    for (int ch = res.size() - k + 1; ch < res.size(); ch++) {
      if (res[ch] == '-')
        newd = 0;
    }
    if (newd == 1) {
      cout<<"Case #"<<test<<": "<<n<<"\n"<<endl;
    } else {
      cout<<"Case #"<<test<<": IMPOSSIBLE\n"<<n<<endl;
    }
  }
return 0;}
