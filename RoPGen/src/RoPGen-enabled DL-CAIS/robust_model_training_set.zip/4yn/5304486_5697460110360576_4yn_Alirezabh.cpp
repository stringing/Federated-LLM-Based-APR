#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef long double lld;
typedef pair<int, int> PII;
typedef pair<ll, ll> PLL;
typedef vector<int> VI;
typedef vector<string> VS;
typedef vector<double> VD;

int ind;
int odd, memo;
long long int even[1009];

long long int eleven(long long int Tcase) { return Tcase * 11 / 10; }

long long int ninety(long long int Tcase) {
  long long int ret = Tcase * 9 / 10;
  if (Tcase % 10 != 0) {
    ret += 1;
  }
  return ret;
}

bool inrange(int inf, long long int currentParent, long long int Tcas) {
  long long int Tcase = even[inf] * Tcas;
  return (ninety(Tcase) <= currentParent) && (currentParent <= eleven(Tcase));
}

int main() {
  freopen("a.in","r",stdin);
freopen("a.out","w",stdout);
cin >> ind;
  for (int en = 1; en <= ind; en++) {
    long long int temp;
    priority_queue<long long int, vector<long long int>, greater<long long int>> hasTaken[1009];
    memset(even, -1, sizeof(even));
    cin >> odd >> memo;
    for (int sum = 0; sum < odd; sum++) {
      cin >> even[sum];
    }
    for (int k = 0; k < odd; k++) {
      for (int newCameronTime = 0; newCameronTime < memo; newCameronTime++) {
        cin >> temp;
        hasTaken[k].push(temp);
      }
    }
    long long int res = 0;
    long long int st = 1;
    long long int v = 1;
    long long int Aj = 1;
    for(;1;) {
      // if can send serving
      bool newCurrentParent = 1;
      st = 1;
      for (int k = 0; k < odd; k++) {
        if (hasTaken[k].empty()) {
          newCurrentParent = 0;
          break;
        }
        if (!inrange(k, hasTaken[k].top(), v)) {
          st = 0;
        }
      }

      if (!newCurrentParent) {
        break;
      }

      if (st) {
        // cout << "Send\n";
        res++;
        for (int k = 0; k < odd; k++) {
          hasTaken[k].pop();
        }
      } else {
        // find next serving size to make
        Aj = 9999999999;
        for (int k = 0; k < odd; k++) {
          if (hasTaken[k].empty())
            break;
          Aj = min(Aj, hasTaken[k].top() / eleven(even[k]));
        }
        if (Aj <= v) {
          Aj = v + 1;
        }
        v = Aj;
        // flush
        for (int k = 0; k < odd; k++) {
          for(;!hasTaken[k].empty() && hasTaken[k].top() < ninety(even[k] * v);) {
            hasTaken[k].pop();
          }
          if (hasTaken[k].empty()) {
            newCurrentParent = 0;
            break;
          }
        }
        if (!newCurrentParent) {
          break;
        }
      }
    }
    cout << "Case #" << en << ": " << res << endl;
  }
}
