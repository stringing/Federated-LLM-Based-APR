#include <bits/stdc++.h>
#include <iostream>
#include <unordered_map>
#include <unordered_set>
using namespace std;

int tc;

int main() {
  ios_base::sync_with_stdio(false);
freopen("inp3.txt","r",stdin);
freopen("out3.txt","w",stdout);
cin >> tc;
  for (int c = 1; c <= tc; c++) {
    string pq;
    int n, each = 0;
    cin >> pq >> n;
    for (int ccr = 0; ccr < pq.size() - n + 1; ccr++) {
      if (pq[ccr] == '-') {
        // cout << "Flip at " << i << endl;
        ++each;
        for (int val = ccr; val < ccr + n; val++) {
          if (pq[val] == '-')
            pq[val] = '+';
          else
            pq[val] = '-';
        }
      }
    }
    int ans = 1;
    for (int ccr = pq.size() - n + 1; ccr < pq.size(); ccr++) {
      if (pq[ccr] == '-')
        ans = 0;
    }
    if (ans == 1) {
      cout<<"Case #"<<c<<": "<<each<<"\n"<<endl;
    } else {
      cout<<"Case #"<<c<<": IMPOSSIBLE\n"<<each<<endl;
    }
  }
return 0;}
