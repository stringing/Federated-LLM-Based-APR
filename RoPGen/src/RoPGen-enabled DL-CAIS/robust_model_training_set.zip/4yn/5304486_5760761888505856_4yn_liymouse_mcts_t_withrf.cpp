#include <algorithm>
#include <bits/stdc++.h>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;
typedef long long i64d;

int tc;

int main() {
  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_5304486_5760761888505856_15_CCS18_RNN_800_True_MCTS_Classic_True/liymouse/4yn/A-small-practice.in", "r", stdin);

  scanf("%d ", &tc);
  for (int t = 1; t <= tc; t++) {
    int r, ca;
    scanf("%d %d ", &r, &ca);
    char cake[30][30];
    for (int i = 0; i < r; i++) {
      for (int x = 0; x < ca; x++) {
        scanf("%c ", &cake[i][x]);
      }
    }
    for (int i = 0; i < r; i++) {
      // sweep left to right
      for (int x = 1; x < ca; x++) {
        if (cake[i][x - 1] != '?' && cake[i][x] == '?') {
          cake[i][x] = cake[i][x - 1];
        }
      }
      // sweep right to left
      for (int x = ca - 2; x >= 0; x--) {
        if (cake[i][x + 1] != '?' && cake[i][x] == '?') {
          cake[i][x] = cake[i][x + 1];
        }
      }
    }
    for (int i = 1; i < r; i++) {
      // sweep up to down
      if (cake[i - 1][0] != '?' && cake[i][0] == '?') {
        for (int x = 0; x < ca; x++) {
          cake[i][x] = cake[i - 1][x];
        }
      }
    }
    for (int i = r - 1; i >= 0; i--) {
      // sweep down to up
      if (cake[i + 1][0] != '?' && cake[i][0] == '?') {
        int x;
        {
          x = 0;
          while (x < ca) {
            cake[i][x] = cake[i + 1][x];
            x++;
          }
        }
      }
    }
    cout << "Case #" << t << ":\n";
    for (int i = 0; i < r; i++) {
      for (int x = 0; x < ca; x++) {
        cout << cake[i][x];
      }
      cout << endl;
    }
  }
}
