#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;

int n;

void split_main_8_54(int* n) {
  for (int l = 1; l <= (*n); ++l) {
    int current, o;
    cin >> current >> o;
    char k[30][30];
    for (int value = 0; value < current; ++value) {
      for (int y = 0; y < o; ++y) {
        cin >> k[value][y];
      }
    }
    for (int y = 0; y < current; ++y) {
      // sweep left to right
      for (int x = 1; x < o; ++x) {
        if (k[y][x - 1] != '?' && k[y][x] == '?') {
          k[y][x] = k[y][x - 1];
        }
      }
      // sweep right to left
      for (int x = o - 2; x >= 0; --x) {
        if (k[y][x + 1] != '?' && k[y][x] == '?') {
          k[y][x] = k[y][x + 1];
        }
      }
    }
    for (int y = 1; y < current; ++y) {
      // sweep up to down
      if (k[y - 1][0] != '?' && k[y][0] == '?') {
        for (int x = 0; x < o; ++x) {
          k[y][x] = k[y - 1][x];
        }
      }
    }
    for (int y = current - 1; y >= 0; --y) {
      // sweep down to up
      if (k[y + 1][0] != '?' && k[y][0] == '?') {
        for (int x = 0; x < o; ++x) {
          k[y][x] = k[y + 1][x];
        }
      }
    }
    cout << "Case #" << l << ":\n";
    for (int y = 0; y < current; ++y) {
      for (int x = 0; x < o; ++x) {
        cout << k[y][x];
      }
      cout << endl;
    }
  }
}
int main() {
  freopen("input.txt","r",stdin);
freopen("output.txt","w",stdout);
cin >> n;
  split_main_8_54(&n);

return 0;}
