#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long long LL;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<int> vi;
int ac;
int cur, minute;
long long int r[1009];

long long int eleven(long long int idx) { return idx * 11 / 10; }

long long int ninety(long long int idx) {
  long long int aj = idx * 9 / 10;
  if (idx % 10 != 0) {
    aj += 1;
  }
  return aj;
}

bool inrange(int memo, long long int sisa, long long int pancake) {
  long long int idx = r[memo] * pancake;
  return (ninety(idx) <= sisa) && (sisa <= eleven(idx));
}

int main() {
  freopen("D:/OneDrive/Code/GCJ/A-large.in","r",stdin);
freopen("D:/OneDrive/Code/GCJ/out.txt","w",stdout);
scanf("%d",&ac);
  for (int jml = 1; jml <= ac; jml++) {
    long long int c;
    priority_queue<long long int, vector<long long int>, greater<long long int>> tmpi[1009];
    memset(r, -1, sizeof(r));
    scanf("%d%d",&cur,&minute);
    for (int bs = 0; bs < cur; bs++) {
      cin >> r[bs];
    }
    for (int en = 0; en < cur; en++) {
      for (int tot = 0; tot < minute; tot++) {
        cin >> c;
        tmpi[en].push(c);
      }
    }
    long long int v = 0;
    long long int f = 1;
    long long int found = 1;
    long long int arr = 1;
    for(;1;) {
      // if can send serving
      bool z = 1;
      f = 1;
      for (int xy = 0; xy < cur; xy++) {
        if (tmpi[xy].empty()) {
          z = 0;
          break;
        }
        if (!inrange(xy, tmpi[xy].top(), found)) {
          f = 0;
        }
      }

      if (!z) {
        break;
      }

      if (f) {
        // cout << "Send\n";
        v++;
        for (int st = 0; st < cur; st++) {
          tmpi[st].pop();
        }
      } else {
        // find next serving size to make
        arr = 9999999999;
        for (int tot = 0; tot < cur; tot++) {
          if (tmpi[tot].empty())
            break;
          arr = min(arr, tmpi[tot].top() / eleven(r[tot]));
        }
        if (arr <= found) {
          arr = found + 1;
        }
        found = arr;
        // flush
        for (int tot = 0; tot < cur; tot++) {
          for(;!tmpi[tot].empty() && tmpi[tot].top() < ninety(r[tot] * found);) {
            tmpi[tot].pop();
          }
          if (tmpi[tot].empty()) {
            z = 0;
            break;
          }
        }
        if (!z) {
          break;
        }
      }
    }
    cout << "Case #" << jml << ": " << v << endl;
  }
return 0;}
