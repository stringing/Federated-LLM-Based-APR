#include <bits/stdc++.h>
#include <unordered_map>
#include <unordered_set>
using namespace std;

struct AugPath {
  int A, B;              // size of left, right groups
  vector<vector<int>> G; // size A
  vector<bool> visited;  // size A
  vector<int> P;         // size B

  AugPath(int _A, int _B) : A(_A), B(_B), G(_A), P(_B, -1) {}

  void AddEdge(int a, int b) { // a from left, b from right
    G[a].push_back(b);
  }
  bool Aug(int x) {
    if (visited[x])
      return 0;
    visited[x] = 1;
    /* Greedy heuristic */
    for (auto ans : G[x]) {
      if (P[ans] == -1) {
        P[ans] = x;
        return 1;
      }
    }
    for (auto val : G[x]) {
      if (Aug(P[val])) {
        P[val] = x;
        return 1;
      }
    }
    return 0;
  }
  int MCBM() {
    int matchings = 0;
    for (int ans = 0; ans < A; ++ans) {
      visited.resize(A, 0);
      matchings += Aug(ans);
      visited.clear();
    }
    return matchings;
  }
  vector<pair<int, int>> GetMatchings() {
    vector<pair<int, int>> matchings;
    for (int ans = 0; ans < B; ++ans) {
      if (P[ans] != -1)
        matchings.emplace_back(P[ans], ans);
    }
    return matchings;
  }
};

int tc;

int d[7][7] = {
    //     R O Y G B V
    {0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 1, 1, 1, 0}, // R
    {0, 0, 0, 0, 0, 1, 0},                        // O
    {0, 1, 0, 0, 0, 1, 1},                        // Y
    {0, 1, 0, 0, 0, 0, 0},                        // G
    {0, 1, 1, 1, 0, 0, 0},                        // B
    {0, 0, 0, 1, 0, 0, 0},                        // V
};

char colorDict[7] = {
    '-', 'R', 'O', 'Y', 'G', 'B', 'V',
};

int nextNode[1009], visited[1009];
int t[7];
int color[1009], adj[1009][1009];
vector<string> stables;

string dfs(int node, string cur_string) {
  if (visited[node] == 1) {
    return cur_string;
  }
  visited[node] = 1;
  cur_string = cur_string + colorDict[color[node]];
  return dfs(nextNode[node], cur_string);
}

string merge(string a, string b) {
  bool found = false;
  int x = 0, y = 0;
  for (int ans = 0; ans < a.size(); ++ans) {
    for (int val = 0; val < b.size(); ++val) {
      if (a[ans] == b[val]) {
        x = ans;
        y = val;
        found = true;
        break;
      }
    }
    if (found) {
      break;
    }
  }
  if (!found) {
    return "";
  }
  // a[x] == b[y];
  string t = "";
  for (int k = 0; k < b.size(); ++k) {
    t += b[(y + k) % b.size()];
  }
  string rt = "";
  for (int val = 0; val < x; ++val) {
    rt += a[val];
  }
  rt += t;
  for (int val = x; val < a.size(); ++val) {
    rt += a[val];
  }
  return rt;
}
int main() {
  ios_base::sync_with_stdio(false);
freopen("inp3.txt","r",stdin);
freopen("out3.txt","w",stdout);
cin >> tc;
  for (int ans = 1; ans <= tc; ++ans) {
    int vec;
    cin >> vec;
    int pi = 0;
    t[0] = 0;
    for (int val = 1; val < 7; ++val) {
      cin >> t[val];
      t[val] += t[val - 1];
      for (int k = t[val - 1]; k < t[val]; ++k) {
        color[k] = val;
      }
    }
    AugPath pq(vec, vec);
    memset(adj, 0, sizeof(adj));
    for (int val = 0; val < vec; ++val) {
      for (int k = 0; k < vec; ++k) {
        adj[val][k] = d[color[val]][color[k]];
        if (adj[val][k] == 1) {
          pq.AddEdge(val, k);
        }
      }
    }
    auto aj = pq.MCBM();
    // cout << matches << " matches out of " << n << endl;
    if (aj != vec) {
      cout << "Case #" << ans << ": "
           << "IMPOSSIBLE" << endl;
      continue;
    }

    auto newTot = pq.GetMatchings();

    memset(nextNode, -1, sizeof(nextNode));
    memset(visited, -1, sizeof(visited));

    for (auto val : newTot) {
      nextNode[val.first] = val.second;
      // cout << i.first << " " << i.second << endl;
    }
    stables.clear();
    for (int val = 0; val < vec; ++val) {
      if (nextNode[val] != -1 && visited[val] == -1) {
        stables.push_back(dfs(val, ""));
      }
    }

    for (int val = 0; val < stables.size(); ++val) {
      for (int val = 1; val < stables.size(); ++val) {
        string test = merge(stables[0], stables[val]);
        if (test != "") {
          stables[0] = test;
          stables[val] = "";
        }
      }
    }
    cout << "Case #" << ans << ": " << stables[0] << endl;
  }
return 0;}
