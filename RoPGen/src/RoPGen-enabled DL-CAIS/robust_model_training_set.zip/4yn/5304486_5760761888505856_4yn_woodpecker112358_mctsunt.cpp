#include <bits/stdc++.h>
using namespace std;

int tc;

void split_main_48_53(int* r,int* c,char cakeary[30][30]) {
    for (int i = 0; i < (*r); i++) {
      for (int it = 0; it < (*c); it++) {
        cout << cakeary[i][it];
      }
      cout << endl;
    }
}
int main() {
  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    int r, c;
    cin >> r >> c;
    char cake[30][30];
    for (int i = 0; i < r; i++) {
      for (int it = 0; it < c; it++) {
        cin >> cake[i][it];
      }
    }
    for (int i = 0; i < r; i++) {
      // sweep left to right
      for (int it = 1; it < c; it++) {
        if (cake[i][it - 1] != '?' && cake[i][it] == '?') {
          cake[i][it] = cake[i][it - 1];
        }
      }
      // sweep right to left
      for (int it = c - 2; it >= 0; it--) {
        if (cake[i][it + 1] != '?' && cake[i][it] == '?') {
          cake[i][it] = cake[i][it + 1];
        }
      }
    }
    for (int i = 1; i < r; i++) {
      // sweep up to down
      if (cake[i - 1][0] != '?' && cake[i][0] == '?') {
        for (int it = 0; it < c; it++) {
          cake[i][it] = cake[i - 1][it];
        }
      }
    }
    for (int i = r - 1; i >= 0; i--) {
      // sweep down to up
      if (cake[i + 1][0] != '?' && cake[i][0] == '?') {
        for (int it = 0; it < c; it++) {
          cake[i][it] = cake[i + 1][it];
        }
      }
    }
    cout << "Case #" << t << ":\n";
    split_main_48_53(&r,&c,cake);

  }
}
