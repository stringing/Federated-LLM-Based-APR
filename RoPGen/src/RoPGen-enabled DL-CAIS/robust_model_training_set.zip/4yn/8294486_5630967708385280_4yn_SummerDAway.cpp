#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
using namespace std;

int y;

long long int ch;
long long int p;
long long int m;
long long int ans;

vector<pair<long long int, long long int>> TC;

int main() {
  freopen("D-small-attempt1.in","r",stdin);
freopen("D-small-attempt1.out","w",stdout);
scanf("%d",&y);
  for (int x1 = 1; x1 <= y; ++x1) {
    TC.clear();
    double x3 = 0;
double j = 0;
double k;

    cin >> ch >> p;
    for (int y = 0; y < p; ++y) {
      cin >> m >> ans;
      TC.push_back((pair<long long int, long long int>)(m, ans));
      if (j == 0&&m != ch) {
        
          j = ch * ans / (ch - m + 0.0);
        } else if (m != ch) {
        j = min(j, ch * ans / (ch - m + 0.0));
      }
    }
    for(;abs(j - x3) > 0.0000005f;) {
      k = (j + x3) / 2;
      bool x = true;
      // cout << "Testing " << ex << endl;
      for (int x2 = 0; x2 < p; ++x2) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (TC[x2].second >= k)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (TC[x2].first / (k - TC[x2].second) * k < ch) {
          x = false;
        }
      }
      if (x) {
        x3 = k;
      } else {
        j = k;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << x1 << ": " << j << endl;
  }
}
