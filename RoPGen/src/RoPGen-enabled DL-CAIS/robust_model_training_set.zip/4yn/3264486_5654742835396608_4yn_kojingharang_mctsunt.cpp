#include <bits/stdc++.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
using namespace std;
ifstream fin;
int gcd;

int main() {
  fin.open("test.input.in");
fin >> gcd;
  for (int j = 1; j <= gcd; j++) {
    int tc, ok;
    fin >> tc >> ok;
    priority_queue<int> s;
    s.push(tc);
    int vec, r;
    for (int l = 0; l < ok; l++) {
      int j = s.top() - 1;
      s.pop();
      vec = j / 2 + (j % 2);
      r = j / 2;
      s.push(vec);
      s.push(r);
    }
    printf("Case #%d: %d %d\n", j, vec, r);
  }
}
