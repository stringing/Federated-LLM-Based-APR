#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
using namespace std;

int ans;

int main() {
  freopen("D-small-attempt1.in","r",stdin);
freopen("D-small-attempt1.out","w",stdout);
scanf("%d",&ans);
  for (int tc = 1; tc <= ans; tc++) {
    string r;
    int x2, l = 0;
    cin >> r >> x2;
    for (int i = 0; i < r.size() - x2 + 1; i++) {
      if (r[i] == '-') {
        // cout << "Flip at " << i << endl;
        ++l;
        for (int j = i; j < i + x2; j++) {
          if (r[j] == '-')
            r[j] = '+';
          else
            r[j] = '-';
        }
      }
    }
    int x = 1;
    for (int k = r.size() - x2 + 1; k < r.size(); k++) {
      if (r[k] == '-')
        x = 0;
    }
    if (x == 1) {
      printf("Case #%d: %d\n", tc, l);
    } else {
      printf("Case #%d: IMPOSSIBLE\n", tc, l);
    }
  }
}
