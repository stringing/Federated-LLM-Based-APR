#include <bits/stdc++.h>
#include <utility>
#include <vector>
using namespace std;
typedef vector<int> vi;
typedef pair<int, int> ii;
typedef long long LL;

int tc;
int n, p;
LL r[1009];

LL eleven(LL x) { return x * 11 / 10; }

LL ninety(LL x) {
  LL y = x * 9 / 10;
  if (x % 10 != 0) {
    y += 1;
  }
  return y;
}

bool inrange(int ingredient, LL number, LL servings) {
  LL x = r[ingredient] * servings;
  return (ninety(x) <= number) && (number <= eleven(x));
}

int main() {
  int ret_val = 0;
  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    LL tmp;
    priority_queue<LL, vector<LL>, greater<LL>> q[1009];
    memset(r, -1, sizeof(r));
    cin >> n >> p;
    for (int i = 0; i < n; i++) {
      cin >> r[i];
    }
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < p; j++) {
        cin >> tmp;
        q[i].push(tmp);
      }
    }
    LL ans = 0;
    LL cansendserving = 1;
    LL curservingsize = 1;
    LL nextservingsize = 1;
    while (1) {
      // if can send serving
      bool okay = 1;
      cansendserving = 1;
      for (int i = 0; i < n; i++) {
        if (q[i].empty()) {
          okay = 0;
          break;
        }
        if (!inrange(i, q[i].top(), curservingsize)) {
          cansendserving = 0;
        }
      }

      if (!okay) {
        break;
      }

      if (cansendserving) {
        // cout << "Send\n";
        ans++;
        for (int i = 0; i < n; i++) {
          q[i].pop();
        }
      } else {
        // find next serving size to make
        nextservingsize = 9999999999;
        for (int i = 0; i < n; i++) {
          if (q[i].empty())
            break;
          nextservingsize = min(nextservingsize, q[i].top() / eleven(r[i]));
        }
        if (nextservingsize <= curservingsize) {
          nextservingsize = curservingsize + 1;
        }
        curservingsize = nextservingsize;
        // flush
        for (int i = 0; i < n; i++) {
          while (!q[i].empty() && q[i].top() < ninety(r[i] * curservingsize)) {
            q[i].pop();
          }
          if (q[i].empty()) {
            okay = 0;
            break;
          }
        }
        if (!okay) {
          break;
        }
      }
    }
    cout << "Case #" << t << ": " << ans << endl;
  }
  return ret_val;
}
