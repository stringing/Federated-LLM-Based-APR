#include <bits/stdc++.h>
#include <iostream>
using namespace std;

int tc;

inline void sikiymoswj(int &cas, char cake[30][30], int &i) {
  for (int m = 0; m < cas; m++) {
    cake[i][m] = cake[i - 1][m];
  }
}

int main() {
  ios::sync_with_stdio(false);

  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_5304486_5760761888505856_15_CCS18_RNN_800_True_MCTS_Classic_True/jiian/4yn/A-small-practice.in",
          "r", stdin);
  cin >> tc;
  for (int n = 1; n <= tc; n++) {
    int r, cas;
    cin >> r >> cas;
    char cake[30][30];
    for (int i = 0; i < r; i++) {
      for (int m = 0; m < cas; m++) {
        cin >> cake[i][m];
      }
    }
    for (int i = 0; i < r; i++) {
      // sweep left to right
      for (int m = 1; m < cas; m++) {
        if (cake[i][m - 1] != '?' && cake[i][m] == '?') {
          cake[i][m] = cake[i][m - 1];
        }
      }
      // sweep right to left
      for (int m = cas - 2; m >= 0; m--) {
        if (cake[i][m + 1] != '?' && cake[i][m] == '?') {
          cake[i][m] = cake[i][m + 1];
        }
      }
    }
    for (int i = 1; i < r; i++) {
      // sweep up to down
      if (cake[i - 1][0] != '?' && cake[i][0] == '?')
        sikiymoswj(cas, cake, i);
    }
    for (int i = r - 1; i >= 0; i--) {
      // sweep down to up
      if (cake[i + 1][0] != '?' && cake[i][0] == '?') {
        {
          int m = 0;
          while (m < cas) {
            cake[i][m] = cake[i + 1][m];
            m++;
          }
        }
      }
    }
    cout << "Case #" << n << ":\n";
    for (int i = 0; i < r; i++) {
      for (int m = 0; m < cas; m++) {
        cout << cake[i][m];
      }
      cout << endl;
    }
  }
  return 0;
}
