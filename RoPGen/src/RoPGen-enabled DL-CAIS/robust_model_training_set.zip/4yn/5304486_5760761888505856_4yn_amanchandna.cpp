#include <bits/stdc++.h>
#include <unordered_map>
#include <unordered_set>
using namespace std;

int t;

int main() {
  ios_base::sync_with_stdio(false);
freopen("inp3.txt","r",stdin);
freopen("out3.txt","w",stdout);
cin >> t;
  for (int aj = 1; aj <= t; ++aj) {
    int vec, n;
    cin >> vec >> n;
    char k[30][30];
    for (int ans = 0; ans < vec; ++ans) {
      for (int val = 0; val < n; ++val) {
        cin >> k[ans][val];
      }
    }
    for (int ans = 0; ans < vec; ++ans) {
      // sweep left to right
      for (int val = 1; val < n; ++val) {
        if (k[ans][val - 1] != '?' && k[ans][val] == '?') {
          k[ans][val] = k[ans][val - 1];
        }
      }
      // sweep right to left
      for (int val = n - 2; val >= 0; --val) {
        if (k[ans][val + 1] != '?' && k[ans][val] == '?') {
          k[ans][val] = k[ans][val + 1];
        }
      }
    }
    for (int ans = 1; ans < vec; ++ans) {
      // sweep up to down
      if (k[ans - 1][0] != '?' && k[ans][0] == '?') {
        for (int val = 0; val < n; ++val) {
          k[ans][val] = k[ans - 1][val];
        }
      }
    }
    for (int ans = vec - 1; ans >= 0; --ans) {
      // sweep down to up
      if (k[ans + 1][0] != '?' && k[ans][0] == '?') {
        for (int val = 0; val < n; ++val) {
          k[ans][val] = k[ans + 1][val];
        }
      }
    }
    cout << "Case #" << aj << ":\n";
    for (int ans = 0; ans < vec; ++ans) {
      for (int val = 0; val < n; ++val) {
        cout << k[ans][val];
      }
      cout << endl;
    }
  }
return 0;}
