#include <algorithm>
#include <bits/stdc++.h>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <stdio.h>
using namespace std;

int s;

inline void goanzztjri(char cake[30][30], int &tt, int &xcri_Var) {
  cake[tt][xcri_Var] = cake[tt][xcri_Var - 1];
}

inline void zfvcnarywe(int &ans, char cake[30][30], int &tt) {
  // sweep down to up
  if (cake[tt + 1][0] != '?')
    if (cake[tt][0] == '?') {
      int xcri_Var;
      for (xcri_Var = 0; xcri_Var < ans; xcri_Var++) {
        cake[tt][xcri_Var] = cake[tt + 1][xcri_Var];
      }
    }
}

int main() {

  scanf("%d ", &s);
  for (int t = 1; t <= s; t++) {
    int r, ans;
    scanf("%d %d ", &r, &ans);
    char cake[30][30];
    for (int tt = 0; tt < r; tt++) {
      for (int xcri_Var = 0; xcri_Var < ans; xcri_Var++) {
        scanf("%c ", &cake[tt][xcri_Var]);
      }
    }
    for (int tt = 0; tt < r; tt++) {
      // sweep left to right
      for (int xcri_Var = 1; xcri_Var < ans; xcri_Var++) {
        if (cake[tt][xcri_Var - 1] != '?' && cake[tt][xcri_Var] == '?')
          goanzztjri(cake, tt, xcri_Var);
      }
      // sweep right to left
      for (int xcri_Var = ans - 2; xcri_Var >= 0; xcri_Var--) {
        if (cake[tt][xcri_Var + 1] != '?' && cake[tt][xcri_Var] == '?') {
          cake[tt][xcri_Var] = cake[tt][xcri_Var + 1];
        }
      }
    }
    for (int tt = 1; tt < r; tt++) {
      // sweep up to down
      if (cake[tt - 1][0] != '?' && cake[tt][0] == '?') {
        {
          int xcri_Var = 0;
          while (xcri_Var < ans) {
            cake[tt][xcri_Var] = cake[tt - 1][xcri_Var];
            xcri_Var++;
          }
        }
      }
    }
    for (int tt = r - 1; tt >= 0; tt--)
      zfvcnarywe(ans, cake, tt);
    printf("Case #%d:\n", t);
    for (int tt = 0; tt < r; tt++) {
      {
        int xcri_Var = 0;
        while (xcri_Var < ans) {
          printf("%c", cake[tt][xcri_Var]);
          xcri_Var++;
        }
      }
      printf("\n");
    }
  }
}
