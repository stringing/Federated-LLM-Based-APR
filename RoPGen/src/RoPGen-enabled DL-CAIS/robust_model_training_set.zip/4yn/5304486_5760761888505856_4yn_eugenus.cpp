#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;

typedef pair<int, int> par;
typedef long long int tint;

int k;

void split_main_42_44(int* hi,char a[30][30],int* cnd) {
        for (int lo = 0; lo < (*hi); lo++) {
          a[(*cnd)][lo] = a[(*cnd) + 1][lo];
        }
}
int main() {
  freopen("test.txt","r",stdin);
freopen("out.txt","w",stdout);
cin >> k;
  for (int lo = 1; lo <= k; lo++) {
    
    int hi;int be;
cin >> be >> hi;
    char best[30][30];
    for (int cnd = 0; cnd < be; cnd++) {
      for (int ans = 0; ans < hi; ans++) {
        cin >> best[cnd][ans];
      }
    }
    for (int cnd = 0; cnd < be; cnd++) {
      // sweep left to right
      for (int ans = 1; ans < hi; ans++) {
        if (best[cnd][ans - 1] != '?' && best[cnd][ans] == '?') {
          best[cnd][ans] = best[cnd][ans - 1];
        }
      }
      // sweep right to left
      for (int ans = hi - 2; ans >= 0; ans--) {
        if (best[cnd][ans + 1] != '?' && best[cnd][ans] == '?') {
          best[cnd][ans] = best[cnd][ans + 1];
        }
      }
    }
    for (int cnd = 1; cnd < be; cnd++) {
      // sweep up to down
      if (best[cnd - 1][0] != '?' && best[cnd][0] == '?') {
        for (int ans = 0; ans < hi; ans++) {
          best[cnd][ans] = best[cnd - 1][ans];
        }
      }
    }
    for (int cnd = be - 1; cnd >= 0; cnd--) {
      // sweep down to up
      if (best[cnd + 1][0] != '?' && best[cnd][0] == '?') {split_main_42_44(&hi,best,&cnd);
}
    }
    cout << "Case #" << lo << ":\n";
    for (int cnd = 0; cnd < be; cnd++) {
      for (int ans = 0; ans < hi; ans++) {
        cout << best[cnd][ans];
      }
      cout << endl;
    }
  }
return 0;}
