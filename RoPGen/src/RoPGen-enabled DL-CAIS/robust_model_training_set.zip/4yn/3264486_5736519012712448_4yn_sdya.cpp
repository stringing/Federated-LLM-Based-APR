#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;

int n;

int main() {
  freopen("input.txt","r",stdin);
freopen("output.txt","w",stdout);
cin >> n;
  for (int i = 1; i <= n; i++) {
    string added;
    int y, l = 0;
    cin >> added >> y;
    for (int j = 0; j < added.size() - y + 1; j++) {
      if (added[j] == '-') {
        // cout << "Flip at " << i << endl;
        ++l;
        for (int k = j; k < j + y; k++) {
          if (added[k] == '-')
            added[k] = '+';
          else
            added[k] = '-';
        }
      }
    }
    int u = 1;
    for (int l = added.size() - y + 1; l < added.size(); l++) {
      if (added[l] == '-')
        u = 0;
    }
    if (u == 1) {
      printf("Case #%d: %d\n", i, l);
    } else {
      printf("Case #%d: IMPOSSIBLE\n", i, l);
    }
  }
return 0;}
