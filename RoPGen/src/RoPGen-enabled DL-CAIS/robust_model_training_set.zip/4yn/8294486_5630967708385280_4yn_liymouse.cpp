#include <algorithm>
#include <bits/stdc++.h>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

typedef long long i64d;

int lastcar;

long long int time;
long long int sout;
long long int lr;
long long int stin;

vector<pair<long long int, long long int>> cas;

int main() {
  freopen("D-small-attempt2.in","r",stdin);
freopen("D-small-attempt2.out","w",stdout);
scanf("%d",&lastcar);
  for (int k = 1; k <= lastcar; k++) {
    cas.clear();
    cin >> time >> sout;
    double y = 0;
double x = 0;
double num;

    for (int j = 0; j < sout; j++) {
      cin >> lr >> stin;
      cas.push_back((pair<long long int, long long int>)(lr, stin));
      if (x == 0&&lr != time) {
        
          x = time * stin / (time - lr + 0.0);
        } else if (lr != time) {
        x = min(x, time * stin / (time - lr + 0.0));
      }
    }
    for(;abs(x - y) > 0.0000005f;) {
      num = (x + y) / 2;
      bool res = true;
      // cout << "Testing " << ex << endl;
      for (int j = 0; j < sout; j++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (cas[j].second >= num)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (cas[j].first / (num - cas[j].second) * num < time) {
          res = false;
        }
      }
      if (res) {
        y = num;
      } else {
        x = num;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << k << ": " << x << endl;
  }
return 0;}
