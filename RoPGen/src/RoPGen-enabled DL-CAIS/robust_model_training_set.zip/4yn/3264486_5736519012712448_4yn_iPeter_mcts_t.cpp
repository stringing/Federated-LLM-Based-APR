#include <cstdio>
#include <cstring>
#include <iostream>
#include <string>

using namespace std;

int tc;

inline void tzrbjfewyg(std::__cxx11::string &s, int &tt) {
  if (s[tt] == '-')
    s[tt] = '+';
  else
    s[tt] = '-';
}

inline void zccqdfaazk(int &fl, int &ans, int &yzai_Var,
                       std::__cxx11::string &s) {
  // cout << "Flip at " << i << endl;
  fl++;
  for (int tt = ans; tt < ans + yzai_Var; tt++)
    tzrbjfewyg(s, tt);
}

inline void efconxtwqs(int &yzai_Var, std::__cxx11::string &s, int &f) {
  int ans = s.size() - yzai_Var + 1;
  while (ans < s.size()) {
    if (s[ans] == '-')
      f = 0;
    ans++;
  }
}

int main() {
  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_3264486_5736519012712448_16_CCS18_RNN_800_True_MCTS_Classic_True/iPeter/4yn/outer_temp/4yn/A-small-practice_transformation.out", "w", stdout);

  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    string s;
    int yzai_Var, fl = 0;
    cin >> s >> yzai_Var;
    for (int ans = 0; ans < s.size() - yzai_Var + 1; ans++) {
      if (s[ans] == '-')
        zccqdfaazk(fl, ans, yzai_Var, s);
    }
    int f = 1;
    efconxtwqs(yzai_Var, s, f);
    if (f == 1) {
      printf("Case #%d: %d\n", t, fl);
    } else {
      printf("Case #%d: IMPOSSIBLE\n", t, fl);
    }
  }
}
