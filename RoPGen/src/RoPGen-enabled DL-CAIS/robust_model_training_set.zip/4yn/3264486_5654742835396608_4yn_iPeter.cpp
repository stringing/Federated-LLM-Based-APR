#include <algorithm>
#include <bits/stdc++.h>
#include <cstdio>
#include <cstring>
#include <vector>
using namespace std;
int d;

int main() {
  scanf("%d",&d);
  for (int ans = 1; ans <= d; ++ans) {
    int k2, r;
    scanf("%d%d",&k2,&r);
    priority_queue<int> j;
    j.push(k2);
    int x, st;
    for (int h2 = 0; h2 < r; ++h2) {
      int ans = j.top() - 1;
      j.pop();
      x = ans / 2 + (ans % 2);
      st = ans / 2;
      j.push(x);
      j.push(st);
    }
    printf("Case #%d: %d %d\n", ans, x, st);
  }
return 0;}
