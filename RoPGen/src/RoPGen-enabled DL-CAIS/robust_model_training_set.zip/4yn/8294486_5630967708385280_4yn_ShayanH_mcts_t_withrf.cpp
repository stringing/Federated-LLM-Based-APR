#include <bits/stdc++.h>
#include <iostream>
using namespace std;

typedef long long ll;
typedef pair<ll, ll> pii;
typedef double dbl;

int ans;

ll d, n, a, b;
vector<pii> j;

inline void ncxzvuzhwz(dbl &ub) { ub = d * b / (d - a + 0.0); }

int main() {
  ios::sync_with_stdio(0);

  cin >> ans;
  int tt;
  for (tt = 1; tt <= ans; tt++) {
    j.clear();
    cin >> d >> n;
    dbl lb, ub, k;
    lb = 0;
    ub = 0;
    {
      int i = 0;
      while (i < n) {
        cin >> a >> b;
        j.push_back(pii(a, b));
        if (ub == 0) {
          if (a != d)
            ncxzvuzhwz(ub);
        } else if (a != d) {
          ub = min(ub, d * b / (d - a + 0.0));
        }
        i++;
      }
    }
    while (abs(ub - lb) > 0.0000005f) {
      k = (ub + lb) / 2;
      int f = true;
      // cout << "Testing " << ex << endl;
      {
        int i = 0;
        while (i < n) {
          // cout << "Horse " << i << " speed " << ks[i].second << endl;
          if (j[i].second >= k) {
            i++;
            continue;
          }
          // cout << "Comparative speed: " << ex - ks[i].second << endl;
          // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex
          // << endl;
          if (j[i].first / (k - j[i].second) * k < d) {
            f = 0;
          }
          i++;
        }
      }
      if (f) {
        lb = k;
      } else {
        ub = k;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << tt << ": " << ub << endl;
  }
}
