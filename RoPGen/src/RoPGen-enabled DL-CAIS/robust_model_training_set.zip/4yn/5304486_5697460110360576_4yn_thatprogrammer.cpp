#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <vector>
using namespace std;
typedef long long ll;
int arr;
int cAct, numExchanges;
long long int jAct[1009];

long long int eleven(long long int a) { return a * 11 / 10; }

long long int ninety(long long int a) {
  long long int Aj = a * 9 / 10;
  if (a % 10 != 0) {
    Aj += 1;
  }
  return Aj;
}

bool inrange(int k, long long int u, long long int numTaken) {
  long long int a = jAct[k] * numTaken;
  return (ninety(a) <= u) && (u <= eleven(a));
}

int main() {
  ios::sync_with_stdio(false);
freopen("test.txt","r",stdin);
freopen("test1.txt","w",stdout);
cin >> arr;
  for (int t = 1; t <= arr; t++) {
    long long int cur;
    priority_queue<long long int, vector<long long int>, greater<long long int>> q[1009];
    memset(jAct, -1, sizeof(jAct));
    cin >> cAct >> numExchanges;
    for (int bad = 0; bad < cAct; bad++) {
      cin >> jAct[bad];
    }
    for (int bad = 0; bad < cAct; bad++) {
      for (int b = 0; b < numExchanges; b++) {
        cin >> cur;
        q[bad].push(cur);
      }
    }
    long long int ans = 0;
    long long int curMax = 1;
    long long int av = 1;
    long long int nextservingsize = 1;
    for(;1;) {
      // if can send serving
      bool okay = 1;
      curMax = 1;
      for (int bad = 0; bad < cAct; bad++) {
        if (q[bad].empty()) {
          okay = 0;
          break;
        }
        if (!inrange(bad, q[bad].top(), av)) {
          curMax = 0;
        }
      }

      if (!okay) {
        break;
      }

      if (curMax) {
        // cout << "Send\n";
        ans++;
        for (int bad = 0; bad < cAct; bad++) {
          q[bad].pop();
        }
      } else {
        // find next serving size to make
        nextservingsize = 9999999999;
        for (int bad = 0; bad < cAct; bad++) {
          if (q[bad].empty())
            break;
          nextservingsize = min(nextservingsize, q[bad].top() / eleven(jAct[bad]));
        }
        if (nextservingsize <= av) {
          nextservingsize = av + 1;
        }
        av = nextservingsize;
        // flush
        for (int bad = 0; bad < cAct; bad++) {
          for(;!q[bad].empty() && q[bad].top() < ninety(jAct[bad] * av);) {
            q[bad].pop();
          }
          if (q[bad].empty()) {
            okay = 0;
            break;
          }
        }
        if (!okay) {
          break;
        }
      }
    }
    cout << "Case #" << t << ": " << ans << endl;
  }
}
