#include <bits/stdc++.h>
#include <iostream>
using namespace std;
typedef long long ll;
typedef pair<ll, ll> pll;
typedef pair<int, int> pii;

int mid;

int main() {
  ios::sync_with_stdio(false);
cin >> mid;
  for (int i = 1; i <= mid; i++) {
    
    int ans;int cur;
cin >> cur >> ans;
    priority_queue<int> base;
    base.push(cur);
    int j, l;
    for (int mid = 0; mid < ans; mid++) {
      int i = base.top() - 1;
      base.pop();
      j = i / 2 + (i % 2);
      l = i / 2;
      base.push(j);
      base.push(l);
    }
    cout<<"Case #"<<i<<": "<<j<<" "<<l<<"\n"<<endl;
  }
return 0;}
