#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>
using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef long double lld;
typedef pair<int, int> PII;
typedef pair<ll, ll> PLL;
typedef vector<int> VI;
typedef vector<string> VS;
typedef vector<double> VD;

int Tcase;

void split_main_8_54(int* Tcase) {
  for (int newCameronTime = 1; newCameronTime <= (*Tcase); newCameronTime++) {
    int st, v;
    cin >> st >> v;
    char p[30][30];
    for (int temp = 0; temp < st; temp++) {
      for (int k = 0; k < v; k++) {
        cin >> p[temp][k];
      }
    }
    for (int k = 0; k < st; k++) {
      // sweep left to right
      for (int n = 1; n < v; n++) {
        if (p[k][n - 1] != '?' && p[k][n] == '?') {
          p[k][n] = p[k][n - 1];
        }
      }
      // sweep right to left
      for (int n = v - 2; n >= 0; n--) {
        if (p[k][n + 1] != '?' && p[k][n] == '?') {
          p[k][n] = p[k][n + 1];
        }
      }
    }
    for (int k = 1; k < st; k++) {
      // sweep up to down
      if (p[k - 1][0] != '?' && p[k][0] == '?') {
        for (int n = 0; n < v; n++) {
          p[k][n] = p[k - 1][n];
        }
      }
    }
    for (int k = st - 1; k >= 0; k--) {
      // sweep down to up
      if (p[k + 1][0] != '?' && p[k][0] == '?') {
        for (int n = 0; n < v; n++) {
          p[k][n] = p[k + 1][n];
        }
      }
    }
    cout << "Case #" << newCameronTime << ":\n";
    for (int k = 0; k < st; k++) {
      for (int n = 0; n < v; n++) {
        cout << p[k][n];
      }
      cout << endl;
    }
  }
}
int main() {
  freopen("a.in","r",stdin);
freopen("a.out","w",stdout);
cin >> Tcase;
  split_main_8_54(&Tcase);

}
