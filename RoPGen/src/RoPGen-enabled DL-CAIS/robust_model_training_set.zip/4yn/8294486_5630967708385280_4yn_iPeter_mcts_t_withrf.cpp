#include <algorithm>
#include <bits/stdc++.h>
#include <cstdio>
#include <cstring>
#include <stdio.h>
#include <vector>
using namespace std;

typedef double td_d;
typedef long long int lli;

int tt;

lli d, s, a, b;
vector<pair<lli, lli>> ks;

inline void yhuomodxqx(double &ub, double &ex) { ub = ex; }

inline void uwbmkitkpc(double &ub) { ub = d * b / (d - a + 0.0); }

int main() {
  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_8294486_5630967708385280_16_CCS18_RNN_800_True_MCTS_Classic_True/iPeter/4yn/outer_temp/4yn/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_8294486_5630967708385280_16_CCS18_RNN_800_True_MCTS_Classic_True/iPeter/4yn/A-small-practice.in",
          "r", stdin);

  scanf("%d ", &tt);
  for (int t = 1; t <= tt; t++) {
    ks.clear();
    scanf("%lld %lld ", &d, &s);
    td_d lb, ub, ex;
    lb = 0;
    ub = 0;
    for (int ans = 0; ans < s; ans++) {
      scanf("%lld %lld ", &a, &b);
      ks.push_back(pair<lli, lli>(a, b));
      if (ub == 0) {
        if (a != d)
          uwbmkitkpc(ub);
      } else if (a != d) {
        ub = min(ub, d * b / (d - a + 0.0));
      }
    }
    while (abs(ub - lb) > 0.0000005f) {
      ex = (ub + lb) / 2;
      bool f = true;
      // cout << "Testing " << ex << endl;
      for (int ans = 0; ans < s; ans++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (ks[ans].second >= ex)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (ks[ans].first / (ex - ks[ans].second) * ex < d) {
          f = false;
        }
      }
      if (f) {
        lb = ex;
      } else {
        yhuomodxqx(ub, ex);
      }
    }
    printf("Case #%d: %.7f\n", t, ub);
  }
}
