#include <bits/stdc++.h>
using namespace std;

int tc;

long long int s;
long long int pw;
long long int w;
long long int N;

vector<pair<long long int, long long int>> tt;

int main() {
  scanf("%d",&tc);
  for (int foo = 1; foo <= tc; ++foo) {
    tt.clear();
    cin >> s >> pw;
    double lb = 0;
double k = 0;
double ex;

    for (int ans = 0; ans < pw; ++ans) {
      cin >> w >> N;
      tt.push_back((pair<long long int, long long int>)(w, N));
      if (k == 0&&w != s) {
        
          k = s * N / (s - w + 0.0);
        } else if (w != s) {
        k = min(k, s * N / (s - w + 0.0));
      }
    }
    for(;abs(k - lb) > 0.0000005f;) {
      ex = (k + lb) / 2;
      bool j = true;
      // cout << "Testing " << ex << endl;
      for (int ans = 0; ans < pw; ++ans) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (tt[ans].second >= ex)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (tt[ans].first / (ex - tt[ans].second) * ex < s) {
          j = false;
        }
      }
      if (j) {
        lb = ex;
      } else {
        k = ex;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << foo << ": " << k << endl;
  }
}
