#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<ll, ll> pll;
typedef pair<int, int> pii;

int k;

long long int p;
long long int dp;
long long int c;
long long int MAXN;

vector<pair<long long int, long long int>> tt;

int main() {
  ios::sync_with_stdio(false);
cin >> k;
  for (int l = 1; l <= k; l++) {
    tt.clear();
    cin >> p >> dp;
    double cur = 0;
double j = 0;
double mid;

    for (int k = 0; k < dp; k++) {
      cin >> c >> MAXN;
      tt.push_back((pair<long long int, long long int>)(c, MAXN));
      if (j == 0) {
        if (c != p) {
          j = p * MAXN / (p - c + 0.0);
        }
      } else if (c != p) {
        j = min(j, p * MAXN / (p - c + 0.0));
      }
    }
    for(;abs(j - cur) > 0.0000005f;) {
      mid = (j + cur) / 2;
      bool base = true;
      // cout << "Testing " << ex << endl;
      for (int ans = 0; ans < dp; ans++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (tt[ans].second >= mid)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (tt[ans].first / (mid - tt[ans].second) * mid < p) {
          base = false;
        }
      }
      if (base) {
        cur = mid;
      } else {
        j = mid;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << l << ": " << j << endl;
  }
return 0;}
