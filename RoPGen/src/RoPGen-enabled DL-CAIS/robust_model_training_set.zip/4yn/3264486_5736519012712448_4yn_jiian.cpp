#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
int cas;

int main() {
  freopen("A-small-attempt1.in","r",stdin);
freopen("123.out","w",stdout);
cin >> cas;
  for (int i = 1; i <= cas; i++) {
    string v;
    int m, ans = 0;
    cin >> v >> m;
    for (int j = 0; j < v.size() - m + 1; j++) {
      if (v[j] == '-') {
        // cout << "Flip at " << i << endl;
        ans++;
        for (int w = j; w < j + m; w++) {
          if (v[w] == '-')
            v[w] = '+';
          else
            v[w] = '-';
        }
      }
    }
    int l = 1;
    for (int x = v.size() - m + 1; x < v.size(); x++) {
      if (v[x] == '-')
        l = 0;
    }
    if (l == 1) {
      printf("Case #%d: %d\n", i, ans);
    } else {
      printf("Case #%d: IMPOSSIBLE\n", i, ans);
    }
  }
return 0;}
