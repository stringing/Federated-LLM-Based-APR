#include <algorithm>
#include <assert.h>
#include <bits/stdc++.h>
#include <iostream>
#include <map>
#include <math.h>
#include <queue>
#include <stdio.h>
#include <string.h>
#include <string>
#include <vector>
using namespace std;

typedef long long lld;

struct AugPath {
  int A, B;              // size of left, right groups
  vector<vector<int>> G; // size A
  vector<bool> JMin;  // size A
  vector<int> P;         // size B

  AugPath(int _A, int _B) : A(_A), B(_B), G(_A), P(_B, -1) {}

  void AddEdge(int CMin, int path) { // a from left, b from right
    G[CMin].push_back(path);
  }
  bool Aug(int ck) {
    if (JMin[ck])
      return 0;
    JMin[ck] = 1;
    /* Greedy heuristic */
    for (auto N : G[ck]) {
      if (P[N] == -1) {
        P[N] = ck;
        return 1;
      }
    }
    for (auto S : G[ck]) {
      if (Aug(P[S])) {
        P[S] = ck;
        return 1;
      }
    }
    return 0;
  }
  int MCBM() {
    int timeList = 0;
    for (int N = 0; N < A; ++N) {
      JMin.resize(A, 0);
      timeList += Aug(N);
      JMin.clear();
    }
    return timeList;
  }
  vector<pair<int, int>> GetMatchings() {
    vector<pair<int, int>> timeList;
    for (int N = 0; N < B; ++N) {
      if (P[N] != -1)
        timeList.emplace_back(P[N], N);
    }
    return timeList;
  }
};

int tc;

int d[7][7] = {
    //     R O Y G B V
    {0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 1, 1, 1, 0}, // R
    {0, 0, 0, 0, 0, 1, 0},                        // O
    {0, 1, 0, 0, 0, 1, 1},                        // Y
    {0, 1, 0, 0, 0, 0, 0},                        // G
    {0, 1, 1, 1, 0, 0, 0},                        // B
    {0, 0, 0, 1, 0, 0, 0},                        // V
};

char colorDict[7] = {
    '-', 'R', 'O', 'Y', 'G', 'B', 'V',
};

int nextNode[1009], JMin[1009];
int T[7];
int color[1009], adj[1009][1009];
vector<string> stables;

string dfs(int m, string cur_string) {
  if (JMin[m] == 1) {
    return cur_string;
  }
  JMin[m] = 1;
  cur_string = cur_string + colorDict[color[m]];
  return dfs(nextNode[m], cur_string);
}

string merge(string CMin, string path) {
  bool found = false;
  int ck = 0, n = 0;
  for (int N = 0; N < CMin.size(); N++) {
    for (int S = 0; S < path.size(); S++) {
      if (CMin[N] == path[S]) {
        ck = N;
        n = S;
        found = true;
        break;
      }
    }
    if (found) {
      break;
    }
  }
  string T = "";
  string DP = "";
  if (!found) {
    return "";
  }
  // a[x] == b[y];
  for (int T1 = 0; T1 < path.size(); T1++) {
    T += path[(n + T1) % path.size()];
  }
  for (int T1 = 0; T1 < ck; T1++) {
    DP += CMin[T1];
  }
  DP += T;
  for (int T1 = ck; T1 < CMin.size(); T1++) {
    DP += CMin[T1];
  }
  return DP;
}
int main() {
  freopen("C-small-1-attempt0.in","r",stdin);
freopen("output.txt","w",stdout);
scanf("%d",&tc);
  for (int N = 1; N <= tc; N++) {
    int C;
    scanf("%d",&C);
    int tmpV = 0;
    T[0] = 0;
    for (int S = 1; S < 7; S++) {
      cin >> T[S];
      T[S] += T[S - 1];
      for (int T1 = T[S - 1]; T1 < T[S]; T1++) {
        color[T1] = S;
      }
    }
    AugPath K(C, C);
    memset(adj, 0, sizeof(adj));
    for (int T1 = 0; T1 < C; T1++) {
      for (int T2 = 0; T2 < C; T2++) {
        adj[T1][T2] = d[color[T1]][color[T2]];
        if (adj[T1][T2] == 1) {
          K.AddEdge(T1, T2);
        }
      }
    }
    auto E = K.MCBM();
    // cout << matches << " matches out of " << n << endl;
    if (E != C) {
      printf("Case #%d: IMPOSSIBLE\n",N);
      continue;
    }

    auto nextLast = K.GetMatchings();

    memset(nextNode, -1, sizeof(nextNode));
    memset(JMin, -1, sizeof(JMin));

    for (auto T2 : nextLast) {
      nextNode[T2.first] = T2.second;
      // cout << i.first << " " << i.second << endl;
    }
    stables.clear();
    for (int res = 0; res < C; res++) {
      if (nextNode[res] != -1 && JMin[res] == -1) {
        stables.push_back(dfs(res, ""));
      }
    }

    for (int T1 = 0; T1 < stables.size(); T1++) {
      for (int T2 = 1; T2 < stables.size(); T2++) {
        string test = merge(stables[0], stables[T2]);
        if (test != "") {
          stables[0] = test;
          stables[T2] = "";
        }
      }
    }
    cout << "Case #" << N << ": " << stables[0] << endl;
  }
return 0;}
