#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef long long LL;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<int> vi;
struct AugPath {
  int A, m;              // size of left, right groups
  vector<vector<int>> G; // size A
  vector<bool> minute;  // size A
  vector<int> P;         // size B

  AugPath(int _A, int st_with) : A(_A), m(st_with), G(_A), P(st_with, -1) {}

  void AddEdge(int memo, int aj) { // a from left, b from right
    G[memo].push_back(aj);
  }
  bool Aug(int x) {
    if (minute[x])
      return 0;
    minute[x] = 1;
    /* Greedy heuristic */
    for (auto tot : G[x]) {
      if (P[tot] == -1) {
        P[tot] = x;
        return 1;
      }
    }
    for (auto bs : G[x]) {
      if (Aug(P[bs])) {
        P[bs] = x;
        return 1;
      }
    }
    return 0;
  }
  int MCBM() {
    int pancake = 0;
    for (int tot = 0; tot < A; ++tot) {
      minute.resize(A, 0);
      pancake += Aug(tot);
      minute.clear();
    }
    return pancake;
  }
  vector<pair<int, int>> GetMatchings() {
    vector<pair<int, int>> pancake;
    for (int tot = 0; tot < m; ++tot) {
      if (P[tot] != -1)
        pancake.emplace_back(P[tot], tot);
    }
    return pancake;
  }
};

int tc;

int d[7][7] = {
    //     R O Y G B V
    {0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 1, 1, 1, 0}, // R
    {0, 0, 0, 0, 0, 1, 0},                        // O
    {0, 1, 0, 0, 0, 1, 1},                        // Y
    {0, 1, 0, 0, 0, 0, 0},                        // G
    {0, 1, 1, 1, 0, 0, 0},                        // B
    {0, 0, 0, 1, 0, 0, 0},                        // V
};

char color_dict[7] = {
    '-', 'R', 'O', 'Y', 'G', 'B', 'V',
};

int str[1009], minute[1009];
int idx[7];
int color[1009], adj[1009][1009];
vector<string> stables;

string dfs(int ac, string cur_string) {
  if (minute[ac] == 1) {
    return cur_string;
  }
  minute[ac] = 1;
  cur_string = cur_string + color_dict[color[ac]];
  return dfs(str[ac], cur_string);
}

string merge(string memo, string aj) {
  bool found = false;
  int x = 0, sisa = 0;
  for (int tot = 0; tot < memo.size(); tot++) {
    for (int bs = 0; bs < aj.size(); bs++) {
      if (memo[tot] == aj[bs]) {
        x = tot;
        sisa = bs;
        found = true;
        break;
      }
    }
    if (found) {
      break;
    }
  }
  if (!found) {
    return "";
  }
  // a[x] == b[y];
  string idx = "";
  for (int xy = 0; xy < aj.size(); xy++) {
    idx += aj[(sisa + xy) % aj.size()];
  }
  string cur = "";
  for (int k = 0; k < x; k++) {
    cur += memo[k];
  }
  cur += idx;
  for (int k = x; k < memo.size(); k++) {
    cur += memo[k];
  }
  return cur;
}
int main() {
  freopen("D:/OneDrive/Code/GCJ/A-large.in","r",stdin);
freopen("D:/OneDrive/Code/GCJ/out.txt","w",stdout);
scanf("%d",&tc);
  for (int tot = 1; tot <= tc; tot++) {
    int v;
    scanf("%d",&v);
    int arr = 0;
    idx[0] = 0;
    for (int bs = 1; bs < 7; bs++) {
      cin >> idx[bs];
      idx[bs] += idx[bs - 1];
      for (int xy = idx[bs - 1]; xy < idx[bs]; xy++) {
        color[xy] = bs;
      }
    }
    AugPath z(v, v);
    memset(adj, 0, sizeof(adj));
    for (int k = 0; k < v; k++) {
      for (int st = 0; st < v; st++) {
        adj[k][st] = d[color[k]][color[st]];
        if (adj[k][st] == 1) {
          z.AddEdge(k, st);
        }
      }
    }
    auto f = z.MCBM();
    // cout << matches << " matches out of " << n << endl;
    if (f != v) {
      printf("Case #%d: IMPOSSIBLE\n",tot);
      continue;
    }

    auto en = z.GetMatchings();

    memset(str, -1, sizeof(str));
    memset(minute, -1, sizeof(minute));

    for (auto k : en) {
      str[k.first] = k.second;
      // cout << i.first << " " << i.second << endl;
    }
    stables.clear();
    for (int k = 0; k < v; k++) {
      if (str[k] != -1 && minute[k] == -1) {
        stables.push_back(dfs(k, ""));
      }
    }

    for (int k = 0; k < stables.size(); k++) {
      for (int k = 1; k < stables.size(); k++) {
        string test = merge(stables[0], stables[k]);
        if (test != "") {
          stables[0] = test;
          stables[k] = "";
        }
      }
    }
    cout << "Case #" << tot << ": " << stables[0] << endl;
  }
return 0;}
