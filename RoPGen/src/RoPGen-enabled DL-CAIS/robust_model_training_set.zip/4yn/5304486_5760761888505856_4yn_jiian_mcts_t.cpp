#include <fstream>
#include <iostream>
#include <stdio.h>

using namespace std;
ifstream fin;

int ans;

inline void qynyjxvrrn(char cake[30][30], int &i, int &n) {
  cake[i][n] = cake[i][n - 1];
}

inline void faexmslzts(char cake[30][30], int &i, int &n) {
  cake[i][n] = cake[i][n + 1];
}

inline void ouuxeztrhc(char cake[30][30], int &i, int &n) {
  cake[i][n] = cake[i - 1][n];
}

inline void lbmriiwiqb(char cake[30][30], int &i, int &n) {
  cake[i][n] = cake[i + 1][n];
}

inline void alkblurdia(int &m) {
  int r, cas;
  fin >> r >> cas;
  char cake[30][30];
  for (int i = 0; i < r; i++) {
    for (int n = 0; n < cas; n++) {
      fin >> cake[i][n];
    }
  }
  int i;
  for (i = 0; i < r; i++) {
    // sweep left to right
    for (int n = 1; n < cas; n++) {
      if (cake[i][n - 1] != '?' && cake[i][n] == '?')
        qynyjxvrrn(cake, i, n);
    }
    // sweep right to left
    for (int n = cas - 2; n >= 0; n--) {
      if (cake[i][n + 1] != '?' && cake[i][n] == '?')
        faexmslzts(cake, i, n);
    }
  }
  for (int i = 1; i < r; i++) {
    // sweep up to down
    if (cake[i - 1][0] != '?' && cake[i][0] == '?') {
      for (int n = 0; n < cas; n++)
        ouuxeztrhc(cake, i, n);
    }
  }
  for (int i = r - 1; i >= 0; i--) {
    // sweep down to up
    if (cake[i + 1][0] != '?' && cake[i][0] == '?') {
      for (int n = 0; n < cas; n++)
        lbmriiwiqb(cake, i, n);
    }
  }
  printf("Case #%d:\n", m);
  for (int i = 0; i < r; i++) {
    for (int n = 0; n < cas; n++) {
      printf("%c", cake[i][n]);
    }
    printf("\n");
  }
}

int main() {
  fin.open("/home/hx/data/Mis/media/ramdisk/blackbox_5304486_5760761888505856_15_CCS18_RNN_800_True_MCTS_Classic_True/jiian/4yn/A-small-practice.in");

  fin >> ans;
  {
    int m = 1;
    while (m <= ans) {
      alkblurdia(m);
      m++;
    }
  }
}
