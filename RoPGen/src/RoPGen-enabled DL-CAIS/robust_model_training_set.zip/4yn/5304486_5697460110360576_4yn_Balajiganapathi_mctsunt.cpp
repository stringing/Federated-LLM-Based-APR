#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;

int tc;
int n, p;
lli r[1009];

lli eleven(lli x) { return x * 11 / 10; }

lli ninety(lli x) {
  lli y = x * 9 / 10;
  if (x % 10 != 0) {
    y += 1;
  }
  return y;
}

bool inrange(int ingredient, lli number, lli servings) {
  lli x = r[ingredient] * servings;
  return (ninety(x) <= number) && (number <= eleven(x));
}

int main() {
  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    lli tmp;
    priority_queue<lli, vector<lli>, greater<lli>> q[1009];
    memset(r, -1, sizeof(r));
    cin >> n >> p;
    for (int ord = 0; ord < n; ord++) {
      cin >> r[ord];
    }
    for (int ord = 0; ord < n; ord++) {
      for (int j = 0; j < p; j++) {
        cin >> tmp;
        q[ord].push(tmp);
      }
    }
    lli ans = 0;
    lli cansendserving = 1;
    lli curservingsize = 1;
    lli nextservingsize = 1;
    while (1) {
      // if can send serving
      bool okay = 1;
      cansendserving = 1;
      for (int ord = 0; ord < n; ord++) {
        if (q[ord].empty()) {
          okay = 0;
          break;
        }
        if (!inrange(ord, q[ord].top(), curservingsize)) {
          cansendserving = 0;
        }
      }

      if (!okay) {
        break;
      }

      if (cansendserving) {
        // cout << "Send\n";
        ans++;
        for (int ord = 0; ord < n; ord++) {
          q[ord].pop();
        }
      } else {
        // find next serving size to make
        nextservingsize = 9999999999;
        for (int ord = 0; ord < n; ord++) {
          if (q[ord].empty())
            break;
          nextservingsize = min(nextservingsize, q[ord].top() / eleven(r[ord]));
        }
        if (nextservingsize <= curservingsize) {
          nextservingsize = curservingsize + 1;
        }
        curservingsize = nextservingsize;
        // flush
        for (int ord = 0; ord < n; ord++) {
          while (!q[ord].empty() && q[ord].top() < ninety(r[ord] * curservingsize)) {
            q[ord].pop();
          }
          if (q[ord].empty()) {
            okay = 0;
            break;
          }
        }
        if (!okay) {
          break;
        }
      }
    }
    cout << "Case #" << t << ": " << ans << endl;
  }
}
