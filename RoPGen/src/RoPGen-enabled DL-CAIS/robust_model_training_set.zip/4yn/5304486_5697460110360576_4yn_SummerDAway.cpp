#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
using namespace std;
int tc;
int HD, m;
long long int ch[1009];

long long int eleven(long long int TC) { return TC * 11 / 10; }

long long int ninety(long long int TC) {
  long long int a = TC * 9 / 10;
  if (TC % 10 != 0) {
    a += 1;
  }
  return a;
}

bool inrange(int ans, long long int f, long long int b) {
  long long int TC = ch[ans] * b;
  return (ninety(TC) <= f) && (f <= eleven(TC));
}

int main() {
  freopen("D-small-attempt1.in","r",stdin);
freopen("D-small-attempt1.out","w",stdout);
scanf("%d",&tc);
  for (int t = 1; t <= tc; ++t) {
    long long int k;
    priority_queue<long long int, vector<long long int>, greater<long long int>> q[1009];
    memset(ch, -1, sizeof(ch));
    long long int l = 0;
long long int o = 1;
long long int x1 = 1;
long long int nextservingsize = 1;

    
    
    
    scanf("%d%d",&HD,&m);
    for (int tc = 0; tc < HD; ++tc) {
      cin >> ch[tc];
    }
    for (int x2 = 0; x2 < HD; ++x2) {
      for (int x3 = 0; x3 < m; ++x3) {
        cin >> k;
        q[x2].push(k);
      }
    }
    for(;1;) {
      // if can send serving
      bool okay = 1;
      o = 1;
      for (int x2 = 0; x2 < HD; ++x2) {
        if (q[x2].empty()) {
          okay = 0;
          break;
        }
        if (!inrange(x2, q[x2].top(), x1)) {
          o = 0;
        }
      }

      if (!okay) {
        break;
      }

      if (o) {
        // cout << "Send\n";
        ++l;
        for (int x2 = 0; x2 < HD; ++x2) {
          q[x2].pop();
        }
      } else {
        // find next serving size to make
        nextservingsize = 9999999999;
        for (int x2 = 0; x2 < HD; ++x2) {
          if (q[x2].empty())
            break;
          nextservingsize = min(nextservingsize, q[x2].top() / eleven(ch[x2]));
        }
        if (nextservingsize <= x1) {
          nextservingsize = x1 + 1;
        }
        x1 = nextservingsize;
        // flush
        for (int x2 = 0; x2 < HD; ++x2) {
          for(;!q[x2].empty() && q[x2].top() < ninety(ch[x2] * x1);) {
            q[x2].pop();
          }
          if (q[x2].empty()) {
            okay = 0;
            break;
          }
        }
        if (!okay) {
          break;
        }
      }
    }
    cout << "Case #" << t << ": " << l << endl;
  }
}
