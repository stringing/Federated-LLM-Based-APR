#include <algorithm>
#include <assert.h>
#include <bits/stdc++.h>
#include <iostream>
#include <map>
#include <math.h>
#include <queue>
#include <stdio.h>
#include <string.h>
#include <string>
#include <vector>
using namespace std;

typedef long long lld;

int T;

int main() {
  freopen("B-small-attempt0.in","r",stdin);
freopen("output.txt","w",stdout);
scanf("%d",&T);
  for (int T2 = 1; T2 <= T; T2++) {
    string T1;
    int A, P = 0;
    cin >> T1 >> A;
    for (int testCase = 0; testCase < T1.size() - A + 1; testCase++) {
      if (T1[testCase] == '-') {
        // cout << "Flip at " << i << endl;
        P++;
        for (int B = testCase; B < testCase + A; B++) {
          if (T1[B] == '-')
            T1[B] = '+';
          else
            T1[B] = '-';
        }
      }
    }
    int N = 1;
    for (int testCase = T1.size() - A + 1; testCase < T1.size(); testCase++) {
      if (T1[testCase] == '-')
        N = 0;
    }
    if (N == 1) {
      printf("Case #%d: %d\n", T2, P);
    } else {
      printf("Case #%d: IMPOSSIBLE\n", T2, P);
    }
  }
return 0;}
