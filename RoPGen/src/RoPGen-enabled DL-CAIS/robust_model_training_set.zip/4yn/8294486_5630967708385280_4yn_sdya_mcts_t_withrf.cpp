#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stdio.h>
#include <string>
#include <vector>
using namespace std;

typedef long long int lli;
typedef pair<lli, lli> pii;
typedef double dbl;

int tc;

lli d, n, readData, b;
vector<pii> ks;

int main() {
  scanf("%d ", &tc);
  for (int t = 1; t <= tc; t++) {
    ks.clear();
    scanf("%lld %lld ", &d, &n);
    dbl lb, ub, ex;
    lb = 0;
    ub = 0;
    for (int i = 0; i < n; i++) {
      scanf("%lld %lld ", &readData, &b);
      ks.push_back(pii(readData, b));
      if (ub == 0) {
        if (readData != d) {
          ub = d * b / (d - readData + 0.0);
        }
      } else if (readData != d) {
        ub = min(ub, d * b / (d - readData + 0.0));
      }
    }
    while (abs(ub - lb) > 0.0000005f) {
      ex = (ub + lb) / 2;
      bool f = true;
      // cout << "Testing " << ex << endl;
      for (int i = 0; i < n; i++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (ks[i].second >= ex)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (ks[i].first / (ex - ks[i].second) * ex < d) {
          f = false;
        }
      }
      if (f) {
        lb = ex;
      } else {
        ub = ex;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << t << ": " << ub << endl;
  }
}
