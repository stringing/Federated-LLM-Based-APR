#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
int t;

void split_main_8_54(int* t) {
  for (int l = 1; l <= (*t); l++) {
    int v, m;
    cin >> v >> m;
    char n[30][30];
    for (int ans = 0; ans < v; ans++) {
      for (int x = 0; x < m; x++) {
        cin >> n[ans][x];
      }
    }
    for (int ans = 0; ans < v; ans++) {
      // sweep left to right
      for (int x = 1; x < m; x++) {
        if (n[ans][x - 1] != '?' && n[ans][x] == '?') {
          n[ans][x] = n[ans][x - 1];
        }
      }
      // sweep right to left
      for (int x = m - 2; x >= 0; x--) {
        if (n[ans][x + 1] != '?' && n[ans][x] == '?') {
          n[ans][x] = n[ans][x + 1];
        }
      }
    }
    for (int ans = 1; ans < v; ans++) {
      // sweep up to down
      if (n[ans - 1][0] != '?' && n[ans][0] == '?') {
        for (int x = 0; x < m; x++) {
          n[ans][x] = n[ans - 1][x];
        }
      }
    }
    for (int ans = v - 1; ans >= 0; ans--) {
      // sweep down to up
      if (n[ans + 1][0] != '?' && n[ans][0] == '?') {
        for (int x = 0; x < m; x++) {
          n[ans][x] = n[ans + 1][x];
        }
      }
    }
    cout << "Case #" << l << ":\n";
    for (int ans = 0; ans < v; ans++) {
      for (int x = 0; x < m; x++) {
        cout << n[ans][x];
      }
      cout << endl;
    }
  }
}
int main() {
  freopen("C-small-1-attempt0.in","r",stdin);
freopen("out0.out","w",stdout);
cin >> t;
  split_main_8_54(&t);

return 0;}
