#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <vector>
using namespace std;
typedef long long ll;
int t;

int main() {
  ios::sync_with_stdio(false);
freopen("test.txt","r",stdin);
freopen("test1.txt","w",stdout);
cin >> t;
  for (int j = 1; j <= t; j++) {
    int cur, av;
    cin >> cur >> av;
    priority_queue<int> ans;
    ans.push(cur);
    int bad, curMax;
    for (int b = 0; b < av; b++) {
      int j = ans.top() - 1;
      ans.pop();
      bad = j / 2 + (j % 2);
      curMax = j / 2;
      ans.push(bad);
      ans.push(curMax);
    }
    cout<<"Case #"<<j<<": "<<bad<<" "<<curMax<<"\n"<<endl;
  }
}
