#include <bits/stdc++.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
using namespace std;
ofstream fout;
ifstream fin;
typedef long long ll;

int tc;
int n, lenn;
long long int r[1009];

long long int willCatch(long long int s) { return s * 11 / 10; }

long long int ninety(long long int s) {
  long long int y = s * 9 / 10;
  if (s % 10 != 0) {
    y += 1;
  }
  return y;
}

bool T(int lftt, long long int a, long long int servings) {
  long long int s = r[lftt] * servings;
  return (ninety(s) <= a) && (a <= willCatch(s));
}

int main() {
  fin.open("test.input.in");
fout.open("test.output.out");
cin >> tc;
  for (int t = 1; t <= tc; t++) {
    long long int tmp;
    priority_queue<long long int, vector<long long int>, greater<long long int>> q[1009];
    memset(r, -1, sizeof(r));
    fin >> n >> lenn;
    for (int k = 0; k < n; k++) {
      cin >> r[k];
    }
    for (int k = 0; k < n; k++) {
      for (int vv = 0; vv < lenn; vv++) {
        fin >> tmp;
        q[k].push(tmp);
      }
    }
    long long int len = 0;
    long long int ok = 1;
    long long int curservingsize = 1;
    long long int nextservingsize = 1;
    while (1) {
      // if can send serving
      bool mid = 1;
      ok = 1;
      for (int k = 0; k < n; k++) {
        if (q[k].empty()) {
          mid = 0;
          break;
        }
        if (!T(k, q[k].top(), curservingsize)) {
          ok = 0;
        }
      }

      if (!mid) {
        break;
      }

      if (ok) {
        // cout << "Send\n";
        len++;
        for (int k = 0; k < n; k++) {
          q[k].pop();
        }
      } else {
        // find next serving size to make
        nextservingsize = 9999999999;
        for (int k = 0; k < n; k++) {
          if (q[k].empty())
            break;
          nextservingsize = min(nextservingsize, q[k].top() / willCatch(r[k]));
        }
        if (nextservingsize <= curservingsize) {
          nextservingsize = curservingsize + 1;
        }
        curservingsize = nextservingsize;
        // flush
        for (int k = 0; k < n; k++) {
          while (!q[k].empty() && q[k].top() < ninety(r[k] * curservingsize)) {
            q[k].pop();
          }
          if (q[k].empty()) {
            mid = 0;
            break;
          }
        }
        if (!mid) {
          break;
        }
      }
    }
    fout << "Case #" << t << ": " << len << endl;
  }
}
