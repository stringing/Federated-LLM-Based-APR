#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>
using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef long double lld;
typedef pair<int, int> PII;
typedef pair<ll, ll> PLL;
typedef vector<int> VI;
typedef vector<string> VS;
typedef vector<double> VD;

int even;

long long int memo;
long long int Tcas;
long long int ret;
long long int inf;

vector<pair<long long int, long long int>> Tcase;

int main() {
  freopen("a.in","r",stdin);
freopen("a.out","w",stdout);
cin >> even;
  for (int k = 1; k <= even; k++) {
    Tcase.clear();
    cin >> memo >> Tcas;
    double p = 0;
double j = 0;
double st;

    for (int temp = 0; temp < Tcas; temp++) {
      cin >> ret >> inf;
      Tcase.push_back((pair<long long int, long long int>)(ret, inf));
      if (j == 0&&ret != memo) {
        
          j = memo * inf / (memo - ret + 0.0);
        } else if (ret != memo) {
        j = min(j, memo * inf / (memo - ret + 0.0));
      }
    }
    for(;abs(j - p) > 0.0000005f;) {
      st = (j + p) / 2;
      bool newCameronTime = true;
      // cout << "Testing " << ex << endl;
      for (int v = 0; v < Tcas; v++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (Tcase[v].second >= st)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (Tcase[v].first / (st - Tcase[v].second) * st < memo) {
          newCameronTime = false;
        }
      }
      if (newCameronTime) {
        p = st;
      } else {
        j = st;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << k << ": " << j << endl;
  }
}
