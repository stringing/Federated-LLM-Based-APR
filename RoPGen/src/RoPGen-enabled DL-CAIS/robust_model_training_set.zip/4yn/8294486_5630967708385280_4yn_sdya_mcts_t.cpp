#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <set>
#include <string>
using namespace std;

typedef long long int lli;

typedef double dbl;

int tc;

lli d, left_bound, a, b;
vector<pair<lli, lli>> ks;

inline void ekqtzqjcrk(dbl &ub) {
  int i = 0;
  for (; i < left_bound;) {
    cin >> a >> b;
    ks.push_back(pair<lli, lli>(a, b));
    if (ub == 0) {
      if (a != d) {
        ub = d * b / (d - a + 0.0);
      }
    } else {
      if (a != d) {
        ub = min(ub, d * b / (d - a + 0.0));
      }
    }
    i++;
  }
}

int main() {
  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_8294486_5630967708385280_15_CCS18_RNN_800_True_MCTS_Classic_True/sdya/4yn/A-small-practice.in",
          "r", stdin);

  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    ks.clear();
    cin >> d >> left_bound;
    dbl lb, ub, ex;
    lb = 0;
    ub = 0;
    ekqtzqjcrk(ub);
    while (abs(ub - lb) > 0.0000005f) {
      ex = (ub + lb) / 2;
      int f = true;
      // cout << "Testing " << ex << endl;
      for (int i = 0; i < left_bound; i++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (ks[i].second >= ex)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (ks[i].first / (ex - ks[i].second) * ex < d) {
          f = false;
        }
      }
      if (f) {
        lb = ex;
      } else {
        ub = ex;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << t << ": " << ub << endl;
  }
}
