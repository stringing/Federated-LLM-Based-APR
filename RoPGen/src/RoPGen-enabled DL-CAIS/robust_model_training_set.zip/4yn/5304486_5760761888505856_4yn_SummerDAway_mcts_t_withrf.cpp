#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <stdio.h>
using namespace std;

int tc;

inline void hihmxmqfew(char cake[30][30], int &i, int &b) {
  printf("%c", cake[i][b]);
}

int main() {
  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_5304486_5760761888505856_15_CCS18_RNN_800_True_MCTS_Classic_True/SummerDAway/4yn/A-small-practice.in",
          "r", stdin);

  cin >> tc;
  for (int TC = 1; TC <= tc; TC++) {
    int r, ans;
    cin >> r >> ans;
    char cake[30][30];
    for (int i = 0; i < r; i++) {
      for (int b = 0; b < ans; b++) {
        cin >> cake[i][b];
      }
    }
    for (int i = 0; i < r; i++) {
      // sweep left to right
      for (int b = 1; b < ans; b++) {
        if (cake[i][b - 1] != '?' && cake[i][b] == '?') {
          cake[i][b] = cake[i][b - 1];
        }
      }
      // sweep right to left
      for (int b = ans - 2; b >= 0; b--) {
        if (cake[i][b + 1] != '?' && cake[i][b] == '?') {
          cake[i][b] = cake[i][b + 1];
        }
      }
    }
    for (int i = 1; i < r; i++) {
      // sweep up to down
      if (cake[i - 1][0] != '?' && cake[i][0] == '?') {
        for (int b = 0; b < ans; b++) {
          cake[i][b] = cake[i - 1][b];
        }
      }
    }
    for (int i = r - 1; i >= 0; i--) {
      // sweep down to up
      if (cake[i + 1][0] != '?' && cake[i][0] == '?') {
        for (int b = 0; b < ans; b++) {
          cake[i][b] = cake[i + 1][b];
        }
      }
    }
    printf("Case #%d:\n", TC);
    for (int i = 0; i < r; i++) {
      for (int b = 0; b < ans; b++)
        hihmxmqfew(cake, i, b);
      printf("\n");
    }
  }
}
