#include <algorithm>
#include <bits/stdc++.h>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <stdio.h>
#include <vector>
using namespace std;
ofstream fout;

int ans;

inline void xqalkqlmfz(char cake[30][30], int &i, int &tt) {
  cake[i][tt] = cake[i][tt - 1];
}

int main() {
  fout.open("/home/hx/data/Mis/media/ramdisk/blackbox_5304486_5760761888505856_16_CCS18_RNN_800_True_MCTS_Classic_True/iPeter/4yn/outer_temp/4yn/A-small-practice_transformation.out");

  scanf("%d ", &ans);
  for (int t = 1; t <= ans; t++) {
    int r, c;
    scanf("%d %d ", &r, &c);
    char cake[30][30];
    for (int i = 0; i < r; i++) {
      for (int tt = 0; tt < c; tt++) {
        scanf("%c ", &cake[i][tt]);
      }
    }
    for (int i = 0; i < r; i++) {
      // sweep left to right
      for (int tt = 1; tt < c; tt++) {
        if (cake[i][tt - 1] != '?')
          if (cake[i][tt] == '?')
            xqalkqlmfz(cake, i, tt);
      }
      // sweep right to left
      for (int tt = c - 2; tt >= 0; tt--) {
        if (cake[i][tt + 1] != '?')
          if (cake[i][tt] == '?') {
            cake[i][tt] = cake[i][tt + 1];
          }
      }
    }
    for (int i = 1; i < r; i++) {
      // sweep up to down
      if (cake[i - 1][0] != '?' && cake[i][0] == '?') {
        for (int tt = 0; tt < c; tt++) {
          cake[i][tt] = cake[i - 1][tt];
        }
      }
    }
    for (int i = r - 1; i >= 0; i--) {
      // sweep down to up
      if (cake[i + 1][0] != '?' && cake[i][0] == '?') {
        for (int tt = 0; tt < c; tt++) {
          cake[i][tt] = cake[i + 1][tt];
        }
      }
    }
    fout << "Case #" << t << ":\n";
    for (int i = 0; i < r; i++) {
      for (int tt = 0; tt < c; tt++) {
        fout << cake[i][tt];
      }
      fout << endl;
    }
  }
}
