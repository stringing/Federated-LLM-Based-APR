#include <bits/stdc++.h>
using namespace std;
int N;

int main() {
  scanf("%d",&N);
  for (int ans = 1; ans <= N; ++ans) {
    int n, foo;
    scanf("%d%d",&n,&foo);
    priority_queue<int> pq;
    pq.push(n);
    int j, z;
    for (int i = 0; i < foo; ++i) {
      int ans = pq.top() - 1;
      pq.pop();
      j = ans / 2 + (ans % 2);
      z = ans / 2;
      pq.push(j);
      pq.push(z);
    }
    printf("Case #%d: %d %d\n", ans, j, z);
  }
}
