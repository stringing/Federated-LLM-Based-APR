#include <algorithm>
#include <assert.h>
#include <bits/stdc++.h>
#include <iostream>
#include <map>
#include <math.h>
#include <queue>
#include <stdio.h>
#include <string.h>
#include <string>
#include <vector>
using namespace std;
typedef long long lld;

int m;
int G, JMin;
long long int ck[1009];

long long int eleven(long long int T) { return T * 11 / 10; }

long long int ninety(long long int T) {
  long long int path = T * 9 / 10;
  if (T % 10 != 0) {
    path += 1;
  }
  return path;
}

bool inrange(int CMin, long long int DP, long long int timeList) {
  long long int T = ck[CMin] * timeList;
  return (ninety(T) <= DP) && (DP <= eleven(T));
}

int main() {
  freopen("C-small-1-attempt0.in","r",stdin);
freopen("output.txt","w",stdout);
scanf("%d",&m);
  for (int nextLast = 1; nextLast <= m; nextLast++) {
    long long int P;
    priority_queue<long long int, vector<long long int>, greater<long long int>> C[1009];
    memset(ck, -1, sizeof(ck));
    long long int S = 0;
long long int T2 = 1;
long long int T1 = 1;
long long int E = 1;

    
    
    
    scanf("%d%d",&G,&JMin);
    for (int N = 0; N < G; N++) {
      cin >> ck[N];
    }
    for (int B = 0; B < G; B++) {
      for (int A = 0; A < JMin; A++) {
        cin >> P;
        C[B].push(P);
      }
    }
    for(;1;) {
      // if can send serving
      bool res = 1;
      T2 = 1;
      for (int B = 0; B < G; B++) {
        if (C[B].empty()) {
          res = 0;
          break;
        }
        if (!inrange(B, C[B].top(), T1)) {
          T2 = 0;
        }
      }

      if (!res) {
        break;
      }

      if (T2) {
        // cout << "Send\n";
        S++;
        for (int B = 0; B < G; B++) {
          C[B].pop();
        }
      } else {
        // find next serving size to make
        E = 9999999999;
        for (int B = 0; B < G; B++) {
          if (C[B].empty())
            break;
          E = min(E, C[B].top() / eleven(ck[B]));
        }
        if (E <= T1) {
          E = T1 + 1;
        }
        T1 = E;
        // flush
        for (int B = 0; B < G; B++) {
          for(;!C[B].empty() && C[B].top() < ninety(ck[B] * T1);) {
            C[B].pop();
          }
          if (C[B].empty()) {
            res = 0;
            break;
          }
        }
        if (!res) {
          break;
        }
      }
    }
    cout << "Case #" << nextLast << ": " << S << endl;
  }
return 0;}
