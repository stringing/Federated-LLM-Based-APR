#include <bits/stdc++.h>
#include <iostream>
using namespace std;

typedef long long ll;
typedef pair<ll, ll> pll;
typedef pair<int, int> pii;

int tt;

int main() {
  ios::sync_with_stdio(false);
cin >> tt;
  for (int tc = 1; tc <= tt; tc++) {
    
    
    string cur;int n;
cin >> cur >> n;
    int r = 0;for (int i = 0; i < cur.size() - n + 1; i++) {
      if (cur[i] == '-') {
        // cout << "Flip at " << i << endl;
        r++;
        for (int j = i; j < i + n; j++) {
          if (cur[j] == '-')
            cur[j] = '+';
          else
            cur[j] = '-';
        }
      }
    }
    int base = 1;
    for (int ans = cur.size() - n + 1; ans < cur.size(); ans++) {
      if (cur[ans] == '-')
        base = 0;
    }
    if (base == 1) {
      cout<<"Case #"<<tc<<": "<<r<<"\n"<<endl;
    } else {
      cout<<"Case #"<<tc<<": IMPOSSIBLE\n"<<r<<endl;
    }
  }
return 0;}
