#include <bits/stdc++.h>
using namespace std;

int tt;

int main() {
  scanf("%d",&tt);
  for (int t = 1; t <= tt; t++) {
    string s;
    int foo, fl = 0;
    cin >> s >> foo;
    for (int cc = 0; cc < s.size() - foo + 1; cc++) {
      if (s[cc] == '-') {
        // cout << "Flip at " << i << endl;
        ++fl;
        for (int i = cc; i < cc + foo; i++) {
          if (s[i] == '-')
            s[i] = '+';
          else
            s[i] = '-';
        }
      }
    }
    int cc = 1;
    for (int j = s.size() - foo + 1; j < s.size(); j++) {
      if (s[j] == '-')
        cc = 0;
    }
    if (cc == 1) {
      printf("Case #%d: %d\n", t, fl);
    } else {
      printf("Case #%d: IMPOSSIBLE\n", t, fl);
    }
  }
}
