#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef long long LL;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<int> vi;
int idx;

void split_main_8_54(int* idx) {
  for (int st = 1; st <= (*idx); st++) {
    int xy, bs;
    scanf("%d%d",&xy,&bs);
    char x[30][30];
    for (int tot = 0; tot < xy; tot++) {
      for (int found = 0; found < bs; found++) {
        cin >> x[tot][found];
      }
    }
    for (int y = 0; y < xy; y++) {
      // sweep left to right
      for (int k = 1; k < bs; k++) {
        if (x[y][k - 1] != '?' && x[y][k] == '?') {
          x[y][k] = x[y][k - 1];
        }
      }
      // sweep right to left
      for (int k = bs - 2; k >= 0; k--) {
        if (x[y][k + 1] != '?' && x[y][k] == '?') {
          x[y][k] = x[y][k + 1];
        }
      }
    }
    for (int y = 1; y < xy; y++) {
      // sweep up to down
      if (x[y - 1][0] != '?' && x[y][0] == '?') {
        for (int k = 0; k < bs; k++) {
          x[y][k] = x[y - 1][k];
        }
      }
    }
    for (int y = xy - 1; y >= 0; y--) {
      // sweep down to up
      if (x[y + 1][0] != '?' && x[y][0] == '?') {
        for (int k = 0; k < bs; k++) {
          x[y][k] = x[y + 1][k];
        }
      }
    }
    printf("Case #%d:\n",st);
    for (int y = 0; y < xy; y++) {
      for (int k = 0; k < bs; k++) {
        cout << x[y][k];
      }
      printf("\n");
    }
  }
}
int main() {
  freopen("D:/OneDrive/Code/GCJ/A-large.in","r",stdin);
freopen("D:/OneDrive/Code/GCJ/out.txt","w",stdout);
scanf("%d",&idx);
  split_main_8_54(&idx);

return 0;}
