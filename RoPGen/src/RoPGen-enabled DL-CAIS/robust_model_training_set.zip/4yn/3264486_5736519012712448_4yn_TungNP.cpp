#include <bits/stdc++.h>
#include <cmath>
#include <fstream>
#include <string>
using namespace std;

int ar;

int main() {
  cin >> ar;
  for (int t = 1; t <= ar; t++) {
    string score;
    int max_ar_n; int buff = 0;
    cin >> score >> max_ar_n;
    for (int c = 0; c < score.size() - max_ar_n + 1; c++) {
      if (score[c] == '-') {
        // cout << "Flip at " << i << endl;
        buff++;
        for (int Case = c; Case < c + max_ar_n; Case++) {
          if (score[Case] == '-')
            score[Case] = '+';
          else
            score[Case] = '-';
        }
      }
    }
    int r = 1;
    for (int Case = score.size() - max_ar_n + 1; Case < score.size(); Case++) {
      if (score[Case] == '-')
        r = 0;
    }
    if (r == 1) {
      printf("Case #%d: %d\n", t, buff);
    } else {
      printf("Case #%d: IMPOSSIBLE\n", t, buff);
    }
  }
return 0;}
