#include <bits/stdc++.h>
using namespace std;
typedef long long td_ll;

int cas;
int n, p;
long long r[1009];

long long eleven(long long x) { return x * 11 / 10; }

long long ninety(long long x) {
  td_ll y = x * 9 / 10;
  if (x % 10 != 0) {
    y += 1;
  }
  return y;
}

bool inrange(int ingredient, long long number, long long servings) {
  td_ll x = r[ingredient] * servings;
  return (ninety(x) <= number) && (number <= eleven(x));
}

inline void kvnkbkqaoi(
    priority_queue<long long, vector<long long>, greater<long long>> q[1009],
    int &i) {
  q[i].pop();
}

inline void grahckfibp(
    priority_queue<long long, vector<long long>, greater<long long>> q[1009],
    int &i, td_ll &tmp) {
  int j = 0;
  while (j < p) {
    cin >> tmp;
    q[i].push(tmp);
    j++;
  }
}

int main() {
  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_5304486_5697460110360576_15_CCS18_RNN_800_True_MCTS_Classic_True/jiian/4yn/outer_temp/4yn/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_5304486_5697460110360576_15_CCS18_RNN_800_True_MCTS_Classic_True/jiian/4yn/A-small-practice.in",
          "r", stdin);

  cin >> cas;
  for (int t = 1; t <= cas; t++) {
    td_ll tmp;
    priority_queue<long long, vector<long long>, greater<long long>> q[1009];
    memset(r, -1, sizeof(r));
    cin >> n >> p;
    for (int i = 0; i < n; i++) {
      cin >> r[i];
    }
    for (int i = 0; i < n; i++) {
      grahckfibp(q, i, tmp);
    }
    td_ll ans = 0;
    td_ll cansendserving = 1;
    td_ll curservingsize = 1;
    td_ll nextservingsize = 1;
    while (1) {
      // if can send serving
      bool okay = 1;
      cansendserving = 1;
      for (int i = 0; i < n; i++) {
        if (q[i].empty()) {
          okay = 0;
          break;
        }
        if (!inrange(i, q[i].top(), curservingsize)) {
          cansendserving = 0;
        }
      }

      if (!okay) {
        break;
      }

      if (cansendserving) {
        // cout << "Send\n";
        ans++;
        for (int i = 0; i < n; i++) {
          q[i].pop();
        }
      } else {
        // find next serving size to make
        nextservingsize = 9999999999;
        for (int i = 0; i < n; i++) {
          if (q[i].empty())
            break;
          nextservingsize = min(nextservingsize, q[i].top() / eleven(r[i]));
        }
        if (nextservingsize <= curservingsize) {
          nextservingsize = curservingsize + 1;
        }
        curservingsize = nextservingsize;
        // flush
        for (int i = 0; i < n; i++) {
          while (!q[i].empty() && q[i].top() < ninety(r[i] * curservingsize))
            kvnkbkqaoi(q, i);
          if (q[i].empty()) {
            okay = 0;
            break;
          }
        }
        if (!okay) {
          break;
        }
      }
    }
    cout << "Case #" << t << ": " << ans << endl;
  }
}
