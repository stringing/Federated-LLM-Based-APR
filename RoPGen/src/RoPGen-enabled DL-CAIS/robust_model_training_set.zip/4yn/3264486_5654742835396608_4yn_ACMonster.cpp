#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <set>
#include <vector>
using namespace std;
int totalTest;

int main() {
  scanf("%d",&totalTest);
  for (int test = 1; test <= totalTest; test++) {
    int m, c;
    scanf("%d%d",&m,&c);
    priority_queue<int> ans;
    ans.push(m);
    int j, a;
    for (int i = 0; i < c; i++) {
      int test = ans.top() - 1;
      ans.pop();
      j = test / 2 + (test % 2);
      a = test / 2;
      ans.push(j);
      ans.push(a);
    }
    printf("Case #%d: %d %d\n", test, j, a);
  }
return 0;}
