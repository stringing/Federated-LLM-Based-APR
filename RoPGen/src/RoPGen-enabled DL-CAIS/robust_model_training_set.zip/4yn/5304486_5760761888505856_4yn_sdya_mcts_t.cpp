#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <fstream>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;
ifstream fin;

int tc;

inline void wxnqpxlczi(char cake[30][30], int &i, int &solve) {
  cake[i][solve] = cake[i][solve - 1];
}

inline void sasrbcagad(char cake[30][30], int &i, int &solve) {
  wxnqpxlczi(cake, i, solve);
}

int main() {
  ios::sync_with_stdio(false);

  fin.open("/home/hx/data/Mis/media/ramdisk/blackbox_5304486_5760761888505856_15_CCS18_RNN_800_True_MCTS_Classic_True/sdya/4yn/A-small-practice.in");

  fin >> tc;
  for (int t = 1; t <= tc; t++) {
    int r, readData;
    fin >> r >> readData;
    char cake[30][30];
    for (int i = 0; i < r; i++) {
      for (int solve = 0; solve < readData; solve++) {
        fin >> cake[i][solve];
      }
    }
    int i;
    {
      i = 0;
      while (i < r) {
        // sweep left to right
        for (int solve = 1; solve < readData; solve++) {
          if (cake[i][solve - 1] != '?' && cake[i][solve] == '?')
            sasrbcagad(cake, i, solve);
        }
        // sweep right to left
        for (int solve = readData - 2; solve >= 0; solve--) {
          if (cake[i][solve + 1] != '?' && cake[i][solve] == '?') {
            cake[i][solve] = cake[i][solve + 1];
          }
        }
        i++;
      }
    }
    for (int i = 1; i < r; i++) {
      // sweep up to down
      if (cake[i - 1][0] != '?' && cake[i][0] == '?') {
        for (int solve = 0; solve < readData; solve++) {
          cake[i][solve] = cake[i - 1][solve];
        }
      }
    }
    for (int i = r - 1; i >= 0; i--) {
      // sweep down to up
      if (cake[i + 1][0] != '?' && cake[i][0] == '?') {
        int solve;
        for (solve = 0; solve < readData; solve++) {
          cake[i][solve] = cake[i + 1][solve];
        }
      }
    }
    cout << "Case #" << t << ":\n";
    {
      int i = 0;
      for (; i < r;) {
        for (int solve = 0; solve < readData; solve++) {
          cout << cake[i][solve];
        }
        cout << endl;
        i++;
      }
    }
  }
}
