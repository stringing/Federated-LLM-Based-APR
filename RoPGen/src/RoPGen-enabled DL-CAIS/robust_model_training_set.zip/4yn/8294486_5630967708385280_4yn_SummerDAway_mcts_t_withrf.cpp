#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <stdio.h>
using namespace std;

typedef long long int lli;

int tc;

lli d, ans, j, b;
vector<pair<lli, lli>> ks;

int main() {
  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_8294486_5630967708385280_15_CCS18_RNN_800_True_MCTS_Classic_True/SummerDAway/4yn/outer_temp/4yn/A-small-practice_transformation.out",
          "w", stdout);

  scanf("%d ", &tc);
  for (int x = 1; x <= tc; x++) {
    ks.clear();
    scanf("%lld %lld ", &d, &ans);
    double lb, TC, y;
    lb = 0;
    TC = 0;
    for (int i = 0; i < ans; i++) {
      scanf("%lld %lld ", &j, &b);
      ks.push_back(pair<lli, lli>(j, b));
      if (TC == 0) {
        if (j != d) {
          TC = d * b / (d - j + 0.0);
        }
      } else {
        if (j != d) {
          TC = min(TC, d * b / (d - j + 0.0));
        }
      }
    }
    while (abs(TC - lb) > 0.0000005f) {
      y = (TC + lb) / 2;
      bool f = true;
      // cout << "Testing " << ex << endl;
      int i;
      for (i = 0; i < ans; i++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (ks[i].second >= y)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (ks[i].first / (y - ks[i].second) * y < d) {
          f = false;
        }
      }
      if (f) {
        lb = y;
      } else {
        TC = y;
      }
    }
    printf("Case #%d: %.7f\n", x, TC);
  }
}
