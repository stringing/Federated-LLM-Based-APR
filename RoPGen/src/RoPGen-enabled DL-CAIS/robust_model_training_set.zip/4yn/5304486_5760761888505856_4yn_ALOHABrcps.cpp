#include <algorithm>
#include <assert.h>
#include <bits/stdc++.h>
#include <iostream>
#include <map>
#include <math.h>
#include <queue>
#include <stdio.h>
#include <string.h>
#include <string>
#include <vector>
using namespace std;

typedef long long lld;

int CMin;

void split_main_42_44(int* S,char T[30][30],int* T1) {
        for (int A = 0; A < (*S); A++) {
          T[(*T1)][A] = T[(*T1) + 1][A];
        }
}
int main() {
  freopen("C-small-1-attempt0.in","r",stdin);
freopen("output.txt","w",stdout);
scanf("%d",&CMin);
  for (int A = 1; A <= CMin; A++) {
    int res, S;
    scanf("%d%d",&res,&S);
    char T2[30][30];
    for (int N = 0; N < res; N++) {
      for (int T1 = 0; T1 < S; T1++) {
        cin >> T2[N][T1];
      }
    }
    for (int T1 = 0; T1 < res; T1++) {
      // sweep left to right
      for (int B = 1; B < S; B++) {
        if (T2[T1][B - 1] != '?' && T2[T1][B] == '?') {
          T2[T1][B] = T2[T1][B - 1];
        }
      }
      // sweep right to left
      for (int B = S - 2; B >= 0; B--) {
        if (T2[T1][B + 1] != '?' && T2[T1][B] == '?') {
          T2[T1][B] = T2[T1][B + 1];
        }
      }
    }
    for (int T1 = 1; T1 < res; T1++) {
      // sweep up to down
      if (T2[T1 - 1][0] != '?' && T2[T1][0] == '?') {
        for (int B = 0; B < S; B++) {
          T2[T1][B] = T2[T1 - 1][B];
        }
      }
    }
    for (int B = res - 1; B >= 0; B--) {
      // sweep down to up
      if (T2[B + 1][0] != '?' && T2[B][0] == '?') {split_main_42_44(&S,T2,&B);
}
    }
    printf("Case #%d:\n",A);
    for (int P = 0; P < res; P++) {
      for (int B = 0; B < S; B++) {
        cout << T2[P][B];
      }
      printf("\n");
    }
  }
return 0;}
