#include <bits/stdc++.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
using namespace std;
ofstream fout;
ifstream fin;

int check;

int main() {
  fin.open("test.input.in");
fout.open("test.output.out");
ios::sync_with_stdio(false);
cin >> check;
  for (int v = 1; v <= check; v++) {
    string s;
    int k, ini = 0;
    fin >> s >> k;
    int i = 0; while (i < s.size() - k + 1)  {
      if (s[i] == '-') {
        // cout << "Flip at " << i << endl;
        ini++;
        for (int res = i; res < i + k; res++) {
          if (s[res] == '-')
            s[res] = '+';
          else
            s[res] = '-';
        }
      }
    i++;
}
    int f = 1;
    for (int i = s.size() - k + 1; i < s.size(); i++) {
      if (s[i] == '-')
        f = 0;
    }
    if (f == 1) {
      printf("Case #%d: %d\n", v, ini);
    } else {
      fout<<"Case #"<<v<<": IMPOSSIBLE\n"<<ini<<endl;
    }
  }
}
