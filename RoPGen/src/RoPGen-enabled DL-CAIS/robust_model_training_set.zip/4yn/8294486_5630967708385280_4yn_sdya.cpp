#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;

int right_bound;

long long int left_bound;
long long int argc;
long long int a;
long long int t;

vector<pair<long long int, long long int>> c;

int main() {
  freopen("input.txt","r",stdin);
freopen("output.txt","w",stdout);
cin >> right_bound;
  for (int s = 1; s <= right_bound; ++s) {
    c.clear();
    cin >> left_bound >> argc;
    double added = 0;
double j = 0;
double score;

    for (int current = 0; current < argc; ++current) {
      cin >> a >> t;
      c.push_back((pair<long long int, long long int>)(a, t));
      if (j == 0&&a != left_bound) {
        
          j = left_bound * t / (left_bound - a + 0.0);
        } else if (a != left_bound) {
        j = min(j, left_bound * t / (left_bound - a + 0.0));
      }
    }
    for(;abs(j - added) > 0.0000005f;) {
      score = (j + added) / 2;
      bool y = true;
      // cout << "Testing " << ex << endl;
      for (int x = 0; x < argc; ++x) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (c[x].second >= score)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (c[x].first / (score - c[x].second) * score < left_bound) {
          y = false;
        }
      }
      if (y) {
        added = score;
      } else {
        j = score;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << s << ": " << j << endl;
  }
return 0;}
