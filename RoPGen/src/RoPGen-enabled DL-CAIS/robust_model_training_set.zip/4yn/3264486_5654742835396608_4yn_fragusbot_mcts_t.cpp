#include <bits/stdc++.h>
using namespace std;

int tt;

int main() {
  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_3264486_5654742835396608_15_CCS18_RNN_800_True_MCTS_Classic_True/fragusbot/4yn/outer_temp/4yn/A-small-practice_transformation.out",
          "w", stdout);

  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_3264486_5654742835396608_15_CCS18_RNN_800_True_MCTS_Classic_True/fragusbot/4yn/A-small-practice.in",
          "r", stdin);

  cin >> tt;
  for (int xxki_Var = 1; xxki_Var <= tt; xxki_Var++) {
    int kopi_Var, ans;
    cin >> kopi_Var >> ans;
    priority_queue<int> pq;
    pq.push(kopi_Var);
    int cc, z;
    for (int i = 0; i < ans; i++) {
      int xxki_Var = pq.top() - 1;
      pq.pop();
      cc = xxki_Var / 2 + (xxki_Var % 2);
      z = xxki_Var / 2;
      pq.push(cc);
      pq.push(z);
    }
    printf("Case #%d: %d %d\n", xxki_Var, cc, z);
  }
}
