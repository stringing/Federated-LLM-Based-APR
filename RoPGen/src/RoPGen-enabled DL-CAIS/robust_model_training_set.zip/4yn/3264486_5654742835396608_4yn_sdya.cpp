#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;
int n;

int main() {
  freopen("input.txt","r",stdin);
freopen("output.txt","w",stdout);
cin >> n;
  for (int i = 1; i <= n; ++i) {
    int l, x;
    cin >> l >> x;
    priority_queue<int> o;
    o.push(l);
    int j, current;
    for (int value = 0; value < x; ++value) {
      int i = o.top() - 1;
      o.pop();
      j = i / 2 + (i % 2);
      current = i / 2;
      o.push(j);
      o.push(current);
    }
    printf("Case #%d: %d %d\n", i, j, current);
  }
return 0;}
