#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
int num;
int len, u;
long long int Case[1009];

long long int eleven(long long int t) { return t * 11 / 10; }

long long int ninety(long long int t) {
  long long int T = t * 9 / 10;
  if (t % 10 != 0) {
    T += 1;
  }
  return T;
}

bool inrange(int cas, long long int ret, long long int cnt) {
  long long int t = Case[cas] * cnt;
  return (ninety(t) <= ret) && (ret <= eleven(t));
}

int main() {
  freopen("C-small-1-attempt0.in","r",stdin);
freopen("out0.out","w",stdout);
cin >> num;
  for (int add = 1; add <= num; add++) {
    long long int pro;
    priority_queue<long long int, vector<long long int>, greater<long long int>> mx[1009];
    memset(Case, -1, sizeof(Case));
    cin >> len >> u;
    for (int l = 0; l < len; l++) {
      cin >> Case[l];
    }
    for (int l = 0; l < len; l++) {
      for (int v = 0; v < u; v++) {
        cin >> pro;
        mx[l].push(pro);
      }
    }
    long long int h = 0;
long long int flag = 1;
long long int m = 1;
long long int need = 1;

    
    
    
    while (1) {
      // if can send serving
      bool k = 1;
      flag = 1;
      for (int l = 0; l < len; l++) {
        if (mx[l].empty()) {
          k = 0;
          break;
        }
        if (!inrange(l, mx[l].top(), m)) {
          flag = 0;
        }
      }

      if (!k) {
        break;
      }

      if (flag) {
        // cout << "Send\n";
        h++;
        for (int l = 0; l < len; l++) {
          mx[l].pop();
        }
      } else {
        // find next serving size to make
        need = 9999999999;
        for (int l = 0; l < len; l++) {
          if (mx[l].empty())
            break;
          need = min(need, mx[l].top() / eleven(Case[l]));
        }
        if (need <= m) {
          need = m + 1;
        }
        m = need;
        // flush
        for (int l = 0; l < len; l++) {
          while (!mx[l].empty() && mx[l].top() < ninety(Case[l] * m)) {
            mx[l].pop();
          }
          if (mx[l].empty()) {
            k = 0;
            break;
          }
        }
        if (!k) {
          break;
        }
      }
    }
    cout << "Case #" << add << ": " << h << endl;
  }
return 0;}
