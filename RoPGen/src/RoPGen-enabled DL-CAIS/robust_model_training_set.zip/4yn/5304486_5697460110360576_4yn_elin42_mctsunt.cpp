#include <bits/stdc++.h>
#include <fstream>
#include <iostream>
#include <iostream>
#include <iostream>
#include <iostream>
#include <stdio.h>
using namespace std;
ofstream fout;
ifstream fin;
int tc;
int n, p;
long long int r[1009];

long long int debugarr(long long int pow2) { return pow2 * 11 / 10; }

long long int containszero(long long int pow2) {
  long long int y = pow2 * 9 / 10;
  if (pow2 % 10 != 0) {
    y += 1;
  }
  return y;
}

bool inrange(int ingredient, long long int number, long long int l) {
  long long int pow2 = r[ingredient] * l;
  return (containszero(pow2) <= number) && (number <= debugarr(pow2));
}

int main() {
  fin.open("test.input.in");
fout.open("test.output.out");
ios::sync_with_stdio(false);
cin >> tc;
  for (int t = 1; t <= tc; t++) {
    long long int tmp;
    priority_queue<long long int, vector<long long int>, greater<long long int>> q[1009];
    memset(r, -1, sizeof(r));
    cin >> n >> p;
    for (int o = 0; o < n; o++) {
      cin >> r[o];
    }
    int o = 0; while (o < n)  {
      for (int j = 0; j < p; j++) {
        fin >> tmp;
        q[o].push(tmp);
      }
    o++;
}
    long long int ans = 0;
    long long int cansendserving = 1;
    long long int curservingsize = 1;
    long long int nextservingsize = 1;
    while (1) {
      // if can send serving
      bool okay = 1;
      cansendserving = 1;
      for (int o = 0; o < n; o++) {
        if (q[o].empty()) {
          okay = 0;
          break;
        }
        if (!inrange(o, q[o].top(), curservingsize)) {
          cansendserving = 0;
        }
      }

      if (!okay) {
        break;
      }

      if (cansendserving) {
        // cout << "Send\n";
        ans++;
        for (int o = 0; o < n; o++) {
          q[o].pop();
        }
      } else {
        // find next serving size to make
        nextservingsize = 9999999999;
        for (int o = 0; o < n; o++) {
          if (q[o].empty())
            break;
          nextservingsize = min(nextservingsize, q[o].top() / debugarr(r[o]));
        }
        if (nextservingsize <= curservingsize) {
          nextservingsize = curservingsize + 1;
        }
        curservingsize = nextservingsize;
        // flush
        for (int o = 0; o < n; o++) {
          while (!q[o].empty() && q[o].top() < containszero(r[o] * curservingsize)) {
            q[o].pop();
          }
          if (q[o].empty()) {
            okay = 0;
            break;
          }
        }
        if (!okay) {
          break;
        }
      }
    }
    fout << "Case #" << t << ": " << ans << endl;
  }
}
