#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef long long LL;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<int> vi;
int tc;

long long int minute;
long long int pancake;
long long int aj;
long long int memo;

vector<pair<long long int, long long int>> idx;

int main() {
  freopen("D:/OneDrive/Code/GCJ/A-large.in","r",stdin);
freopen("D:/OneDrive/Code/GCJ/out.txt","w",stdout);
scanf("%d",&tc);
  for (int x = 1; x <= tc; x++) {
    idx.clear();
    cin >> minute >> pancake;
    double found = 0;
double k = 0;
double tot;

    for (int i = 0; i < pancake; i++) {
      cin >> aj >> memo;
      idx.push_back((pair<long long int, long long int>)(aj, memo));
      if (k == 0&&aj != minute) {
        
          k = minute * memo / (minute - aj + 0.0);
        } else if (aj != minute) {
        k = min(k, minute * memo / (minute - aj + 0.0));
      }
    }
    for(;abs(k - found) > 0.0000005f;) {
      tot = (k + found) / 2;
      bool j = true;
      // cout << "Testing " << ex << endl;
      for (int y = 0; y < pancake; y++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (idx[y].second >= tot)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (idx[y].first / (tot - idx[y].second) * tot < minute) {
          j = false;
        }
      }
      if (j) {
        found = tot;
      } else {
        k = tot;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << x << ": " << k << endl;
  }
return 0;}
