#include <algorithm>
#include <bits/stdc++.h>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;

typedef long long int lli;

int s;

inline void supyabxbpm(int &ans, priority_queue<int> &pq, int &z) {
  int t = pq.top() - 1;
  pq.pop();
  ans = t / 2 + (t % 2);
  z = t / 2;
  pq.push(ans);
  pq.push(z);
}

inline void jxlquzdolg(int &t) {
  int tt, ekji_Var;
  cin >> tt >> ekji_Var;
  priority_queue<int> pq;
  pq.push(tt);
  int ans, z;
  int rfbi_Var;
  for (rfbi_Var = 0; rfbi_Var < ekji_Var; rfbi_Var++)
    supyabxbpm(ans, pq, z);
  printf("Case #%d: %d %d\n", t, ans, z);
}

int main() {

  cin >> s;
  int t;
  for (t = 1; t <= s; t++)
    jxlquzdolg(t);
}
