#include <bits/stdc++.h>
#include <stdio.h>
using namespace std;

int tc;
int n, p;
long long r[1009];

long long eleven(long long x) { return x * 11 / 10; }

long long ninety(long long x) {
  long long y = x * 9 / 10;
  if (x % 10 != 0) {
    y += 1;
  }
  return y;
}

bool inrange(int ingredient, long long number, long long servings) {
  long long x = r[ingredient] * servings;
  return (ninety(x) <= number) && (number <= eleven(x));
}

int main() {
  scanf("%d ", &tc);
  for (int t = 1; t <= tc; t++) {
    long long tmp;
    priority_queue<long long, vector<long long>, greater<long long>> q[1009];
    memset(r, -1, sizeof(r));
    scanf("%d %d ", &n, &p);
    for (int tt = 0; tt < n; tt++) {
      scanf("%lld ", &r[tt]);
    }
    {
      int tt = 0;
      while (tt < n) {
        for (int s = 0; s < p; s++) {
          scanf("%lld ", &tmp);
          q[tt].push(tmp);
        }
        tt++;
      }
    }
    long long ans = 0;
    long long cansendserving = 1;
    long long curservingsize = 1;
    long long nextservingsize = 1;
    while (1) {
      // if can send serving
      bool okay = 1;
      cansendserving = 1;
      for (int tt = 0; tt < n; tt++) {
        if (q[tt].empty()) {
          okay = 0;
          break;
        }
        if (!inrange(tt, q[tt].top(), curservingsize)) {
          cansendserving = 0;
        }
      }

      if (!okay) {
        break;
      }

      if (cansendserving) {
        // cout << "Send\n";
        ans++;
        for (int tt = 0; tt < n; tt++) {
          q[tt].pop();
        }
      } else {
        // find next serving size to make
        nextservingsize = 9999999999;
        for (int tt = 0; tt < n; tt++) {
          if (q[tt].empty())
            break;
          nextservingsize = min(nextservingsize, q[tt].top() / eleven(r[tt]));
        }
        if (nextservingsize <= curservingsize) {
          nextservingsize = curservingsize + 1;
        }
        curservingsize = nextservingsize;
        // flush
        for (int tt = 0; tt < n; tt++) {
          while (!q[tt].empty() &&
                 q[tt].top() < ninety(r[tt] * curservingsize)) {
            q[tt].pop();
          }
          if (q[tt].empty()) {
            okay = 0;
            break;
          }
        }
        if (!okay) {
          break;
        }
      }
    }
    printf("Case #%d: %lld\n", t, ans);
  }
}
