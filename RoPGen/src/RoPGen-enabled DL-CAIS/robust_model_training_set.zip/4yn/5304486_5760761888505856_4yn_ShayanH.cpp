#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<ll, ll> pll;
typedef pair<int, int> pii;

int mid;

void split_main_8_54(int* mid) {
  for (int n = 1; n <= (*mid); n++) {
    
    int l;int cur;
cin >> cur >> l;
    char base[30][30];
    for (int mid = 0; mid < cur; mid++) {
      for (int ans = 0; ans < l; ans++) {
        cin >> base[mid][ans];
      }
    }
    for (int ans = 0; ans < cur; ans++) {
      // sweep left to right
      for (int k = 1; k < l; k++) {
        if (base[ans][k - 1] != '?' && base[ans][k] == '?') {
          base[ans][k] = base[ans][k - 1];
        }
      }
      // sweep right to left
      for (int k = l - 2; k >= 0; k--) {
        if (base[ans][k + 1] != '?' && base[ans][k] == '?') {
          base[ans][k] = base[ans][k + 1];
        }
      }
    }
    for (int ans = 1; ans < cur; ans++) {
      // sweep up to down
      if (base[ans - 1][0] != '?' && base[ans][0] == '?') {
        for (int k = 0; k < l; k++) {
          base[ans][k] = base[ans - 1][k];
        }
      }
    }
    for (int ans = cur - 1; ans >= 0; ans--) {
      // sweep down to up
      if (base[ans + 1][0] != '?' && base[ans][0] == '?') {
        for (int k = 0; k < l; k++) {
          base[ans][k] = base[ans + 1][k];
        }
      }
    }
    cout << "Case #" << n << ":\n";
    for (int ans = 0; ans < cur; ans++) {
      for (int k = 0; k < l; k++) {
        cout << base[ans][k];
      }
      cout << endl;
    }
  }
}
int main() {
  ios::sync_with_stdio(false);
cin >> mid;
  split_main_8_54(&mid);

return 0;}
