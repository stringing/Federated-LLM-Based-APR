#include <algorithm>
#include <bits/stdc++.h>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

typedef long long i64d;

int cas;

int main() {
  freopen("A-small-attempt0.in","r",stdin);
freopen("A-small-attempt0.out","w",stdout);
scanf("%d",&cas);
  for (int res = 1; res <= cas; res++) {
    
    
    string y;int n;
cin >> y >> n;
    int a = 0;for (int ca = 0; ca < y.size() - n + 1; ca++) {
      if (y[ca] == '-') {
        // cout << "Flip at " << i << endl;
        a++;
        for (int x = ca; x < ca + n; x++) {
          if (y[x] == '-')
            y[x] = '+';
          else
            y[x] = '-';
        }
      }
    }
    int b = 1;
    for (int ca = y.size() - n + 1; ca < y.size(); ca++) {
      if (y[ca] == '-')
        b = 0;
    }
    if (b == 1) {
      printf("Case #%d: %d\n", res, a);
    } else {
      printf("Case #%d: IMPOSSIBLE\n", res, a);
    }
  }
return 0;}
