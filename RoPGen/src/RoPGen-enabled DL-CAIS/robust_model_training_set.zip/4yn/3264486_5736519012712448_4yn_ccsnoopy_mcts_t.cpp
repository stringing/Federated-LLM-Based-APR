#include <bits/stdc++.h>
#include <iomanip>
#include <iostream>
#include <utility>
#include <vector>
using namespace std;
typedef pair<int, int> ii;
typedef long long LL;
typedef vector<int> vi;

int tc;

int main() {
  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_3264486_5736519012712448_16_CCS18_RNN_800_True_MCTS_Classic_True/ccsnoopy/4yn/A-small-practice.in", "r", stdin);

  cin >> tc;
  for (int ct = 1; ct <= tc; ct++) {
    string s;
    int k, fl = 0;
    cin >> s >> k;
    for (int i = 0; i < s.size() - k + 1; i++) {
      if (s[i] == '-') {
        // cout << "Flip at " << i << endl;
        fl++;
        for (int j = i; j < i + k; j++) {
          if (s[j] == '-')
            s[j] = '+';
          else
            s[j] = '-';
        }
      }
    }
    int f = 1;
    for (int i = s.size() - k + 1; i < s.size(); i++) {
      if (s[i] == '-')
        f = 0;
    }
    if (f == 1) {
      cout << "Case #" << ct << ": " << fl << "\n";
    } else {
      printf("Case #%d: IMPOSSIBLE\n", ct, fl);
    }
  }
}
