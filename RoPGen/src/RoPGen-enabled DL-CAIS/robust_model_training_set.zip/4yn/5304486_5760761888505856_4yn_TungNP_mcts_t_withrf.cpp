#include <bits/stdc++.h>
#include <cmath>
#include <fstream>
#include <string>
using namespace std;
ifstream fin;

int Case;

int main() {
  fin.open("/home/hx/data/Mis/media/ramdisk/blackbox_5304486_5760761888505856_15_CCS18_RNN_800_True_MCTS_Classic_True/TungNP/4yn/A-small-practice.in");

  fin >> Case;
  for (int t = 1; t <= Case; t++) {
    int r, fout;
    fin >> r >> fout;
    char cake[30][30];
    for (int i = 0; i < r; i++) {
      for (int argc = 0; argc < fout; argc++) {
        fin >> cake[i][argc];
      }
    }
    for (int i = 0; i < r; i++) {
      // sweep left to right
      for (int argc = 1; argc < fout; argc++) {
        if (cake[i][argc - 1] != '?' && cake[i][argc] == '?') {
          cake[i][argc] = cake[i][argc - 1];
        }
      }
      // sweep right to left
      for (int argc = fout - 2; argc >= 0; argc--) {
        if (cake[i][argc + 1] != '?' && cake[i][argc] == '?') {
          cake[i][argc] = cake[i][argc + 1];
        }
      }
    }
    for (int i = 1; i < r; i++) {
      // sweep up to down
      if (cake[i - 1][0] != '?' && cake[i][0] == '?') {
        for (int argc = 0; argc < fout; argc++) {
          cake[i][argc] = cake[i - 1][argc];
        }
      }
    }
    for (int i = r - 1; i >= 0; i--) {
      // sweep down to up
      if (cake[i + 1][0] != '?' && cake[i][0] == '?') {
        for (int argc = 0; argc < fout; argc++) {
          cake[i][argc] = cake[i + 1][argc];
        }
      }
    }
    cout << "Case #" << t << ":\n";
    for (int i = 0; i < r; i++) {
      for (int argc = 0; argc < fout; argc++) {
        cout << cake[i][argc];
      }
      cout << endl;
    }
  }
}
