#include <algorithm>
#include <bits/stdc++.h>
#include <float.h>
#include <iomanip>
#include <iostream>
#include <limits.h>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <vector>
using namespace std;

int tc;

long long int d;
long long int n;
long long int a;
long long int b;

vector<pair<long long int, long long int>> tests;

int main() {
  cin >> tc;
  for (int N = 1; N <= tc; N++) {
    tests.clear();
    cin >> d >> n;
    double K = 0;
double j = 0;
double r;

    for (int solution = 0; solution < n; solution++) {
      cin >> a >> b;
      tests.push_back((pair<long long int, long long int>)(a, b));
      if (j == 0&&a != d) {
        
          j = d * b / (d - a + 0.0);
        } else if (a != d) {
        j = min(j, d * b / (d - a + 0.0));
      }
    }
    for(;abs(j - K) > 0.0000005f;) {
      r = (j + K) / 2;
      bool di = true;
      // cout << "Testing " << ex << endl;
      for (int ci = 0; ci < n; ci++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (tests[ci].second >= r)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (tests[ci].first / (r - tests[ci].second) * r < d) {
          di = false;
        }
      }
      if (di) {
        K = r;
      } else {
        j = r;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << N << ": " << j << endl;
  }
}
