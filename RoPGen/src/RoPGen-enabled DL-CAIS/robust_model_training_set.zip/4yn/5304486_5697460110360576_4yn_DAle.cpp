#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstring>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <regex>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <tuple>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>
using namespace std;
int tc;
int col, d2;
long long int a[1009];

long long int eleven(long long int ifs) { return ifs * 11 / 10; }

long long int ninety(long long int ifs) {
  long long int ofs = ifs * 9 / 10;
  if (ifs % 10 != 0) {
    ofs += 1;
  }
  return ofs;
}

bool inrange(int t, long long int row, long long int d1) {
  long long int ifs = a[t] * d1;
  return (ninety(ifs) <= row) && (row <= eleven(ifs));
}

int main() {
  ios_base::sync_with_stdio(false);
cin >> tc;
  for (int test = 1; test <= tc; ++test) {
    long long int sum;
    priority_queue<long long int, vector<long long int>, greater<long long int>> sum2[1009];
    memset(a, -1, sizeof(a));
    cin >> col >> d2;
    for (int v = 0; v < col; ++v) {
      cin >> a[v];
    }
    for (int b = 0; b < col; ++b) {
      for (int bs = 0; bs < d2; ++bs) {
        cin >> sum;
        sum2[b].push(sum);
      }
    }
    long long int best = 0;
    long long int ssum = 1;
    long long int newd = 1;
    long long int c = 1;
    for(;1;) {
      // if can send serving
      bool f = 1;
      ssum = 1;
      for (int res = 0; res < col; ++res) {
        if (sum2[res].empty()) {
          f = 0;
          break;
        }
        if (!inrange(res, sum2[res].top(), newd)) {
          ssum = 0;
        }
      }

      if (!f) {
        break;
      }

      if (ssum) {
        // cout << "Send\n";
        ++best;
        for (int m = 0; m < col; ++m) {
          sum2[m].pop();
        }
      } else {
        // find next serving size to make
        c = 9999999999;
        for (int cnt = 0; cnt < col; ++cnt) {
          if (sum2[cnt].empty())
            break;
          c = min(c, sum2[cnt].top() / eleven(a[cnt]));
        }
        if (c <= newd) {
          c = newd + 1;
        }
        newd = c;
        // flush
        for (int bs = 0; bs < col; ++bs) {
          for(;!sum2[bs].empty() && sum2[bs].top() < ninety(a[bs] * newd);) {
            sum2[bs].pop();
          }
          if (sum2[bs].empty()) {
            f = 0;
            break;
          }
        }
        if (!f) {
          break;
        }
      }
    }
    cout << "Case #" << test << ": " << best << endl;
  }
return 0;}
