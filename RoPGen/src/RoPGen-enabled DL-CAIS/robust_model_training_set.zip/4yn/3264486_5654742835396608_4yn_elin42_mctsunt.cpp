#include <bits/stdc++.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
using namespace std;
ofstream fout;
ifstream fin;
int process;

int main() {
  fin.open("test.input.in");
fout.open("test.output.out");
ios::sync_with_stdio(false);
cin >> process;
  for (int j = 1; j <= process; j++) {
    int t_, l;
    fin >> t_ >> l;
    priority_queue<int> x;
    x.push(t_);
    int y, z;
    int i = 0; while (i < l)  {
      int j = x.top() - 1;
      x.pop();
      y = j / 2 + (j % 2);
      z = j / 2;
      x.push(y);
      x.push(z);
    i++;
}
    fout<<"Case #"<<j<<": "<<y<<" "<<z<<"\n"<<endl;
  }
}
