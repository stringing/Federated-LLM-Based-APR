#include <algorithm>
#include <bits/stdc++.h>
#include <cstdio>
#include <cstring>
#include <vector>
using namespace std;

int t;

void split_main_42_44(int* k2,char d[30][30],int* x) {
        for (int h2 = 0; h2 < (*k2); ++h2) {
          d[(*x)][h2] = d[(*x) + 1][h2];
        }
}
int main() {
  scanf("%d",&t);
  for (int h2 = 1; h2 <= t; ++h2) {
    int a1, k2;
    scanf("%d%d",&a1,&k2);
    char st[30][30];
    for (int x = 0; x < a1; ++x) {
      for (int ans = 0; ans < k2; ++ans) {
        cin >> st[x][ans];
      }
    }
    for (int x = 0; x < a1; ++x) {
      // sweep left to right
      for (int ans = 1; ans < k2; ++ans) {
        if (st[x][ans - 1] != '?' && st[x][ans] == '?') {
          st[x][ans] = st[x][ans - 1];
        }
      }
      // sweep right to left
      for (int ans = k2 - 2; ans >= 0; --ans) {
        if (st[x][ans + 1] != '?' && st[x][ans] == '?') {
          st[x][ans] = st[x][ans + 1];
        }
      }
    }
    for (int x = 1; x < a1; ++x) {
      // sweep up to down
      if (st[x - 1][0] != '?' && st[x][0] == '?') {
        for (int ans = 0; ans < k2; ++ans) {
          st[x][ans] = st[x - 1][ans];
        }
      }
    }
    for (int x = a1 - 1; x >= 0; --x) {
      // sweep down to up
      if (st[x + 1][0] != '?' && st[x][0] == '?') {split_main_42_44(&k2,st,&x);
}
    }
    printf("Case #%d:\n",h2);
    for (int x = 0; x < a1; ++x) {
      for (int ans = 0; ans < k2; ++ans) {
        cout << st[x][ans];
      }
      printf("\n");
    }
  }
return 0;}
