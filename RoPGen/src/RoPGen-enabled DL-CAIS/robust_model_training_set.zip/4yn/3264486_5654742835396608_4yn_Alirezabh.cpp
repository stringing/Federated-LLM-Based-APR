#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef long double lld;
typedef pair<int, int> PII;
typedef pair<ll, ll> PLL;
typedef vector<int> VI;
typedef vector<string> VS;
typedef vector<double> VD;

int Tcase;

int main() {
  freopen("a.in","r",stdin);
freopen("a.out","w",stdout);
cin >> Tcase;
  for (int i = 1; i <= Tcase; i++) {
    int temp, v;
    cin >> temp >> v;
    priority_queue<int> newCameronTime;
    newCameronTime.push(temp);
    int j, p;
    for (int st = 0; st < v; st++) {
      int i = newCameronTime.top() - 1;
      newCameronTime.pop();
      j = i / 2 + (i % 2);
      p = i / 2;
      newCameronTime.push(j);
      newCameronTime.push(p);
    }
    cout<<"Case #"<<i<<": "<<j<<" "<<p<<"\n"<<endl;
  }
}
