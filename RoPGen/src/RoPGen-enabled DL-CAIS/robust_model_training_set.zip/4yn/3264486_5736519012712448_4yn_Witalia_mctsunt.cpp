#include <bits/stdc++.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include <iostream>
using namespace std;
ofstream _dump;
ifstream fin;

int tc;

void split_main_39_43(int* f,ofstream* _dump,int* t,int* fl) {
    if ((*f) == 1) {
      (*_dump)<<"Case #"<<(*t)<<": "<<(*fl)<<"\n"<<endl;
    } else {
      (*_dump)<<"Case #"<<(*t)<<": IMPOSSIBLE\n"<<(*fl)<<endl;
    }
}
int main() {
  ios::sync_with_stdio(false);
fin.open("test.input.in");
_dump.open("test.output.out");
fin >> tc;
  for (int t = 1; t <= tc; t++) {
    string s;
    int k, fl = 0;
    fin >> s >> k;
    for (int it = 0; it < s.size() - k + 1; it++) {
      if (s[it] == '-') {
        // cout << "Flip at " << i << endl;
        fl++;
        for (int j = it; j < it + k; j++) {
          if (s[j] == '-')
            s[j] = '+';
          else
            s[j] = '-';
        }
      }
    }
    int f = 1;
    int it = s.size() - k + 1; while (it < s.size())  {
      if (s[it] == '-')
        f = 0;
    it++;
}
    split_main_39_43(&f,&_dump,&t,&fl);

  }
}
