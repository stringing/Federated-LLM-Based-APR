#include <bits/stdc++.h>
using namespace std;

typedef long long int ll;

int tc;

int main() {
  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    int r, c;
    cin >> r >> c;
    char cake[30][30];
    for (int i = 0; i < r; i++) {
      for (int ii = 0; ii < c; ii++) {
        cin >> cake[i][ii];
      }
    }
    for (int i = 0; i < r; i++) {
      // sweep left to right
      for (int ii = 1; ii < c; ii++) {
        if (cake[i][ii - 1] != '?' && cake[i][ii] == '?') {
          cake[i][ii] = cake[i][ii - 1];
        }
      }
      // sweep right to left
      for (int ii = c - 2; ii >= 0; ii--) {
        if (cake[i][ii + 1] != '?' && cake[i][ii] == '?') {
          cake[i][ii] = cake[i][ii + 1];
        }
      }
    }
    for (int i = 1; i < r; i++) {
      // sweep up to down
      if (cake[i - 1][0] != '?' && cake[i][0] == '?') {
        for (int ii = 0; ii < c; ii++) {
          cake[i][ii] = cake[i - 1][ii];
        }
      }
    }
    for (int i = r - 1; i >= 0; i--) {
      // sweep down to up
      if (cake[i + 1][0] != '?' && cake[i][0] == '?') {
        for (int ii = 0; ii < c; ii++) {
          cake[i][ii] = cake[i + 1][ii];
        }
      }
    }
    cout << "Case #" << t << ":\n";
    for (int i = 0; i < r; i++) {
      for (int ii = 0; ii < c; ii++) {
        cout << cake[i][ii];
      }
      cout << endl;
    }
  }
}
