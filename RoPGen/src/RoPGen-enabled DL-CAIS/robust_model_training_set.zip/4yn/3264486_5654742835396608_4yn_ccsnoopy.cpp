#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long long LL;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<int> vi;
int idx;

int main() {
  freopen("D:/OneDrive/Code/GCJ/A-large.in","r",stdin);
freopen("D:/OneDrive/Code/GCJ/out.txt","w",stdout);
scanf("%d",&idx);
  for (int i = 1; i <= idx; i++) {
    int xy, found;
    scanf("%d%d",&xy,&found);
    priority_queue<int> x;
    x.push(xy);
    int tot, bs;
    for (int j = 0; j < found; j++) {
      int i = x.top() - 1;
      x.pop();
      tot = i / 2 + (i % 2);
      bs = i / 2;
      x.push(tot);
      x.push(bs);
    }
    printf("Case #%d: %d %d\n", i, tot, bs);
  }
return 0;}
