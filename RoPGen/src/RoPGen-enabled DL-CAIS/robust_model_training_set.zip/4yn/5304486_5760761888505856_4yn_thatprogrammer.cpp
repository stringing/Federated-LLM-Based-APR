#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <vector>
using namespace std;

typedef long long ll;
int t;

void split_main_8_54(int* t) {
  for (int curMax = 1; curMax <= (*t); curMax++) {
    int cur, ans;
    cin >> cur >> ans;
    char b[30][30];
    for (int av = 0; av < cur; av++) {
      for (int bad = 0; bad < ans; bad++) {
        cin >> b[av][bad];
      }
    }
    for (int av = 0; av < cur; av++) {
      // sweep left to right
      for (int bad = 1; bad < ans; bad++) {
        if (b[av][bad - 1] != '?' && b[av][bad] == '?') {
          b[av][bad] = b[av][bad - 1];
        }
      }
      // sweep right to left
      for (int bad = ans - 2; bad >= 0; bad--) {
        if (b[av][bad + 1] != '?' && b[av][bad] == '?') {
          b[av][bad] = b[av][bad + 1];
        }
      }
    }
    for (int av = 1; av < cur; av++) {
      // sweep up to down
      if (b[av - 1][0] != '?' && b[av][0] == '?') {
        for (int bad = 0; bad < ans; bad++) {
          b[av][bad] = b[av - 1][bad];
        }
      }
    }
    for (int av = cur - 1; av >= 0; av--) {
      // sweep down to up
      if (b[av + 1][0] != '?' && b[av][0] == '?') {
        for (int bad = 0; bad < ans; bad++) {
          b[av][bad] = b[av + 1][bad];
        }
      }
    }
    cout << "Case #" << curMax << ":\n";
    for (int av = 0; av < cur; av++) {
      for (int bad = 0; bad < ans; bad++) {
        cout << b[av][bad];
      }
      cout << endl;
    }
  }
}
int main() {
  ios::sync_with_stdio(false);
freopen("test.txt","r",stdin);
freopen("test1.txt","w",stdout);
cin >> t;
  split_main_8_54(&t);

}
