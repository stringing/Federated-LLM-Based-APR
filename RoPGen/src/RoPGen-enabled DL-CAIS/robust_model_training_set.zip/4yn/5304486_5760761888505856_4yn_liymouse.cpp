#include <algorithm>
#include <bits/stdc++.h>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

typedef long long i64d;

int cas;

int main() {
  freopen("D-small-attempt2.in","r",stdin);
freopen("D-small-attempt2.out","w",stdout);
scanf("%d",&cas);
  for (int k = 1; k <= cas; k++) {
    
    int n;int b;
scanf("%d%d",&b,&n);
    char res[30][30];
    for (int x = 0; x < b; x++) {
      for (int a = 0; a < n; a++) {
        cin >> res[x][a];
      }
    }
    for (int x = 0; x < b; x++) {
      // sweep left to right
      for (int a = 1; a < n; a++) {
        if (res[x][a - 1] != '?' && res[x][a] == '?') {
          res[x][a] = res[x][a - 1];
        }
      }
      // sweep right to left
      for (int a = n - 2; a >= 0; a--) {
        if (res[x][a + 1] != '?' && res[x][a] == '?') {
          res[x][a] = res[x][a + 1];
        }
      }
    }
    for (int x = 1; x < b; x++) {
      // sweep up to down
      if (res[x - 1][0] != '?' && res[x][0] == '?') {
        for (int a = 0; a < n; a++) {
          res[x][a] = res[x - 1][a];
        }
      }
    }
    for (int x = b - 1; x >= 0; x--) {
      // sweep down to up
      if (res[x + 1][0] != '?' && res[x][0] == '?') {
        for (int a = 0; a < n; a++) {
          res[x][a] = res[x + 1][a];
        }
      }
    }
    printf("Case #%d:\n",k);
    for (int x = 0; x < b; x++) {
      for (int a = 0; a < n; a++) {
        cout << res[x][a];
      }
      printf("\n");
    }
  }
return 0;}
