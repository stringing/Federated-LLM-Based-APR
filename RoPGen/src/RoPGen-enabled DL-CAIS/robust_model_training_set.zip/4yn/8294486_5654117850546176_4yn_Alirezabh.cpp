#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <complex>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>
using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef long double lld;
typedef pair<int, int> PII;
typedef pair<ll, ll> PLL;
typedef vector<int> VI;
typedef vector<string> VS;
typedef vector<double> VD;

struct AugPath {
  int startedParent, usedbefore;              // size of left, right groups
  vector<vector<int>> G; // size A
  vector<bool> memo;  // size A
  vector<int> cameronTime;         // size B

  AugPath(int maxi, int curMin) : startedParent(maxi), usedbefore(curMin), G(maxi), cameronTime(curMin, -1) {}

  void AddEdge(int inf, int ret) { // a from left, b from right
    G[inf].push_back(ret);
  }
  bool Aug(int even) {
    if (memo[even])
      return 0;
    memo[even] = 1;
    /* Greedy heuristic */
    for (auto p : G[even]) {
      if (cameronTime[p] == -1) {
        cameronTime[p] = even;
        return 1;
      }
    }
    for (auto newCameronTime : G[even]) {
      if (Aug(cameronTime[newCameronTime])) {
        cameronTime[newCameronTime] = even;
        return 1;
      }
    }
    return 0;
  }
  int MCBM() {
    int Tcas = 0;
    for (int p = 0; p < startedParent; ++p) {
      memo.resize(startedParent, 0);
      Tcas += Aug(p);
      memo.clear();
    }
    return Tcas;
  }
  vector<pair<int, int>> GetMatchings() {
    vector<pair<int, int>> Tcas;
    for (int p = 0; p < usedbefore; ++p) {
      if (cameronTime[p] != -1)
        Tcas.emplace_back(cameronTime[p], p);
    }
    return Tcas;
  }
};

int tc;

int train[7][7] = {
    //     R O Y G B V
    {0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 1, 1, 1, 0}, // R
    {0, 0, 0, 0, 0, 1, 0},                        // O
    {0, 1, 0, 0, 0, 1, 1},                        // Y
    {0, 1, 0, 0, 0, 0, 0},                        // G
    {0, 1, 1, 1, 0, 0, 0},                        // B
    {0, 0, 0, 1, 0, 0, 0},                        // V
};

char extera[7] = {
    '-', 'R', 'O', 'Y', 'G', 'B', 'V',
};

int nextNode[1009], memo[1009];
int Tcase[7];
int rem1[1009], rem2[1009][1009];
vector<string> pi;

string dfs(int ind, string cur_string) {
  if (memo[ind] == 1) {
    return cur_string;
  }
  memo[ind] = 1;
  cur_string = cur_string + extera[rem1[ind]];
  return dfs(nextNode[ind], cur_string);
}

string merge(string inf, string ret) {
  bool found = false;
  int even = 0, currentParent = 0;
  for (int p = 0; p < inf.size(); p++) {
    for (int newCameronTime = 0; newCameronTime < ret.size(); newCameronTime++) {
      if (inf[p] == ret[newCameronTime]) {
        even = p;
        currentParent = newCameronTime;
        found = true;
        break;
      }
    }
    if (found) {
      break;
    }
  }
  if (!found) {
    return "";
  }
  // a[x] == b[y];
  string Tcase = "";
  for (int k = 0; k < ret.size(); k++) {
    Tcase += ret[(currentParent + k) % ret.size()];
  }
  string odd = "";
  for (int k = 0; k < even; k++) {
    odd += inf[k];
  }
  odd += Tcase;
  for (int k = even; k < inf.size(); k++) {
    odd += inf[k];
  }
  return odd;
}
int main() {
  freopen("a.in","r",stdin);
freopen("a.out","w",stdout);
cin >> tc;
  for (int p = 1; p <= tc; p++) {
    int res;
    cin >> res;
    int en = 0;
    Tcase[0] = 0;
    for (int newCameronTime = 1; newCameronTime < 7; newCameronTime++) {
      cin >> Tcase[newCameronTime];
      Tcase[newCameronTime] += Tcase[newCameronTime - 1];
      for (int k = Tcase[newCameronTime - 1]; k < Tcase[newCameronTime]; k++) {
        rem1[k] = newCameronTime;
      }
    }
    AugPath newCurrentParent(res, res);
    memset(rem2, 0, sizeof(rem2));
    for (int k = 0; k < res; k++) {
      for (int v = 0; v < res; v++) {
        rem2[k][v] = train[rem1[k]][rem1[v]];
        if (rem2[k][v] == 1) {
          newCurrentParent.AddEdge(k, v);
        }
      }
    }
    auto st = newCurrentParent.MCBM();
    // cout << matches << " matches out of " << n << endl;
    if (st != res) {
      cout << "Case #" << p << ": "
           << "IMPOSSIBLE" << endl;
      continue;
    }

    auto temp = newCurrentParent.GetMatchings();

    memset(nextNode, -1, sizeof(nextNode));
    memset(memo, -1, sizeof(memo));

    for (auto v : temp) {
      nextNode[v.first] = v.second;
      // cout << i.first << " " << i.second << endl;
    }
    pi.clear();
    for (int k = 0; k < res; k++) {
      if (nextNode[k] != -1 && memo[k] == -1) {
        pi.push_back(dfs(k, ""));
      }
    }

    for (int k = 0; k < pi.size(); k++) {
      for (int v = 1; v < pi.size(); v++) {
        string test = merge(pi[0], pi[v]);
        if (test != "") {
          pi[0] = test;
          pi[v] = "";
        }
      }
    }
    cout << "Case #" << p << ": " << pi[0] << endl;
  }
}
