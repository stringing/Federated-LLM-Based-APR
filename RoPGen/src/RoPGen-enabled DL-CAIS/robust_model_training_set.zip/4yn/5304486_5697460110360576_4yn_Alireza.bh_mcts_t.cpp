#include <bits/stdc++.h>
#include <complex>
#include <cstdio>
#include <ctime>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <sstream>
#include <stack>
#include <utility>
using namespace std;
typedef unsigned long long ull;
typedef pair<int, int> PII;
typedef long long ll;

int tc;
int n, p;
ll r[1009];

ll eleven(ll x) { return x * 11 / 10; }

ll ninety(ll x) {
  ll y = x * 9 / 10;
  if (x % 10 != 0) {
    y += 1;
  }
  return y;
}

bool inrange(int ingredient, ll number, ll servings) {
  ll x = r[ingredient] * servings;
  return (ninety(x) <= number) && (number <= eleven(x));
}

int main() {
  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    ll tmp;
    priority_queue<ll, vector<ll>, greater<ll>> q[1009];
    memset(r, -1, sizeof(r));
    cin >> n >> p;
    for (int i = 0; i < n; i++) {
      cin >> r[i];
    }
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < p; j++) {
        cin >> tmp;
        q[i].push(tmp);
      }
    }
    ll ans = 0;
    ll cansendserving = 1;
    ll curservingsize = 1;
    ll nextservingsize = 1;
    while (1) {
      // if can send serving
      bool okay = 1;
      cansendserving = 1;
      for (int i = 0; i < n; i++) {
        if (q[i].empty()) {
          okay = 0;
          break;
        }
        if (!inrange(i, q[i].top(), curservingsize)) {
          cansendserving = 0;
        }
      }

      if (!okay) {
        break;
      }

      if (cansendserving) {
        // cout << "Send\n";
        ans++;
        for (int i = 0; i < n; i++) {
          q[i].pop();
        }
      } else {
        // find next serving size to make
        nextservingsize = 9999999999;
        for (int i = 0; i < n; i++) {
          if (q[i].empty())
            break;
          nextservingsize = min(nextservingsize, q[i].top() / eleven(r[i]));
        }
        if (nextservingsize <= curservingsize) {
          nextservingsize = curservingsize + 1;
        }
        curservingsize = nextservingsize;
        // flush
        for (int i = 0; i < n; i++) {
          while (!q[i].empty() && q[i].top() < ninety(r[i] * curservingsize)) {
            q[i].pop();
          }
          if (q[i].empty()) {
            okay = 0;
            break;
          }
        }
        if (!okay) {
          break;
        }
      }
    }
    cout << "Case #" << t << ": " << ans << endl;
  }
}
