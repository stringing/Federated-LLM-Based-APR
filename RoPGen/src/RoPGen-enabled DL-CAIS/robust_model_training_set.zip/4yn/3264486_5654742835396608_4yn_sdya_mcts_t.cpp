#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <map>
#include <set>
#include <string>
#include <vector>
using namespace std;
typedef long long int lli;
typedef pair<lli, lli> pii;

int readData;

int main() {
  cin >> readData;
  for (int t = 1; t <= readData; t++) {
    int n, k;
    cin >> n >> k;
    priority_queue<int> pq;
    pq.push(n);
    int argv, z;
    for (int i = 0; i < k; i++) {
      int t = pq.top() - 1;
      pq.pop();
      argv = t / 2 + (t % 2);
      z = t / 2;
      pq.push(argv);
      pq.push(z);
    }
    printf("Case #%d: %d %d\n", t, argv, z);
  }
}
