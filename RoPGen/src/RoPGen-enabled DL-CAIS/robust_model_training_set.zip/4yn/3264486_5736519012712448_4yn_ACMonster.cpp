#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <set>
#include <vector>
using namespace std;

int totalTest;

int main() {
  scanf("%d",&totalTest);
  for (int test = 1; test <= totalTest; test++) {
    string m;
    int c, ans = 0;
    cin >> m >> c;
    for (int mask = 0; mask < m.size() - c + 1; mask++) {
      if (m[mask] == '-') {
        // cout << "Flip at " << i << endl;
        ans++;
        for (int plan = mask; plan < mask + c; plan++) {
          if (m[plan] == '-')
            m[plan] = '+';
          else
            m[plan] = '-';
        }
      }
    }
    int n = 1;
    for (int i = m.size() - c + 1; i < m.size(); i++) {
      if (m[i] == '-')
        n = 0;
    }
    if (n == 1) {
      printf("Case #%d: %d\n", test, ans);
    } else {
      printf("Case #%d: IMPOSSIBLE\n", test, ans);
    }
  }
return 0;}
