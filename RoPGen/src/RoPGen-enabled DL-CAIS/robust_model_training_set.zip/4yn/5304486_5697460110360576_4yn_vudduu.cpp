#include <algorithm>
#include <bits/stdc++.h>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <functional>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string.h>
#include <string>
#include <utility>
#include <vector>
using namespace std;
typedef long long LL;

int tc;
int d, t;
long long int dam[1009];

long long int eleven(long long int T) { return T * 11 / 10; }

long long int ninety(long long int T) {
  long long int it = T * 9 / 10;
  if (T % 10 != 0) {
    it += 1;
  }
  return it;
}

bool inrange(int aux, long long int number, long long int v) {
  long long int T = dam[aux] * v;
  return (ninety(T) <= number) && (number <= eleven(T));
}

int main() {
  scanf("%d",&tc);
  for (int cas = 1; cas <= tc; ++cas) {
    long long int cs;
    priority_queue<long long int, vector<long long int>, greater<long long int>> q[1009];
    memset(dam, -1, sizeof(dam));
    scanf("%d%d",&d,&t);
    for (int _i = 0; _i < d; ++_i) {
      cin >> dam[_i];
    }
    for (int _i = 0; _i < d; ++_i) {
      for (int flag = 0; flag < t; ++flag) {
        cin >> cs;
        q[_i].push(cs);
      }
    }
    long long int c = 0;
long long int b = 1;
long long int _cas = 1;
long long int nextservingsize = 1;

    
    
    
    for(;1;) {
      // if can send serving
      bool a = 1;
      b = 1;
      for (int _i = 0; _i < d; ++_i) {
        if (q[_i].empty()) {
          a = 0;
          break;
        }
        if (!inrange(_i, q[_i].top(), _cas)) {
          b = 0;
        }
      }

      if (!a) {
        break;
      }

      if (b) {
        // cout << "Send\n";
        ++c;
        for (int _i = 0; _i < d; ++_i) {
          q[_i].pop();
        }
      } else {
        // find next serving size to make
        nextservingsize = 9999999999;
        for (int _i = 0; _i < d; ++_i) {
          if (q[_i].empty())
            break;
          nextservingsize = min(nextservingsize, q[_i].top() / eleven(dam[_i]));
        }
        if (nextservingsize <= _cas) {
          nextservingsize = _cas + 1;
        }
        _cas = nextservingsize;
        // flush
        for (int _i = 0; _i < d; ++_i) {
          for(;!q[_i].empty() && q[_i].top() < ninety(dam[_i] * _cas);) {
            q[_i].pop();
          }
          if (q[_i].empty()) {
            a = 0;
            break;
          }
        }
        if (!a) {
          break;
        }
      }
    }
    cout << "Case #" << cas << ": " << c << endl;
  }
}
