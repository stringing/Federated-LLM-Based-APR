#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <vector>
using namespace std;

typedef long long ll;
int numExchanges;

long long int numTaken;
long long int Aj;
long long int p;
long long int k;

vector<pair<long long int, long long int>> t;

int main() {
  ios::sync_with_stdio(false);
freopen("test.txt","r",stdin);
freopen("test1.txt","w",stdout);
cin >> numExchanges;
  for (int ans = 1; ans <= numExchanges; ans++) {
    t.clear();
    cin >> numTaken >> Aj;
    double curMax = 0;
double bad = 0;
double cur;

    for (int j = 0; j < Aj; j++) {
      cin >> p >> k;
      t.push_back((pair<long long int, long long int>)(p, k));
      if (bad == 0&&p != numTaken) {
        
          bad = numTaken * k / (numTaken - p + 0.0);
        } else if (p != numTaken) {
        bad = min(bad, numTaken * k / (numTaken - p + 0.0));
      }
    }
    for(;abs(bad - curMax) > 0.0000005f;) {
      cur = (bad + curMax) / 2;
      bool av = true;
      // cout << "Testing " << ex << endl;
      for (int j = 0; j < Aj; j++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (t[j].second >= cur)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (t[j].first / (cur - t[j].second) * cur < numTaken) {
          av = false;
        }
      }
      if (av) {
        curMax = cur;
      } else {
        bad = cur;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << ans << ": " << bad << endl;
  }
}
