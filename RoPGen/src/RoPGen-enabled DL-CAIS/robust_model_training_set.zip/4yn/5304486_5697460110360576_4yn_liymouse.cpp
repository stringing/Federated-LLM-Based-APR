#include <algorithm>
#include <bits/stdc++.h>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>
using namespace std;
typedef long long i64d;

int tc;
int pre, time;
long long int lastcar[1009];

long long int eleven(long long int cas) { return cas * 11 / 10; }

long long int ninety(long long int cas) {
  long long int lr = cas * 9 / 10;
  if (cas % 10 != 0) {
    lr += 1;
  }
  return lr;
}

bool inrange(int stin, long long int pt, long long int sout) {
  long long int cas = lastcar[stin] * sout;
  return (ninety(cas) <= pt) && (pt <= eleven(cas));
}

int main() {
  freopen("D-small-attempt2.in","r",stdin);
freopen("D-small-attempt2.out","w",stdout);
scanf("%d",&tc);
  for (int b = 1; b <= tc; b++) {
    
    
    memset(lastcar, -1, sizeof(lastcar));
    scanf("%d%d",&pre,&time);
    for (int a = 0; a < pre; a++) {
      cin >> lastcar[a];
    }
    priority_queue<long long int, vector<long long int>, greater<long long int>> tot[1009];long long int num;for (int a = 0; a < pre; a++) {
      for (int res = 0; res < time; res++) {
        cin >> num;
        tot[a].push(num);
      }
    }
    long long int xx = 0;
    long long int yy = 1;
    long long int k = 1;
    long long int s = 1;
    for(;1;) {
      // if can send serving
      bool sum = 1;
      yy = 1;
      for (int a = 0; a < pre; a++) {
        if (tot[a].empty()) {
          sum = 0;
          break;
        }
        if (!inrange(a, tot[a].top(), k)) {
          yy = 0;
        }
      }

      if (!sum) {
        break;
      }

      if (yy) {
        // cout << "Send\n";
        xx++;
        for (int a = 0; a < pre; a++) {
          tot[a].pop();
        }
      } else {
        // find next serving size to make
        s = 9999999999;
        for (int a = 0; a < pre; a++) {
          if (tot[a].empty())
            break;
          s = min(s, tot[a].top() / eleven(lastcar[a]));
        }
        if (s <= k) {
          s = k + 1;
        }
        k = s;
        // flush
        for (int a = 0; a < pre; a++) {
          for(;!tot[a].empty() && tot[a].top() < ninety(lastcar[a] * k);) {
            tot[a].pop();
          }
          if (tot[a].empty()) {
            sum = 0;
            break;
          }
        }
        if (!sum) {
          break;
        }
      }
    }
    cout << "Case #" << b << ": " << xx << endl;
  }
return 0;}
