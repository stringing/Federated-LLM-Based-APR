#include <bits/stdc++.h>
#include <stdio.h>
using namespace std;

int mod;

long long int solve;
long long int res;
long long int pi;
long long int eps;

vector<pair<long long int, long long int>> powmod;

int main() {
  scanf("%d",&mod);
  for (int k = 1; k <= mod; k++) {
    powmod.clear();
    cin >> solve >> res;
    double cnt;
double l;
double r;

    cnt = 0;
    l = 0;
    for (int j = 0; j < res; j++) {
      cin >> pi >> eps;
      powmod.push_back((pair<long long int, long long int>)(pi, eps));
      if (l == 0) {
        if (pi != solve) {
          l = solve * eps / (solve - pi + 0.0);
        }
      } else if (pi != solve) {
        l = min(l, solve * eps / (solve - pi + 0.0));
      }
    }
    while (abs(l - cnt) > 0.0000005f) {
      r = (l + cnt) / 2;
      bool f = true;
      // cout << "Testing " << ex << endl;
      for (int j = 0; j < res; j++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (powmod[j].second >= r)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (powmod[j].first / (r - powmod[j].second) * r < solve) {
          f = false;
        }
      }
      if (f) {
        cnt = r;
      } else {
        l = r;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << k << ": " << l << endl;
  }
}
