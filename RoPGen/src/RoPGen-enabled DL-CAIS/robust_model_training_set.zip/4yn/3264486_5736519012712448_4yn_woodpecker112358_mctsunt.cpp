#include <bits/stdc++.h>
using namespace std;

int Work;

void split_main_29_33(int* f,int* t,int* fl) {
    if ((*f) == 1) {
      printf("Case #%d: %d\n", (*t), (*fl));
    } else {
      printf("Case #%d: IMPOSSIBLE\n", (*t), (*fl));
    }
}
int main() {
  cin >> Work;
  for (int t = 1; t <= Work; t++) {
    string s;
    int k, fl = 0;
    cin >> s >> k;
    for (int i = 0; i < s.size() - k + 1; i++) {
      if (s[i] == '-') {
        // cout << "Flip at " << i << endl;
        fl++;
        for (int j = i; j < i + k; j++) {
          if (s[j] == '-')
            s[j] = '+';
          else
            s[j] = '-';
        }
      }
    }
    int f = 1;
    for (int i = s.size() - k + 1; i < s.size(); i++) {
      if (s[i] == '-')
        f = 0;
    }
    split_main_29_33(&f,&t,&fl);

  }
}
