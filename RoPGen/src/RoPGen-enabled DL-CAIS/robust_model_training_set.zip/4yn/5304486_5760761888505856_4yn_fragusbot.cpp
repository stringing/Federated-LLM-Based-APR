#include <bits/stdc++.h>
using namespace std;

int N;

void split_main_8_54(int* N) {
  for (int n = 1; n <= (*N); ++n) {
    int r, c;
    scanf("%d%d",&r,&c);
    char foo[30][30];
    for (int k = 0; k < r; ++k) {
      for (int ans = 0; ans < c; ++ans) {
        cin >> foo[k][ans];
      }
    }
    for (int k = 0; k < r; ++k) {
      // sweep left to right
      for (int ans = 1; ans < c; ++ans) {
        if (foo[k][ans - 1] != '?' && foo[k][ans] == '?') {
          foo[k][ans] = foo[k][ans - 1];
        }
      }
      // sweep right to left
      for (int ans = c - 2; ans >= 0; --ans) {
        if (foo[k][ans + 1] != '?' && foo[k][ans] == '?') {
          foo[k][ans] = foo[k][ans + 1];
        }
      }
    }
    for (int k = 1; k < r; ++k) {
      // sweep up to down
      if (foo[k - 1][0] != '?' && foo[k][0] == '?') {
        for (int ans = 0; ans < c; ++ans) {
          foo[k][ans] = foo[k - 1][ans];
        }
      }
    }
    for (int k = r - 1; k >= 0; --k) {
      // sweep down to up
      if (foo[k + 1][0] != '?' && foo[k][0] == '?') {
        for (int ans = 0; ans < c; ++ans) {
          foo[k][ans] = foo[k + 1][ans];
        }
      }
    }
    printf("Case #%d:\n",n);
    for (int k = 0; k < r; ++k) {
      for (int ans = 0; ans < c; ++ans) {
        cout << foo[k][ans];
      }
      printf("\n");
    }
  }
}
int main() {
  scanf("%d",&N);
  split_main_8_54(&N);

}
