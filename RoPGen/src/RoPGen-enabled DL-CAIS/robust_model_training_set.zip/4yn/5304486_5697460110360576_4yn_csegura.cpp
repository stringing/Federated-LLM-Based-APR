#include <algorithm>
#include <bits/stdc++.h>
#include <float.h>
#include <iomanip>
#include <iostream>
#include <limits.h>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <vector>
using namespace std;
int tc;
int n, p;
long long int r[1009];

long long int eleven(long long int tests) { return tests * 11 / 10; }

long long int ninety(long long int tests) {
  long long int y = tests * 9 / 10;
  if (tests % 10 != 0) {
    y += 1;
  }
  return y;
}

bool inrange(int ingredient, long long int number, long long int servings) {
  long long int tests = r[ingredient] * servings;
  return (ninety(tests) <= number) && (number <= eleven(tests));
}

int main() {
  cin >> tc;
  for (int solution = 1; solution <= tc; solution++) {
    long long int K;
    priority_queue<long long int, vector<long long int>, greater<long long int>> Activities[1009];
    memset(r, -1, sizeof(r));
    cin >> n >> p;
    for (int g = 0; g < n; g++) {
      cin >> r[g];
    }
    for (int N = 0; N < n; N++) {
      for (int di = 0; di < p; di++) {
        cin >> K;
        Activities[N].push(K);
      }
    }
    long long int additional = 0;
long long int Aj = 1;
long long int ci = 1;
long long int prob = 1;

    
    
    
    for(;1;) {
      // if can send serving
      bool U = 1;
      Aj = 1;
      for (int N = 0; N < n; N++) {
        if (Activities[N].empty()) {
          U = 0;
          break;
        }
        if (!inrange(N, Activities[N].top(), ci)) {
          Aj = 0;
        }
      }

      if (!U) {
        break;
      }

      if (Aj) {
        // cout << "Send\n";
        additional++;
        for (int N = 0; N < n; N++) {
          Activities[N].pop();
        }
      } else {
        // find next serving size to make
        prob = 9999999999;
        for (int N = 0; N < n; N++) {
          if (Activities[N].empty())
            break;
          prob = min(prob, Activities[N].top() / eleven(r[N]));
        }
        if (prob <= ci) {
          prob = ci + 1;
        }
        ci = prob;
        // flush
        for (int N = 0; N < n; N++) {
          for(;!Activities[N].empty() && Activities[N].top() < ninety(r[N] * ci);) {
            Activities[N].pop();
          }
          if (Activities[N].empty()) {
            U = 0;
            break;
          }
        }
        if (!U) {
          break;
        }
      }
    }
    cout << "Case #" << solution << ": " << additional << endl;
  }
}
