#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;
int ak;
int right_bound, left_bound;
long long int a[1009];

long long int eleven(long long int c) { return c * 11 / 10; }

long long int ninety(long long int c) {
  long long int y = c * 9 / 10;
  if (c % 10 != 0) {
    y += 1;
  }
  return y;
}

bool inrange(int t, long long int argv, long long int argc) {
  long long int c = a[t] * argc;
  return (ninety(c) <= argv) && (argv <= eleven(c));
}

int main() {
  freopen("input.txt","r",stdin);
freopen("output.txt","w",stdout);
cin >> ak;
  for (int current = 1; current <= ak; ++current) {
    long long int l;
    priority_queue<long long int, vector<long long int>, greater<long long int>> q[1009];
    memset(a, -1, sizeof(a));
    cin >> right_bound >> left_bound;
    for (int w = 0; w < right_bound; ++w) {
      cin >> a[w];
    }
    for (int k = 0; k < right_bound; ++k) {
      for (int value = 0; value < left_bound; ++value) {
        cin >> l;
        q[k].push(l);
      }
    }
    long long int score = 0;
long long int added = 1;
long long int o = 1;
long long int rem = 1;

    
    
    
    for(;1;) {
      // if can send serving
      bool s = 1;
      added = 1;
      for (int k = 0; k < right_bound; ++k) {
        if (q[k].empty()) {
          s = 0;
          break;
        }
        if (!inrange(k, q[k].top(), o)) {
          added = 0;
        }
      }

      if (!s) {
        break;
      }

      if (added) {
        // cout << "Send\n";
        ++score;
        for (int k = 0; k < right_bound; ++k) {
          q[k].pop();
        }
      } else {
        // find next serving size to make
        rem = 9999999999;
        for (int k = 0; k < right_bound; ++k) {
          if (q[k].empty())
            break;
          rem = min(rem, q[k].top() / eleven(a[k]));
        }
        if (rem <= o) {
          rem = o + 1;
        }
        o = rem;
        // flush
        for (int k = 0; k < right_bound; ++k) {
          for(;!q[k].empty() && q[k].top() < ninety(a[k] * o);) {
            q[k].pop();
          }
          if (q[k].empty()) {
            s = 0;
            break;
          }
        }
        if (!s) {
          break;
        }
      }
    }
    cout << "Case #" << current << ": " << score << endl;
  }
return 0;}
