#include <bits/stdc++.h>
#include <stdio.h>
using namespace std;

typedef long long int lli;
typedef pair<lli, lli> pii;
typedef double dbl;

int tc;

lli takeInput, n, a, b;
vector<pii> ks;

int main() {
  scanf("%d",&tc);
  for (int t = 1; t <= tc; t++) {
    ks.clear();
    cin >> takeInput >> n;
    dbl lb, ub, ex;
    lb = 0;
    ub = 0;
    for (int i = 0; i < n; i++) {
      cin >> a >> b;
      ks.push_back(pii(a, b));
      if (ub == 0) {
        if (a != takeInput) {
          ub = takeInput * b / (takeInput - a + 0.0);
        }
      } else if (a != takeInput) {
        ub = min(ub, takeInput * b / (takeInput - a + 0.0));
      }
    }
    while (abs(ub - lb) > 0.0000005f) {
      ex = (ub + lb) / 2;
      bool f = true;
      // cout << "Testing " << ex << endl;
      for (int i = 0; i < n; i++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (ks[i].second >= ex)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (ks[i].first / (ex - ks[i].second) * ex < takeInput) {
          f = false;
        }
      }
      if (f) {
        lb = ex;
      } else {
        ub = ex;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << t << ": " << ub << endl;
  }
}
