#include <algorithm>
#include <bits/stdc++.h>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <vector>
using namespace std;

int tc;
int n, p;
long long r[1009];

long long eleven(long long x) { return x * 11 / 10; }

long long ninety(long long x) {
  long long y = x * 9 / 10;
  if (x % 10 != 0) {
    y += 1;
  }
  return y;
}

bool inrange(int ingredient, long long number, long long servings) {
  long long x = r[ingredient] * servings;
  return (ninety(x) <= number) && (number <= eleven(x));
}

int main() {
  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_5304486_5697460110360576_15_CCS18_RNN_800_True_MCTS_Classic_True/liymouse/4yn/outer_temp/4yn/A-small-practice_transformation.out", "w", stdout);

  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    long long tmp;
    vector<priority_queue<long long, vector<long long>, greater<long long>>> q(
        1009);
    memset(r, -1, sizeof(r));
    cin >> n >> p;
    for (int i = 0; i < n; i++) {
      cin >> r[i];
    }
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < p; j++) {
        cin >> tmp;
        q[i].push(tmp);
      }
    }
    long long ans = 0;
    long long cansendserving = 1;
    long long curservingsize = 1;
    long long nextservingsize = 1;
    while (1) {
      // if can send serving
      bool okay = 1;
      cansendserving = 1;
      {
        int i = 0;
        while (i < n) {
          if (q[i].empty()) {
            okay = 0;
            break;
          }
          if (!inrange(i, q[i].top(), curservingsize)) {
            cansendserving = 0;
          }
          i++;
        }
      }

      if (!okay) {
        break;
      }

      if (cansendserving) {
        // cout << "Send\n";
        ans++;
        for (int i = 0; i < n; i++) {
          q[i].pop();
        }
      } else {
        // find next serving size to make
        nextservingsize = 9999999999;
        for (int i = 0; i < n; i++) {
          if (q[i].empty())
            break;
          nextservingsize = min(nextservingsize, q[i].top() / eleven(r[i]));
        }
        if (nextservingsize <= curservingsize) {
          nextservingsize = curservingsize + 1;
        }
        curservingsize = nextservingsize;
        // flush
        for (int i = 0; i < n; i++) {
          while (!q[i].empty() && q[i].top() < ninety(r[i] * curservingsize)) {
            q[i].pop();
          }
          if (q[i].empty()) {
            okay = 0;
            break;
          }
        }
        if (!okay) {
          break;
        }
      }
    }
    cout << "Case #" << t << ": " << ans << endl;
  }
}
