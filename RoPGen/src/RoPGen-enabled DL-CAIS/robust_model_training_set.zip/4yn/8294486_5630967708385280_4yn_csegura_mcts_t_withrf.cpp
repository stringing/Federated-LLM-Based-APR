#include <bits/stdc++.h>
#include <float.h>
#include <iomanip>
#include <iostream>
#include <limits.h>
#include <list>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
using namespace std;

typedef double td_d;
typedef long long int lli;
typedef pair<lli, lli> pii;

int tc;

lli d, n, a, b;
vector<pii> ks;

inline void stsdsghjib(double &ub) { ub = d * b / (d - a + 0.0); }

inline void zyufxflasn(double &ub) {
  cin >> a >> b;
  ks.push_back(pii(a, b));
  if (ub == 0) {
    if (a != d)
      stsdsghjib(ub);
  } else if (a != d) {
    ub = min(ub, d * b / (d - a + 0.0));
  }
}

int main() {
  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    ks.clear();
    cin >> d >> n;
    td_d lb, ub, ex;
    lb = 0;
    ub = 0;
    for (int i = 0; i < n; i++)
      zyufxflasn(ub);
    while (abs(ub - lb) > 0.0000005f) {
      ex = (ub + lb) / 2;
      bool f = true;
      // cout << "Testing " << ex << endl;
      for (int i = 0; i < n; i++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (ks[i].second >= ex)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (ks[i].first / (ex - ks[i].second) * ex < d) {
          f = false;
        }
      }
      if (f) {
        lb = ex;
      } else {
        ub = ex;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << t << ": " << ub << endl;
  }
}
