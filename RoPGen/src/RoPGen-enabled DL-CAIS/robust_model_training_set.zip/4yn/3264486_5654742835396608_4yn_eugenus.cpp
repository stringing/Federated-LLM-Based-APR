#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;
typedef pair<int, int> par;
typedef long long int tint;

int a;

int main() {
  freopen("test.txt","r",stdin);
freopen("out.txt","w",stdout);
cin >> a;
  for (int ans = 1; ans <= a; ans++) {
    
    int cnd;int be;
cin >> be >> cnd;
    priority_queue<int> best;
    best.push(be);
    int j, hi;
    for (int lo = 0; lo < cnd; lo++) {
      int ans = best.top() - 1;
      best.pop();
      j = ans / 2 + (ans % 2);
      hi = ans / 2;
      best.push(j);
      best.push(hi);
    }
    cout<<"Case #"<<ans<<": "<<j<<" "<<hi<<"\n"<<endl;
  }
return 0;}
