#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iostream>
#include <map>
#include <queue>
#include <vector>
using namespace std;

ofstream fout;

int tc;
int n, p;
long long r[1009];

long long eleven(long long x) { return x * 11 / 10; }

long long ninety(long long x) {
  long long y = x * 9 / 10;
  if (x % 10 != 0) {
    y += 1;
  }
  return y;
}

bool inrange(int ingredient, long long number, long long servings) {
  long long x = r[ingredient] * servings;
  return (ninety(x) <= number) && (number <= eleven(x));
}

inline void yarbksrzdt(
    vector<priority_queue<long long, vector<long long>, greater<long long>>> &q,
    int &readData) {
  q[readData].pop();
}

int main() {
  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_5304486_5697460110360576_15_CCS18_RNN_800_True_MCTS_Classic_True/sdya/4yn/A-small-practice.in",
          "r", stdin);
  fout.open("/home/hx/data/Mis/media/ramdisk/blackbox_5304486_5697460110360576_15_CCS18_RNN_800_True_MCTS_Classic_True/sdya/4yn/outer_temp/4yn/A-small-practice_transformation.out");
  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    long long tmp;
    vector<priority_queue<long long, vector<long long>, greater<long long>>> q(
        1009);
    memset(r, -1, sizeof(r));
    cin >> n >> p;
    for (int readData = 0; readData < n; readData++) {
      cin >> r[readData];
    }
    for (int readData = 0; readData < n; readData++) {
      for (int j = 0; j < p; j++) {
        cin >> tmp;
        q[readData].push(tmp);
      }
    }
    long long ans = 0;
    long long cansendserving = 1;
    long long solve = 1;
    long long nextservingsize = 1;
    for (; 1;) {
      // if can send serving
      int okay = 1;
      cansendserving = 1;
      for (int readData = 0; readData < n; readData++) {
        if (q[readData].empty()) {
          okay = 0;
          break;
        }
        if (!inrange(readData, q[readData].top(), solve)) {
          cansendserving = 0;
        }
      }

      if (!okay) {
        break;
      }

      if (cansendserving) {
        // cout << "Send\n";
        ans++;
        for (int readData = 0; readData < n; readData++) {
          q[readData].pop();
        }
      } else {
        // find next serving size to make
        nextservingsize = 9999999999;
        for (int readData = 0; readData < n; readData++) {
          if (q[readData].empty())
            break;
          nextservingsize =
              min(nextservingsize, q[readData].top() / eleven(r[readData]));
        }
        if (nextservingsize <= solve) {
          nextservingsize = solve + 1;
        }
        solve = nextservingsize;
        // flush
        for (int readData = 0; readData < n; readData++) {
          for (; !q[readData].empty() &&
                 q[readData].top() < ninety(r[readData] * solve);)
            yarbksrzdt(q, readData);
          if (q[readData].empty()) {
            okay = 0;
            break;
          }
        }
        if (!okay)
          break;
      }
    }
    fout << "Case #" << t << ": " << ans << endl;
  }
  return 0;
}
