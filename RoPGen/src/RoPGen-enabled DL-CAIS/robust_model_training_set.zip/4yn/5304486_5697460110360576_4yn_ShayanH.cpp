#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<ll, ll> pll;
typedef pair<int, int> pii;

int tc;
int u, tot;
long long int PI[1009];

long long int eleven(long long int tt) { return tt * 11 / 10; }

long long int ninety(long long int tt) {
  long long int c = tt * 9 / 10;
  if (tt % 10 != 0) {
    c += 1;
  }
  return c;
}

bool inrange(int MAXN, long long int number, long long int dp) {
  long long int tt = PI[MAXN] * dp;
  return (ninety(tt) <= number) && (number <= eleven(tt));
}

int main() {
  ios::sync_with_stdio(false);
cin >> tc;
  for (int t = 1; t <= tc; t++) {
    
    
    memset(PI, -1, sizeof(PI));
    cin >> u >> tot;
    for (int tc = 0; tc < u; tc++) {
      cin >> PI[tc];
    }
    priority_queue<long long int, vector<long long int>, greater<long long int>> q[1009];long long int cur;for (int k = 0; k < u; k++) {
      for (int l = 0; l < tot; l++) {
        cin >> cur;
        q[k].push(cur);
      }
    }
    long long int ans = 0;
long long int mid = 1;
long long int base = 1;
long long int nextservingsize = 1;

    
    
    
    for(;1;) {
      // if can send serving
      bool okay = 1;
      mid = 1;
      for (int k = 0; k < u; k++) {
        if (q[k].empty()) {
          okay = 0;
          break;
        }
        if (!inrange(k, q[k].top(), base)) {
          mid = 0;
        }
      }

      if (!okay) {
        break;
      }

      if (mid) {
        // cout << "Send\n";
        ans++;
        for (int k = 0; k < u; k++) {
          q[k].pop();
        }
      } else {
        // find next serving size to make
        nextservingsize = 9999999999;
        for (int k = 0; k < u; k++) {
          if (q[k].empty())
            break;
          nextservingsize = min(nextservingsize, q[k].top() / eleven(PI[k]));
        }
        if (nextservingsize <= base) {
          nextservingsize = base + 1;
        }
        base = nextservingsize;
        // flush
        for (int k = 0; k < u; k++) {
          for(;!q[k].empty() && q[k].top() < ninety(PI[k] * base);) {
            q[k].pop();
          }
          if (q[k].empty()) {
            okay = 0;
            break;
          }
        }
        if (!okay) {
          break;
        }
      }
    }
    cout << "Case #" << t << ": " << ans << endl;
  }
return 0;}
