#include <bits/stdc++.h>
using namespace std;

typedef long long int lli;
typedef pair<lli, lli> pii;

int ans;

lli d, n, a, b;
vector<pii> r;

int main() {
  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_8294486_5630967708385280_15_CCS18_RNN_800_True_MCTS_Classic_True/jiian/4yn/outer_temp/4yn/A-small-practice_transformation.out", "w", stdout);

  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_8294486_5630967708385280_15_CCS18_RNN_800_True_MCTS_Classic_True/jiian/4yn/A-small-practice.in",
          "r", stdin);
  cin >> ans;
  for (int cas = 1; cas <= ans; cas++) {
    r.clear();
    cin >> d >> n;
    double lb, m, ex;
    lb = 0;
    m = 0;
    for (int i = 0; i < n; i++) {
      cin >> a >> b;
      r.push_back(pii(a, b));
      if (m == 0) {
        if (a != d) {
          m = d * b / (d - a + 0.0);
        }
      } else if (a != d)
        m = min(m, d * b / (d - a + 0.0));
    }
    for (; abs(m - lb) > 0.0000005f;) {
      ex = (m + lb) / 2;
      int f = 1;
      // cout << "Testing " << ex << endl;
      for (int i = 0; i < n; i++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (r[i].second >= ex) {
          continue;
        }
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (r[i].first / (ex - r[i].second) * ex < d) {
          f = 0;
        }
      }
      if (f) {
        lb = ex;
      } else {
        m = ex;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << cas << ": " << m << endl;
  }
  return 0;
}
