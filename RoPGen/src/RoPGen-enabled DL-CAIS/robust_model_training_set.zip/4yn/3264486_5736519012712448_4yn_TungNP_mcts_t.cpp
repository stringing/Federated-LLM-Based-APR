#include <bits/stdc++.h>
#include <fstream>
#include <stdio.h>
#include <string>
using namespace std;

int tc;

inline void tcohlnfnza(int &t, int &fl) {
  printf("Case #%d: IMPOSSIBLE\n", t, fl);
}

int main() {
  scanf("%d ", &tc);
  int t;
  for (t = 1; t <= tc; t++) {
    string argc;
    int k, fl = 0;
    cin >> argc >> k;
    for (int i = 0; i < argc.size() - k + 1; i++) {
      if (argc[i] == '-') {
        // cout << "Flip at " << i << endl;
        fl++;
        for (int j = i; j < i + k; j++) {
          if (argc[j] == '-')
            argc[j] = '+';
          else
            argc[j] = '-';
        }
      }
    }
    int f = 1;
    for (int i = argc.size() - k + 1; i < argc.size(); i++) {
      if (argc[i] == '-')
        f = 0;
    }
    if (f == 1) {
      printf("Case #%d: %d\n", t, fl);
    } else
      tcohlnfnza(t, fl);
  }
}
