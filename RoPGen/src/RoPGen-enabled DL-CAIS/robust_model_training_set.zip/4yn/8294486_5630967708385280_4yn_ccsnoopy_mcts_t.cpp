#include <bits/stdc++.h>
#include <utility>
using namespace std;

typedef double td_d;
typedef pair<int, int> ii;
typedef long long LL;
typedef pair<LL, LL> pii;

int tc;

LL d, n, a, b;
vector<pii> open;

int main() {
  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_8294486_5630967708385280_16_CCS18_RNN_800_True_MCTS_Classic_True/ccsnoopy/4yn/A-small-practice.in",
          "r", stdin);

  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    open.clear();
    cin >> d >> n;
    td_d lb, ub, ex;
    lb = 0;
    ub = 0;
    for (int i = 0; i < n; i++) {
      cin >> a >> b;
      open.push_back(pii(a, b));
      if (ub == 0) {
        if (a != d) {
          ub = d * b / (d - a + 0.0);
        }
      } else if (a != d) {
        ub = min(ub, d * b / (d - a + 0.0));
      }
    }
    while (abs(ub - lb) > 0.0000005f) {
      ex = (ub + lb) / 2;
      bool f = true;
      // cout << "Testing " << ex << endl;
      for (int i = 0; i < n; i++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (open[i].second >= ex)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (open[i].first / (ex - open[i].second) * ex < d) {
          f = false;
        }
      }
      if (f) {
        lb = ex;
      } else {
        ub = ex;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << t << ": " << ub << endl;
  }
}
