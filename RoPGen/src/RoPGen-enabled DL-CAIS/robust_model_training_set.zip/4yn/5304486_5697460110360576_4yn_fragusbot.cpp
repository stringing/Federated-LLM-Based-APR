#include <bits/stdc++.h>
using namespace std;
int tc;
int n, s;
long long int w[1009];

long long int eleven(long long int N) { return N * 11 / 10; }

long long int ninety(long long int N) {
  long long int a = N * 9 / 10;
  if (N % 10 != 0) {
    a += 1;
  }
  return a;
}

bool inrange(int tt, long long int number, long long int pw) {
  long long int N = w[tt] * pw;
  return (ninety(N) <= number) && (number <= eleven(N));
}

int main() {
  scanf("%d",&tc);
  for (int cc = 1; cc <= tc; ++cc) {
    long long int tmp;
    priority_queue<long long int, vector<long long int>, greater<long long int>> q[1009];
    memset(w, -1, sizeof(w));
    scanf("%d%d",&n,&s);
    for (int k = 0; k < n; ++k) {
      cin >> w[k];
    }
    for (int k = 0; k < n; ++k) {
      for (int j = 0; j < s; ++j) {
        cin >> tmp;
        q[k].push(tmp);
      }
    }
    long long int ans = 0;
    long long int cansendserving = 1;
    long long int foo = 1;
    long long int nextservingsize = 1;
    for(;1;) {
      // if can send serving
      bool okay = 1;
      cansendserving = 1;
      for (int k = 0; k < n; ++k) {
        if (q[k].empty()) {
          okay = 0;
          break;
        }
        if (!inrange(k, q[k].top(), foo)) {
          cansendserving = 0;
        }
      }

      if (!okay) {
        break;
      }

      if (cansendserving) {
        // cout << "Send\n";
        ++ans;
        for (int k = 0; k < n; ++k) {
          q[k].pop();
        }
      } else {
        // find next serving size to make
        nextservingsize = 9999999999;
        for (int k = 0; k < n; ++k) {
          if (q[k].empty())
            break;
          nextservingsize = min(nextservingsize, q[k].top() / eleven(w[k]));
        }
        if (nextservingsize <= foo) {
          nextservingsize = foo + 1;
        }
        foo = nextservingsize;
        // flush
        for (int k = 0; k < n; ++k) {
          for(;!q[k].empty() && q[k].top() < ninety(w[k] * foo);) {
            q[k].pop();
          }
          if (q[k].empty()) {
            okay = 0;
            break;
          }
        }
        if (!okay) {
          break;
        }
      }
    }
    cout << "Case #" << cc << ": " << ans << endl;
  }
}
