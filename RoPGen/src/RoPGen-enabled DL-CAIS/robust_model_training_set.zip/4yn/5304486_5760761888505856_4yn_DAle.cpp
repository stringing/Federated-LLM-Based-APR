#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstring>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <regex>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <tuple>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>
using namespace std;

int t;

void split_main_42_44(int* v,char ifs[30][30],int* newd) {
        for (int test = 0; test < (*v); ++test) {
          ifs[(*newd)][test] = ifs[(*newd) + 1][test];
        }
}
int main() {
  ios_base::sync_with_stdio(false);
cin >> t;
  for (int test = 1; test <= t; ++test) {
    int k, v;
    cin >> k >> v;
    char y[30][30];
    for (int n = 0; n < k; ++n) {
      for (int m = 0; m < v; ++m) {
        cin >> y[n][m];
      }
    }
    for (int newd = 0; newd < k; ++newd) {
      // sweep left to right
      for (int bs = 1; bs < v; ++bs) {
        if (y[newd][bs - 1] != '?' && y[newd][bs] == '?') {
          y[newd][bs] = y[newd][bs - 1];
        }
      }
      // sweep right to left
      for (int bs = v - 2; bs >= 0; --bs) {
        if (y[newd][bs + 1] != '?' && y[newd][bs] == '?') {
          y[newd][bs] = y[newd][bs + 1];
        }
      }
    }
    for (int newd = 1; newd < k; ++newd) {
      // sweep up to down
      if (y[newd - 1][0] != '?' && y[newd][0] == '?') {
        for (int bs = 0; bs < v; ++bs) {
          y[newd][bs] = y[newd - 1][bs];
        }
      }
    }
    for (int newd = k - 1; newd >= 0; --newd) {
      // sweep down to up
      if (y[newd + 1][0] != '?' && y[newd][0] == '?') {split_main_42_44(&v,y,&newd);
}
    }
    cout << "Case #" << test << ":\n";
    for (int newd = 0; newd < k; ++newd) {
      for (int bs = 0; bs < v; ++bs) {
        cout << y[newd][bs];
      }
      cout << endl;
    }
  }
return 0;}
