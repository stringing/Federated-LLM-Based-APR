#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <fstream>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;
ofstream fout;

int tc;

int main() {
  fout.open("/home/hx/data/Mis/media/ramdisk/blackbox_5304486_5760761888505856_15_CCS18_RNN_800_True_MCTS_Classic_True/sdya/4yn/outer_temp/4yn/A-small-practice_transformation.out");

  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    int r, d;
    cin >> r >> d;
    char cake[30][30];
    for (int solve = 0; solve < r; solve++) {
      for (int readData = 0; readData < d; readData++) {
        cin >> cake[solve][readData];
      }
    }
    for (int solve = 0; solve < r; solve++) {
      // sweep left to right
      {
        int readData = 1;
        while (readData < d) {
          if (cake[solve][readData - 1] != '?' &&
              cake[solve][readData] == '?') {
            cake[solve][readData] = cake[solve][readData - 1];
          }
          readData++;
        }
      }
      // sweep right to left
      for (int readData = d - 2; readData >= 0; readData--) {
        if (cake[solve][readData + 1] != '?' && cake[solve][readData] == '?') {
          cake[solve][readData] = cake[solve][readData + 1];
        }
      }
    }
    for (int solve = 1; solve < r; solve++) {
      // sweep up to down
      if (cake[solve - 1][0] != '?' && cake[solve][0] == '?') {
        for (int readData = 0; readData < d; readData++) {
          cake[solve][readData] = cake[solve - 1][readData];
        }
      }
    }
    for (int solve = r - 1; solve >= 0; solve--) {
      // sweep down to up
      if (cake[solve + 1][0] != '?')
        if (cake[solve][0] == '?') {
          for (int readData = 0; readData < d; readData++) {
            cake[solve][readData] = cake[solve + 1][readData];
          }
        }
    }
    fout << "Case #" << t << ":\n";
    for (int solve = 0; solve < r; solve++) {
      for (int readData = 0; readData < d; readData++) {
        fout << cake[solve][readData];
      }
      fout << endl;
    }
  }
}
