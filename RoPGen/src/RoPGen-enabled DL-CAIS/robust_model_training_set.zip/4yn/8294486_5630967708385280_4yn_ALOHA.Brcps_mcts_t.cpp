#include <algorithm>
#include <bits/std_abs.h>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <math.h>
#include <memory>
#include <queue>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <utility>
#include <vector>

using namespace std;
ofstream fout;

typedef long long lld;
typedef pair<lld, lld> pii;
typedef double dbl;

int testCase;

lld d, T, a, b;
vector<pii> ks;

inline void foqlhwghqp(dbl &lb, dbl &ex) { lb = ex; }

int main() {
  fout.open("/home/hx/data/Mis/media/ramdisk/blackbox_8294486_5630967708385280_15_CCS18_RNN_800_True_MCTS_Classic_True/ALOHA.Brcps/4yn/outer_temp/4yn/A-small-practice_transformation.out");

  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_8294486_5630967708385280_15_CCS18_RNN_800_True_MCTS_Classic_True/ALOHA.Brcps/4yn/A-small-practice.in",
          "r", stdin);

  scanf("%d ", &testCase);
  int C;
  for (C = 1; C <= testCase; C++) {
    ks.clear();
    scanf("%lld %lld ", &d, &T);
    dbl lb, ub, ex;
    lb = 0;
    ub = 0;
    for (int i = 0; i < T; i++) {
      scanf("%lld %lld ", &a, &b);
      ks.push_back(pii(a, b));
      if (ub == 0) {
        if (a != d) {
          ub = d * b / (d - a + 0.0);
        }
      } else if (a != d) {
        ub = min(ub, d * b / (d - a + 0.0));
      }
    }
    for (; abs(ub - lb) > 0.0000005f;) {
      ex = (ub + lb) / 2;
      bool f = true;
      // cout << "Testing " << ex << endl;
      for (int i = 0; i < T; i++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (ks[i].second >= ex)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (ks[i].first / (ex - ks[i].second) * ex < d)
          f = 0;
      }
      if (f)
        foqlhwghqp(lb, ex);
      else {
        ub = ex;
      }
    }
    fout << fixed << setprecision(7) << "Case #" << C << ": " << ub << endl;
  }
}
