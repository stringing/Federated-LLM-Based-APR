#include <algorithm>
#include <assert.h>
#include <bits/stdc++.h>
#include <iostream>
#include <map>
#include <math.h>
#include <queue>
#include <stdio.h>
#include <string.h>
#include <string>
#include <vector>
using namespace std;
typedef long long lld;

int T;

int main() {
  freopen("C-small-1-attempt0.in","r",stdin);
freopen("output.txt","w",stdout);
scanf("%d",&T);
  for (int i = 1; i <= T; i++) {
    int N, j;
    scanf("%d%d",&N,&j);
    priority_queue<int> T1;
    int B, P;
    T1.push(N);
    for (int A = 0; A < j; A++) {
      int i = T1.top() - 1;
      T1.pop();
      B = i / 2 + (i % 2);
      P = i / 2;
      T1.push(B);
      T1.push(P);
    }
    printf("Case #%d: %d %d\n", i, B, P);
  }
return 0;}
