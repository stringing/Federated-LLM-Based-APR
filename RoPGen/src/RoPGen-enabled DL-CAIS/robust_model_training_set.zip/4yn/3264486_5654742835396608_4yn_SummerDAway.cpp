#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
using namespace std;
int o;

int main() {
  freopen("D-small-attempt1.in","r",stdin);
freopen("D-small-attempt1.out","w",stdout);
scanf("%d",&o);
  for (int i = 1; i <= o; ++i) {
    int x3, x2;
    scanf("%d%d",&x3,&x2);
    priority_queue<int> x;
    int j, x1;
    x.push(x3);
    for (int o = 0; o < x2; ++o) {
      int i = x.top() - 1;
      x.pop();
      j = i / 2 + (i % 2);
      x1 = i / 2;
      x.push(j);
      x.push(x1);
    }
    printf("Case #%d: %d %d\n", i, j, x1);
  }
}
