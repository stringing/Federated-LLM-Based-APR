#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
using namespace std;

int o;

void split_main_8_54(int* o) {
  for (int k = 1; k <= (*o); ++k) {
    int x3, x1;
    scanf("%d%d",&x3,&x1);
    char x[30][30];
    for (int o = 0; o < x3; ++o) {
      for (int x2 = 0; x2 < x1; ++x2) {
        cin >> x[o][x2];
      }
    }
    for (int x2 = 0; x2 < x3; ++x2) {
      // sweep left to right
      for (int y = 1; y < x1; ++y) {
        if (x[x2][y - 1] != '?' && x[x2][y] == '?') {
          x[x2][y] = x[x2][y - 1];
        }
      }
      // sweep right to left
      for (int y = x1 - 2; y >= 0; --y) {
        if (x[x2][y + 1] != '?' && x[x2][y] == '?') {
          x[x2][y] = x[x2][y + 1];
        }
      }
    }
    for (int x2 = 1; x2 < x3; ++x2) {
      // sweep up to down
      if (x[x2 - 1][0] != '?' && x[x2][0] == '?') {
        for (int y = 0; y < x1; ++y) {
          x[x2][y] = x[x2 - 1][y];
        }
      }
    }
    for (int x2 = x3 - 1; x2 >= 0; --x2) {
      // sweep down to up
      if (x[x2 + 1][0] != '?' && x[x2][0] == '?') {
        for (int y = 0; y < x1; ++y) {
          x[x2][y] = x[x2 + 1][y];
        }
      }
    }
    printf("Case #%d:\n",k);
    for (int x2 = 0; x2 < x3; ++x2) {
      for (int y = 0; y < x1; ++y) {
        cout << x[x2][y];
      }
      printf("\n");
    }
  }
}
int main() {
  freopen("D-small-attempt1.in","r",stdin);
freopen("D-small-attempt1.out","w",stdout);
scanf("%d",&o);
  split_main_8_54(&o);

}
