#include <algorithm>
#include <bits/stdc++.h>
#include <bitset>
#include <cstdio>
#include <ctime>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <vector>
using namespace std;

int tc;

int main() {
  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    string s;
    int readData, fl = 0;
    cin >> s >> readData;
    for (int i = 0; i < s.size() - readData + 1; i++) {
      if (s[i] == '-') {
        // cout << "Flip at " << i << endl;
        fl++;
        for (int j = i; j < i + readData; j++) {
          if (s[j] == '-')
            s[j] = '+';
          else
            s[j] = '-';
        }
      }
    }
    int f = 1;
    for (int i = s.size() - readData + 1; i < s.size(); i++) {
      if (s[i] == '-')
        f = 0;
    }
    if (f == 1) {
      printf("Case #%d: %d\n", t, fl);
    } else {
      printf("Case #%d: IMPOSSIBLE\n", t, fl);
    }
  }
}
