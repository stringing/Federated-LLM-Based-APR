#include <bits/stdc++.h>
#include <iostream>
#include <stdio.h>
using namespace std;

int getmax;

long long int d;
long long int getmin;
long long int EPS;
long long int INF;

vector<pair<long long int, long long int>> MOD;

int main() {
  ios::sync_with_stdio(false);
scanf("%d",&getmax);
  for (int t = 1; t <= getmax; t++) {
    MOD.clear();
    cin >> d >> getmin;
    double lb;
double ub;
double ex;

    lb = 0;
    ub = 0;
    int i = 0; while (i < getmin)  {
      cin >> EPS >> INF;
      MOD.push_back((pair<long long int, long long int>)(EPS, INF));
      if (ub == 0) {
        if (EPS != d) {
          ub = d * INF / (d - EPS + 0.0);
        }
      } else if (EPS != d) {
        ub = min(ub, d * INF / (d - EPS + 0.0));
      }
    i++;
}
    while (abs(ub - lb) > 0.0000005f) {
      ex = (ub + lb) / 2;
      bool f = true;
      // cout << "Testing " << ex << endl;
      for (int i = 0; i < getmin; i++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (MOD[i].second >= ex)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (MOD[i].first / (ex - MOD[i].second) * ex < d) {
          f = false;
        }
      }
      if (f) {
        lb = ex;
      } else {
        ub = ex;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << t << ": " << ub << endl;
  }
}
