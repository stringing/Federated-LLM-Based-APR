#include <bits/stdc++.h>
#include <cmath>
#include <fstream>
#include <string>
using namespace std;
int fout;

int main() {
  cin >> fout;
  for (int i = 1; i <= fout; i++) {
    int max_r_n;  int r;
    cin >> max_r_n >> r;
    priority_queue<int> buff;
    buff.push(max_r_n);
    int j;  int z;
    for (int ch = 0; ch < r; ch++) {
      int i = buff.top() - 1;
      buff.pop();
      j = i / 2 + (i % 2);
      z = i / 2;
      buff.push(j);
      buff.push(z);
    }
    printf("Case #%d: %d %d\n", i, j, z);
  }
return 0;}
