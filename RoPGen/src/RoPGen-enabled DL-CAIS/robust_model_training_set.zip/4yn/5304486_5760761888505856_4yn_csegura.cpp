#include <algorithm>
#include <bits/stdc++.h>
#include <float.h>
#include <iomanip>
#include <iostream>
#include <limits.h>
#include <list>
#include <map>
#include <math.h>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <vector>
using namespace std;

int tests;

int main() {
  cin >> tests;
  for (int di = 1; di <= tests; di++) {
    int additional, K;
    cin >> additional >> K;
    char solution[30][30];
    for (int Aj = 0; Aj < additional; Aj++) {
      for (int ci = 0; ci < K; ci++) {
        cin >> solution[Aj][ci];
      }
    }
    for (int ci = 0; ci < additional; ci++) {
      // sweep left to right
      for (int N = 1; N < K; N++) {
        if (solution[ci][N - 1] != '?' && solution[ci][N] == '?') {
          solution[ci][N] = solution[ci][N - 1];
        }
      }
      // sweep right to left
      for (int N = K - 2; N >= 0; N--) {
        if (solution[ci][N + 1] != '?' && solution[ci][N] == '?') {
          solution[ci][N] = solution[ci][N + 1];
        }
      }
    }
    for (int ci = 1; ci < additional; ci++) {
      // sweep up to down
      if (solution[ci - 1][0] != '?' && solution[ci][0] == '?') {
        for (int N = 0; N < K; N++) {
          solution[ci][N] = solution[ci - 1][N];
        }
      }
    }
    for (int ci = additional - 1; ci >= 0; ci--) {
      // sweep down to up
      if (solution[ci + 1][0] != '?' && solution[ci][0] == '?') {
        for (int N = 0; N < K; N++) {
          solution[ci][N] = solution[ci + 1][N];
        }
      }
    }
    cout << "Case #" << di << ":\n";
    for (int ci = 0; ci < additional; ci++) {
      for (int N = 0; N < K; N++) {
        cout << solution[ci][N];
      }
      cout << endl;
    }
  }
}
