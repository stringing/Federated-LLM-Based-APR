#include <bits/stdc++.h>
#include <iostream>
#include <utility>
using namespace std;
typedef pair<int, int> pii;
typedef long long ll;

const int MAXN = 1 * 1000 + 10;

int tc;

int main() {
  ios::sync_with_stdio(false);

  cin >> tc;
  for (int tt = 1; tt <= tc; tt++) {
    int r, ans;
    cin >> r >> ans;
    char cake[30][30];
    for (int i = 0; i < r; i++) {
      for (int j = 0; j < ans; j++) {
        cin >> cake[i][j];
      }
    }
    for (int i = 0; i < r; i++) {
      // sweep left to right
      for (int j = 1; j < ans; j++) {
        if (cake[i][j - 1] != '?' && cake[i][j] == '?') {
          cake[i][j] = cake[i][j - 1];
        }
      }
      // sweep right to left
      for (int j = ans - 2; j >= 0; j--) {
        if (cake[i][j + 1] != '?' && cake[i][j] == '?') {
          cake[i][j] = cake[i][j + 1];
        }
      }
    }
    for (int i = 1; i < r; i++) {
      // sweep up to down
      if (cake[i - 1][0] != '?' && cake[i][0] == '?') {
        for (int j = 0; j < ans; j++) {
          cake[i][j] = cake[i - 1][j];
        }
      }
    }
    for (int i = r - 1; i >= 0; i--) {
      // sweep down to up
      if (cake[i + 1][0] != '?' && cake[i][0] == '?') {
        for (int j = 0; j < ans; j++) {
          cake[i][j] = cake[i + 1][j];
        }
      }
    }
    cout << "Case #" << tt << ":\n";
    for (int i = 0; i < r; i++) {
      for (int j = 0; j < ans; j++) {
        cout << cake[i][j];
      }
      cout << endl;
    }
  }
  return 0;
}
