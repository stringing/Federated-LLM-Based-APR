#include <algorithm>
#include <bits/stdc++.h>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <functional>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdio.h>
#include <string.h>
#include <string>
#include <utility>
#include <vector>
using namespace std;

typedef long long LL;

int T;

void split_main_8_54(int* T) {
  for (int b = 1; b <= (*T); ++b) {
    int a, cs;
    scanf("%d%d",&a,&cs);
    char flag[30][30];
    for (int _cas = 0; _cas < a; ++_cas) {
      for (int _i = 0; _i < cs; ++_i) {
        cin >> flag[_cas][_i];
      }
    }
    for (int _cas = 0; _cas < a; ++_cas) {
      // sweep left to right
      for (int _i = 1; _i < cs; ++_i) {
        if (flag[_cas][_i - 1] != '?' && flag[_cas][_i] == '?') {
          flag[_cas][_i] = flag[_cas][_i - 1];
        }
      }
      // sweep right to left
      for (int _i = cs - 2; _i >= 0; --_i) {
        if (flag[_cas][_i + 1] != '?' && flag[_cas][_i] == '?') {
          flag[_cas][_i] = flag[_cas][_i + 1];
        }
      }
    }
    for (int _cas = 1; _cas < a; ++_cas) {
      // sweep up to down
      if (flag[_cas - 1][0] != '?' && flag[_cas][0] == '?') {
        for (int _i = 0; _i < cs; ++_i) {
          flag[_cas][_i] = flag[_cas - 1][_i];
        }
      }
    }
    for (int _cas = a - 1; _cas >= 0; --_cas) {
      // sweep down to up
      if (flag[_cas + 1][0] != '?' && flag[_cas][0] == '?') {
        for (int _i = 0; _i < cs; ++_i) {
          flag[_cas][_i] = flag[_cas + 1][_i];
        }
      }
    }
    printf("Case #%d:\n",b);
    for (int _cas = 0; _cas < a; ++_cas) {
      for (int _i = 0; _i < cs; ++_i) {
        cout << flag[_cas][_i];
      }
      printf("\n");
    }
  }
}
int main() {
  scanf("%d",&T);
  split_main_8_54(&T);

}
