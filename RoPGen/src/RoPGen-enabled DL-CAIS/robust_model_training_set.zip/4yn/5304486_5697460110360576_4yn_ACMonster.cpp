#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <set>
#include <vector>
using namespace std;
int trans;
int inf, dp;
long long int g[1009];

long long int eleven(long long int totalTest) { return totalTest * 11 / 10; }

long long int ninety(long long int totalTest) {
  long long int peer = totalTest * 9 / 10;
  if (totalTest % 10 != 0) {
    peer += 1;
  }
  return peer;
}

bool inrange(int A, long long int nex, long long int H) {
  long long int totalTest = g[A] * H;
  return (ninety(totalTest) <= nex) && (nex <= eleven(totalTest));
}

int main() {
  scanf("%d",&trans);
  for (int test = 1; test <= trans; test++) {
    long long int sum;
    priority_queue<long long int, vector<long long int>, greater<long long int>> mid[1009];
    memset(g, -1, sizeof(g));
    scanf("%d%d",&inf,&dp);
    for (int a = 0; a < inf; a++) {
      cin >> g[a];
    }
    for (int Ar = 0; Ar < inf; Ar++) {
      for (int c = 0; c < dp; c++) {
        cin >> sum;
        mid[Ar].push(sum);
      }
    }
    long long int Hd = 0;
    long long int cnt = 1;
    long long int m = 1;
    long long int laser = 1;
    for(;1;) {
      // if can send serving
      bool H0 = 1;
      cnt = 1;
      for (int flag = 0; flag < inf; flag++) {
        if (mid[flag].empty()) {
          H0 = 0;
          break;
        }
        if (!inrange(flag, mid[flag].top(), m)) {
          cnt = 0;
        }
      }

      if (!H0) {
        break;
      }

      if (cnt) {
        // cout << "Send\n";
        Hd++;
        for (int c = 0; c < inf; c++) {
          mid[c].pop();
        }
      } else {
        // find next serving size to make
        laser = 9999999999;
        for (int c = 0; c < inf; c++) {
          if (mid[c].empty())
            break;
          laser = min(laser, mid[c].top() / eleven(g[c]));
        }
        if (laser <= m) {
          laser = m + 1;
        }
        m = laser;
        // flush
        for (int c = 0; c < inf; c++) {
          for(;!mid[c].empty() && mid[c].top() < ninety(g[c] * m);) {
            mid[c].pop();
          }
          if (mid[c].empty()) {
            H0 = 0;
            break;
          }
        }
        if (!H0) {
          break;
        }
      }
    }
    cout << "Case #" << test << ": " << Hd << endl;
  }
return 0;}
