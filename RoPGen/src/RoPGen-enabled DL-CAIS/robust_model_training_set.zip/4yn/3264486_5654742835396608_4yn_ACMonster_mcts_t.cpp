#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <set>
#include <stdio.h>
#include <vector>
using namespace std;
typedef long long int lli;

int tc;

inline void knautwpkxy(int &y, priority_queue<int> &pq, int &z) {
  int t = pq.top() - 1;
  pq.pop();
  y = t / 2 + (t % 2);
  z = t / 2;
  pq.push(y);
  pq.push(z);
}

int main() {
  scanf("%d ", &tc);
  for (int t = 1; t <= tc; t++) {
    int n, get;
    scanf("%d %d ", &n, &get);
    priority_queue<int> pq;
    pq.push(n);
    int y, z;
    for (int i = 0; i < get; i++)
      knautwpkxy(y, pq, z);
    printf("Case #%d: %d %d\n", t, y, z);
  }
}
