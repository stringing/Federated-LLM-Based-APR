#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
using namespace std;
typedef long long td_ll;

int tc;
int TC, p;
long long r[1009];

long long eleven(long long x) { return x * 11 / 10; }

long long ninety(long long x) {
  td_ll y = x * 9 / 10;
  if (x % 10 != 0) {
    y += 1;
  }
  return y;
}

bool inrange(int ingredient, long long number, long long servings) {
  td_ll x = r[ingredient] * servings;
  return (ninety(x) <= number) && (number <= eleven(x));
}

int main() {
  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_5304486_5697460110360576_15_CCS18_RNN_800_True_MCTS_Classic_True/SummerDAway/4yn/A-small-practice.in",
          "r", stdin);
  freopen("/home/hx/data/Mis/media/ramdisk/blackbox_5304486_5697460110360576_15_CCS18_RNN_800_True_MCTS_Classic_True/SummerDAway/4yn/outer_temp/4yn/A-small-practice_transformation.out",
          "w", stdout);
  cin >> tc;
  for (int b = 1; b <= tc; b++) {
    td_ll tmp;
    priority_queue<long long, vector<long long>, greater<long long>> q[1009];
    memset(r, -1, sizeof(r));
    cin >> TC >> p;
    for (int work = 0; work < TC; work++) {
      cin >> r[work];
    }
    int work;
    for (work = 0; work < TC; work++) {
      for (int j = 0; j < p; j++) {
        cin >> tmp;
        q[work].push(tmp);
      }
    }
    td_ll ans = 0;
    td_ll cansendserving = 1;
    td_ll curservingsize = 1;
    td_ll nextservingsize = 1;
    while (1) {
      // if can send serving
      int okay = 1;
      cansendserving = 1;
      {
        int work = 0;
        while (work < TC) {
          if (q[work].empty()) {
            okay = 0;
            break;
          }
          if (!inrange(work, q[work].top(), curservingsize)) {
            cansendserving = 0;
          }
          work++;
        }
      }

      if (!okay) {
        break;
      }

      if (cansendserving) {
        // cout << "Send\n";
        ans++;
        for (int work = 0; work < TC; work++) {
          q[work].pop();
        }
      } else {
        // find next serving size to make
        nextservingsize = 9999999999;
        for (int work = 0; work < TC; work++) {
          if (q[work].empty())
            break;
          nextservingsize =
              min(nextservingsize, q[work].top() / eleven(r[work]));
        }
        if (nextservingsize <= curservingsize) {
          nextservingsize = curservingsize + 1;
        }
        curservingsize = nextservingsize;
        // flush
        {
          int work = 0;
          while (work < TC) {
            for (; !q[work].empty() &&
                   q[work].top() < ninety(r[work] * curservingsize);) {
              q[work].pop();
            }
            if (q[work].empty()) {
              okay = 0;
              break;
            }
            work++;
          }
        }
        if (!okay) {
          break;
        }
      }
    }
    cout << "Case #" << b << ": " << ans << endl;
  }
  return 0;
}
