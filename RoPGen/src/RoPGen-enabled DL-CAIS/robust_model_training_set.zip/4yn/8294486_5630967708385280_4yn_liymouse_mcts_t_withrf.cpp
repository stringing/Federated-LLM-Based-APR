#include <algorithm>
#include <bits/stdc++.h>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <numeric>
#include <set>
#include <sstream>
#include <stdio.h>
#include <vector>
using namespace std;

typedef long long i64d;
typedef pair<i64d, i64d> pii;
typedef double dbl;

int ca;

i64d d, n, a, b;
vector<pii> ks;

int main() {
  cin >> ca;
  for (int t = 1; t <= ca; t++) {
    ks.clear();
    cin >> d >> n;
    dbl lb, ub, ex;
    lb = 0;
    ub = 0;
    for (int i = 0; i < n; i++) {
      cin >> a >> b;
      ks.push_back(pii(a, b));
      if (ub == 0) {
        if (a != d) {
          ub = d * b / (d - a + 0.0);
        }
      } else if (a != d) {
        ub = min(ub, d * b / (d - a + 0.0));
      }
    }
    while (abs(ub - lb) > 0.0000005f) {
      ex = (ub + lb) / 2;
      bool f = true;
      // cout << "Testing " << ex << endl;
      for (int i = 0; i < n; i++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (ks[i].second >= ex)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (ks[i].first / (ex - ks[i].second) * ex < d) {
          f = false;
        }
      }
      if (f) {
        lb = ex;
      } else {
        ub = ex;
      }
    }
    printf("Case #%d: %.7f\n", t, ub);
  }
}
