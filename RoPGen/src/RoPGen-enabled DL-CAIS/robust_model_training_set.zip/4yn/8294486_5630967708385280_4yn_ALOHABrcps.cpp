#include <algorithm>
#include <assert.h>
#include <bits/stdc++.h>
#include <iostream>
#include <map>
#include <math.h>
#include <queue>
#include <stdio.h>
#include <string.h>
#include <string>
#include <vector>
using namespace std;

typedef long long lld;

int ck;

long long int CMin;
long long int JMin;
long long int timeList;
long long int path;

vector<pair<long long int, long long int>> T;

void split_main_43_45(vector<pair<long long int, long long int>>* T,int* j,double* T2,long long int* CMin,bool* T1) {
        if ((*T)[(*j)].first / ((*T2) - (*T)[(*j)].second) * (*T2) < (*CMin)) {
          (*T1) = false;
        }
}
int main() {
  freopen("C-small-1-attempt0.in","r",stdin);
freopen("output.txt","w",stdout);
scanf("%d",&ck);
  for (int P = 1; P <= ck; P++) {
    T.clear();
    double N = 0;
double B = 0;
double T2;

    cin >> CMin >> JMin;
    for (int A = 0; A < JMin; A++) {
      cin >> timeList >> path;
      T.push_back((pair<long long int, long long int>)(timeList, path));
      if (B == 0) {
        if (timeList != CMin) {
          B = CMin * path / (CMin - timeList + 0.0);
        }
      } else if (timeList != CMin) {
        B = min(B, CMin * path / (CMin - timeList + 0.0));
      }
    }
    for(;abs(B - N) > 0.0000005f;) {
      T2 = (B + N) / 2;
      bool T1 = true;
      // cout << "Testing " << ex << endl;
      for (int j = 0; j < JMin; j++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (T[j].second >= T2)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        split_main_43_45(&T,&j,&T2,&CMin,&T1);

      }
      if (T1) {
        N = T2;
      } else {
        B = T2;
      }
    }
    cout << fixed << setprecision(7) << "Case #" << P << ": " << B << endl;
  }
return 0;}
