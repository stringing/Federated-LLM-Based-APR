#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <vector>
using namespace std;
typedef long long ll;

int a;

int main() {
  cin >> a;
  for (int t = 1; t <= a; t++) {
    string s;
    int solve, fl = 0;
    cin >> s >> solve;
    for (int i = 0; i < s.size() - solve + 1; i++) {
      if (s[i] == '-') {
        // cout << "Flip at " << i << endl;
        fl++;
        for (int j = i; j < i + solve; j++) {
          if (s[j] == '-')
            s[j] = '+';
          else
            s[j] = '-';
        }
      }
    }
    int f = 1;
    for (int i = s.size() - solve + 1; i < s.size(); i++) {
      if (s[i] == '-')
        f = 0;
    }
    if (f == 1) {
      cout << "Case #" << t << ": " << fl << "\n";
    } else {
      printf("Case #%d: IMPOSSIBLE\n", t, fl);
    }
  }
}
