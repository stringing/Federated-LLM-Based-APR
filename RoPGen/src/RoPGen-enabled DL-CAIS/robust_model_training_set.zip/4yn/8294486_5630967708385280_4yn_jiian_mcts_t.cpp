#include <bits/stdc++.h>
#include <iostream>
#include <stdio.h>
using namespace std;

int ans;

long long d, n, m, b;
vector<pair<long long, long long>> ks;

int main() {

  cin >> ans;
  for (int cas = 1; cas <= ans; cas++) {
    ks.clear();
    cin >> d >> n;
    double lb, ub, ex;
    lb = 0;
    ub = 0;
    for (int i = 0; i < n; i++) {
      cin >> m >> b;
      ks.push_back(pair<long long, long long>(m, b));
      if (ub == 0) {
        if (m != d) {
          ub = d * b / (d - m + 0.0);
        }
      } else if (m != d) {
        ub = min(ub, d * b / (d - m + 0.0));
      }
    }
    for (; abs(ub - lb) > 0.0000005f;) {
      ex = (ub + lb) / 2;
      bool f = true;
      // cout << "Testing " << ex << endl;
      {
        int i = 0;
        while (i < n) {
          // cout << "Horse " << i << " speed " << ks[i].second << endl;
          if (ks[i].second >= ex) {
            i++;
            continue;
          }
          // cout << "Comparative speed: " << ex - ks[i].second << endl;
          // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex
          // << endl;
          if (ks[i].first / (ex - ks[i].second) * ex < d) {
            f = false;
          }
          i++;
        }
      }
      if (f) {
        lb = ex;
      } else {
        ub = ex;
      }
    }
    printf("Case #%d: %.7f\n", cas, ub);
  }
}
