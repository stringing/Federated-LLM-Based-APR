#include <algorithm>
#include <bits/stdc++.h>
#include <cassert>
#include <cctype>
#include <cmath>
#include <cstring>
#include <deque>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <string>
using namespace std;

int tc;

int main() {
  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    int r, c;
    cin >> r >> c;
    char cake[30][30];
    for (int i = 0; i < r; i++) {
      for (int solve = 0; solve < c; solve++) {
        cin >> cake[i][solve];
      }
    }
    for (int i = 0; i < r; i++) {
      // sweep left to right
      for (int solve = 1; solve < c; solve++) {
        if (cake[i][solve - 1] != '?' && cake[i][solve] == '?') {
          cake[i][solve] = cake[i][solve - 1];
        }
      }
      // sweep right to left
      for (int solve = c - 2; solve >= 0; solve--) {
        if (cake[i][solve + 1] != '?' && cake[i][solve] == '?') {
          cake[i][solve] = cake[i][solve + 1];
        }
      }
    }
    for (int i = 1; i < r; i++) {
      // sweep up to down
      if (cake[i - 1][0] != '?' && cake[i][0] == '?') {
        for (int solve = 0; solve < c; solve++) {
          cake[i][solve] = cake[i - 1][solve];
        }
      }
    }
    for (int i = r - 1; i >= 0; i--) {
      // sweep down to up
      if (cake[i + 1][0] != '?' && cake[i][0] == '?') {
        for (int solve = 0; solve < c; solve++) {
          cake[i][solve] = cake[i + 1][solve];
        }
      }
    }
    cout << "Case #" << t << ":\n";
    for (int i = 0; i < r; i++) {
      for (int solve = 0; solve < c; solve++) {
        cout << cake[i][solve];
      }
      cout << endl;
    }
  }
}
