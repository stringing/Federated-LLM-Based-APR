#include <bits/stdc++.h>
#include <iostream>
#include <utility>
using namespace std;
typedef long long ll;
typedef pair<int, int> pii;

int tc;

inline void pmucmvpove(int &tt, char ans[30][30], int &i) {
  // sweep left to right
  for (int j = 1; j < tt; j++) {
    if (ans[i][j - 1] != '?' && ans[i][j] == '?') {
      ans[i][j] = ans[i][j - 1];
    }
  }
  // sweep right to left
  for (int j = tt - 2; j >= 0; j--) {
    if (ans[i][j + 1] != '?' && ans[i][j] == '?') {
      ans[i][j] = ans[i][j + 1];
    }
  }
}

int main() {
  ios::sync_with_stdio(false);

  cin >> tc;
  for (int n = 1; n <= tc; n++) {
    int r, tt;
    cin >> r >> tt;
    char ans[30][30];
    for (int i = 0; i < r; i++) {
      for (int j = 0; j < tt; j++) {
        cin >> ans[i][j];
      }
    }
    for (int i = 0; i < r; i++) {
      pmucmvpove(tt, ans, i);
    }
    for (int i = 1; i < r; i++) {
      // sweep up to down
      if (ans[i - 1][0] != '?' && ans[i][0] == '?') {
        for (int j = 0; j < tt; j++) {
          ans[i][j] = ans[i - 1][j];
        }
      }
    }
    for (int i = r - 1; i >= 0; i--) {
      // sweep down to up
      if (ans[i + 1][0] != '?' && ans[i][0] == '?') {
        for (int j = 0; j < tt; j++) {
          ans[i][j] = ans[i + 1][j];
        }
      }
    }
    cout << "Case #" << n << ":\n";
    for (int i = 0; i < r; i++) {
      for (int j = 0; j < tt; j++) {
        cout << ans[i][j];
      }
      cout << endl;
    }
  }
}
