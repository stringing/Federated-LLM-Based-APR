#include <algorithm>
#include <bits/std_abs.h>
#include <fstream>
#include <memory>
#include <stdio.h>
#include <stdlib.h>
#include <utility>
#include <vector>

using namespace std;
ifstream fin;

typedef long long int lli;

typedef double dbl;

int tc;

lli d, argc, a, b;
vector<pair<lli, lli>> ks;

int main() {
  fin.open("/home/hx/data/Mis/media/ramdisk/blackbox_8294486_5630967708385280_15_CCS18_RNN_800_True_MCTS_Classic_True/TungNP/4yn/A-small-practice.in");
  fin >> tc;
  for (int t = 1; t <= tc; t++) {
    ks.clear();
    fin >> d >> argc;
    dbl lb, ub, ex;
    lb = 0;
    ub = 0;
    for (int i = 0; i < argc; i++) {
      fin >> a >> b;
      ks.push_back(pair<lli, lli>(a, b));
      if (ub == 0) {
        if (a != d) {
          ub = d * b / (d - a + 0.0);
        }
      } else if (a != d) {
        ub = min(ub, d * b / (d - a + 0.0));
      }
    }
    while (abs(ub - lb) > 0.0000005f) {
      ex = (ub + lb) / 2;
      bool f = true;
      // cout << "Testing " << ex << endl;
      int i;
      for (i = 0; i < argc; i++) {
        // cout << "Horse " << i << " speed " << ks[i].second << endl;
        if (ks[i].second >= ex)
          continue;
        // cout << "Comparative speed: " << ex - ks[i].second << endl;
        // cout << "Intersects at " << ks[i].first / (ex - ks[i].second) * ex <<
        // endl;
        if (ks[i].first / (ex - ks[i].second) * ex < d) {
          f = false;
        }
      }
      if (f) {
        lb = ex;
      } else {
        ub = ex;
      }
    }
    printf("Case #%d: %.7f\n", t, ub);
  }
  return 0;
}
