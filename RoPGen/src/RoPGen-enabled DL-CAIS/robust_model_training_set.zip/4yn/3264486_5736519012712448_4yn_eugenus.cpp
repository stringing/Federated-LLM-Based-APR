#include <algorithm>
#include <bits/stdc++.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>
using namespace std;

typedef pair<int, int> par;
typedef long long int tint;

int a;

int main() {
  freopen("test.txt","r",stdin);
freopen("out.txt","w",stdout);
cin >> a;
  for (int lo = 1; lo <= a; lo++) {
    
    
    string lambda;int best;
cin >> lambda >> best;
    int cnd = 0;for (int ans = 0; ans < lambda.size() - best + 1; ans++) {
      if (lambda[ans] == '-') {
        // cout << "Flip at " << i << endl;
        cnd++;
        for (int caso = ans; caso < ans + best; caso++) {
          if (lambda[caso] == '-')
            lambda[caso] = '+';
          else
            lambda[caso] = '-';
        }
      }
    }
    int P = 1;
    for (int caso = lambda.size() - best + 1; caso < lambda.size(); caso++) {
      if (lambda[caso] == '-')
        P = 0;
    }
    if (P == 1) {
      cout<<"Case #"<<lo<<": "<<cnd<<"\n"<<endl;
    } else {
      cout<<"Case #"<<lo<<": IMPOSSIBLE\n"<<cnd<<endl;
    }
  }
return 0;}
